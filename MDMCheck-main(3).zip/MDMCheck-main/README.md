# Website Services

This repository combines a frontend, Cloudflare worker, and Python backend into a unified workflow.

## Workflow

1. **Build the frontend**
   ```
   make build-frontend
   ```
   Compiles static assets into `frontend/dist`.

2. **Deploy to Cloudflare Pages**
   ```
   make deploy-pages
   ```
   Publishes the built frontend to Cloudflare Pages.

3. **Deploy the Cloudflare Worker**
   ```
   make deploy-worker
   ```
   Deploys the worker script through the `worker` package.

4. **Run the backend locally**
   ```
   make run-backend
   ```
   Launches the FastAPI backend with Uvicorn reloading enabled.

Together these commands provide an organized plan for website services with Cloudflare hosting.

