#!/usr/bin/env python3
import argparse, base64, json, logging, os, re, sys, time, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
from datetime import datetime, timezone, timedelta
import requests

from logging_config import configure_logging

configure_logging()
log = logging.getLogger("auth_evidence")

ENROLLMENT_URL_RE = re.compile(r"https?://[^\s\"'<>]*?(enroll|enrollment|mdm|devicemanagement|enterpriseenrollment|enterpriseregistration)[^\s\"'<>]*", re.IGNORECASE)

def now_iso():
    return datetime.now(timezone.utc).isoformat()

class LocalAuthServer:
    def __init__(self, host="127.0.0.1", port=8765, path="/oauth/callback"):
        self.host, self.port, self.path = host, port, path
        self._server = None
        self._code = None
        self._error = None
    def _make_handler(self):
        parent = self
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                try:
                    u = urlparse(self.path)
                    if u.path != parent.path:
                        self.send_response(404); self.end_headers(); return
                    qs = parse_qs(u.query)
                    if "code" in qs:
                        parent._code = qs["code"][0]
                        self.send_response(200); self.end_headers()
                        self.wfile.write(b"Authentication complete. You may close this window.")
                    else:
                        parent._error = qs.get("error", ["unknown"])[0]
                        self.send_response(400); self.end_headers()
                        self.wfile.write(b"Authentication failed.")
                except Exception as e:
                    parent._error = str(e)
                    self.send_response(500); self.end_headers()
            def log_message(self, *args, **kwargs): pass
        return Handler
    def start(self):
        self._server = HTTPServer((self.host, self.port), self._make_handler())
        t = threading.Thread(target=self._server.serve_forever, daemon=True)
        t.start()
    def stop(self):
        if self._server:
            try: self._server.shutdown()
            except Exception: pass
    @property
    def code(self): return self._code
    @property
    def error(self): return self._error

def _pkce_pair():
    import secrets, hashlib
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(40)).decode().rstrip("=")
    digest = hashlib.sha256(verifier.encode()).digest()
    challenge = base64.urlsafe_b64encode(digest).decode().rstrip("=")
    return verifier, challenge

def _open(url):
    import webbrowser
    if not webbrowser.open(url, new=1, autoraise=True):
        log.info(f"Open this URL in your browser:\n{url}")

class OAuthClient:
    def __init__(self, auth_url, token_url, client_id, scopes, redirect_uri, extra_auth=None, extra_token=None, pkce_supported=True):
        self.auth_url = auth_url
        self.token_url = token_url
        self.client_id = client_id
        self.scopes = scopes
        self.redirect_uri = redirect_uri
        self.extra_auth = extra_auth or {}
        self.extra_token = extra_token or {}
        self.pkce_supported = pkce_supported
    def authorize_url(self, state, code_challenge=None):
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": self.redirect_uri,
            "scope": " ".join(self.scopes),
            "state": state,
        }
        if self.pkce_supported and code_challenge:
            params["code_challenge"] = code_challenge
            params["code_challenge_method"] = "S256"
        params.update(self.extra_auth)
        return self.auth_url + "?" + "&".join(f"{k}={requests.utils.quote(str(v))}" for k,v in params.items())
    def exchange_code(self, code, code_verifier=None, basic_auth=None):
        data = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "code": code,
            "redirect_uri": self.redirect_uri,
        }
        if self.pkce_supported and code_verifier:
            data["code_verifier"] = code_verifier
        data.update(self.extra_token)
        headers = {"Accept": "application/json"}
        auth = None
        if basic_auth:  # (client_id, client_secret)
            auth = basic_auth
        r = requests.post(self.token_url, data=data, headers=headers, auth=auth, timeout=25)
        if not r.ok:
            raise RuntimeError(f"Token exchange failed: {r.status_code} {r.text[:300]}")
        return r.json()

def ms_provider(cfg):
    tenant = cfg.ms_tenant or "consumers"
    auth = f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"
    token = f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
    scopes = ["openid","profile","email"]
    if cfg.with_mail: scopes.append("https://graph.microsoft.com/Mail.Read")
    if cfg.with_graph_device_read:
        scopes += ["https://graph.microsoft.com/DeviceManagementConfiguration.Read.All",
                   "https://graph.microsoft.com/DeviceManagementManagedDevices.Read.All"]
    return OAuthClient(auth, token, cfg.ms_client_id, scopes, cfg.redirect_uri, extra_auth={}, extra_token={}, pkce_supported=True)

def google_provider(cfg):
    auth = "https://accounts.google.com/o/oauth2/v2/auth"
    token = "https://oauth2.googleapis.com/token"
    scopes = ["openid", "profile", "email"]
    extra_auth = {"access_type":"offline","prompt":"consent"}
    if cfg.with_mail: scopes.append("https://www.googleapis.com/auth/gmail.readonly")
    return OAuthClient(auth, token, cfg.google_client_id, scopes, cfg.redirect_uri, extra_auth=extra_auth, pkce_supported=True)

def github_provider(cfg):
    auth = "https://github.com/login/oauth/authorize"
    token = "https://github.com/login/oauth/access_token"
    scopes = ["read:user","user:email"]  # identity only; no mailbox exists
    return OAuthClient(auth, token, cfg.github_client_id, scopes, cfg.redirect_uri, pkce_supported=True)

def _apple_build_client_secret(team_id, key_id, key_file, client_id, ttl=3000):
    import jwt  # PyJWT required
    now = int(time.time())
    payload = {"iss": team_id, "iat": now, "exp": now + ttl, "aud":"https://appleid.apple.com", "sub": client_id}
    with open(key_file, "rb") as f:
        private_key = f.read()
    headers = {"kid": key_id, "alg": "ES256"}
    return jwt.encode(payload, private_key, algorithm="ES256", headers=headers)

def apple_provider(cfg):
    auth = "https://appleid.apple.com/auth/authorize"
    token = "https://appleid.apple.com/auth/token"
    # Apple requires client_secret JWT to exchange; PKCE is supported in web flows.
    if not (cfg.apple_client_id and cfg.apple_team_id and cfg.apple_key_id and cfg.apple_key_file):
        raise RuntimeError("Apple provider requires --apple-client-id, --apple-team-id, --apple-key-id, --apple-key-file")
    client_secret = _apple_build_client_secret(cfg.apple_team_id, cfg.apple_key_id, cfg.apple_key_file, cfg.apple_client_id)
    scopes = ["name","email"]
    extra_auth = {"response_mode": "form_post"}
    extra_token = {"client_secret": client_secret}
    client = OAuthClient(auth, token, cfg.apple_client_id, scopes, cfg.redirect_uri, extra_auth=extra_auth, extra_token=extra_token, pkce_supported=True)
    client._apple_client_secret = client_secret  # keep for refresh if needed
    return client

def yahoo_provider(cfg):
    # Yahoo usually expects client secret; PKCE capabilities vary by app type.
    auth = "https://api.login.yahoo.com/oauth2/request_auth"
    token = "https://api.login.yahoo.com/oauth2/get_token"
    scopes = ["openid","email","profile"]
    extra_auth = {}
    extra_token = {}
    client = OAuthClient(auth, token, cfg.yahoo_client_id, scopes, cfg.redirect_uri, extra_auth=extra_auth, extra_token=extra_token, pkce_supported=True)
    client._yahoo_client_secret = cfg.yahoo_client_secret  # may be required in token exchange
    return client

def fetch_ms_evidence(access_token, scopes, with_mail=False, with_graph_device_read=False):
    h = {"Authorization": f"Bearer {access_token}"}
    out = {"provider":"microsoft","scopes":scopes,"collected_at":now_iso(),"identity":{},"mail_indicators":[],"account_indicators":{}}
    try:
        r = requests.get("https://graph.microsoft.com/v1.0/me", headers=h, timeout=15)
        if r.ok: out["identity"] = r.json()
    except Exception as e: out["identity_error"] = str(e)
    if with_graph_device_read:
        try:
            r = requests.get("https://graph.microsoft.com/v1.0/deviceManagement/managedDevices?$top=1", headers=h, timeout=20)
            out["account_indicators"]["managedDevices_present"] = r.status_code == 200
            if r.ok: out["account_indicators"]["managedDevices_sample"] = r.json()
        except Exception as e: out["account_indicators_error"] = str(e)
    if with_mail:
        try:
            r = requests.get("https://graph.microsoft.com/v1.0/me/messages?$top=50&$select=subject,from,receivedDateTime,bodyPreview,internetMessageHeaders", headers=h, timeout=25)
            if r.ok:
                for item in r.json().get("value", []):
                    headers = item.get("internetMessageHeaders", [])
                    subject = item.get("subject") or ""
                    preview = item.get("bodyPreview") or ""
                    hay = " ".join([subject, preview] + [f"{x.get('name','')}: {x.get('value','')}" for x in headers if isinstance(x, dict)])
                    for m in ENROLLMENT_URL_RE.findall(hay):
                        out["mail_indicators"].append({"match": m if isinstance(m,str) else m[0], "message_subject": subject, "from": item.get("from",{}).get("emailAddress",{}).get("address"), "received": item.get("receivedDateTime")})
        except Exception as e: out["mail_error"] = str(e)
    return out

def fetch_google_evidence(access_token, scopes, with_mail=False):
    h = {"Authorization": f"Bearer {access_token}"}
    out = {"provider":"google","scopes":scopes,"collected_at":now_iso(),"identity":{},"mail_indicators":[],"account_indicators":{}}
    try:
        r = requests.get("https://openidconnect.googleapis.com/v1/userinfo", headers=h, timeout=15)
        if r.ok: out["identity"] = r.json()
    except Exception as e: out["identity_error"] = str(e)
    if with_mail:
        try:
            user = out.get("identity", {}).get("email", "me")
            r = requests.get(f"https://gmail.googleapis.com/gmail/v1/users/{user}/messages?q=newer_than:365d", headers=h, timeout=20)
            if r.ok:
                for m in r.json().get("messages", [])[:100]:
                    try:
                        msg = requests.get(f"https://gmail.googleapis.com/gmail/v1/users/{user}/messages/{m['id']}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=To&metadataHeaders=List-Id", headers=h, timeout=20)
                        if not msg.ok: continue
                        md = msg.json()
                        headers = {hh["name"]: hh["value"] for hh in md.get("payload",{}).get("headers",[])}
                        subject = headers.get("Subject","")
                        hay = " ".join([subject] + [f"{k}: {v}" for k,v in headers.items()])
                        for mm in ENROLLMENT_URL_RE.findall(hay):
                            out["mail_indicators"].append({"match": mm if isinstance(mm,str) else mm[0], "message_id": m["id"], "subject": subject, "headers": {k: headers.get(k) for k in ("From","To","List-Id")}})
                    except Exception: continue
        except Exception as e: out["mail_error"] = str(e)
    return out

def fetch_github_evidence(access_token, scopes):
    h = {"Authorization": f"Bearer {access_token}","Accept":"application/vnd.github+json"}
    out = {"provider":"github","scopes":scopes,"collected_at":now_iso(),"identity":{},"emails":[],"account_indicators":{}}
    try:
        r = requests.get("https://api.github.com/user", headers=h, timeout=15)
        if r.ok: out["identity"] = r.json()
    except Exception as e: out["identity_error"] = str(e)
    try:
        r = requests.get("https://api.github.com/user/emails", headers=h, timeout=15)
        if r.ok: out["emails"] = r.json()
    except Exception as e: out["emails_error"] = str(e)
    return out

def fetch_apple_evidence(token_response, scopes):
    # Apple often returns identity in id_token (JWT)
    out = {"provider":"apple","scopes":scopes,"collected_at":now_iso(),"identity":{}, "account_indicators":{}}
    try:
        id_token = token_response.get("id_token")
        if id_token:
            # decode without verification just to extract claims (kid/iss already validated by Apple during exchange)
            header, payload, _sig = id_token.split(".")
            payload += "=" * (-len(payload) % 4)
            data = json.loads(base64.urlsafe_b64decode(payload.encode()).decode())
            out["identity"] = {"email": data.get("email"), "email_verified": data.get("email_verified"), "sub": data.get("sub")}
    except Exception as e:
        out["identity_error"] = str(e)
    return out

def fetch_yahoo_evidence(access_token, scopes, with_mail_imap=False):
    h = {"Authorization": f"Bearer {access_token}"}
    out = {"provider":"yahoo","scopes":scopes,"collected_at":now_iso(),"identity":{}, "mail_indicators":[], "account_indicators":{}}
    try:
        r = requests.get("https://api.login.yahoo.com/openid/v1/userinfo", headers=h, timeout=15)
        if r.ok: out["identity"] = r.json()
    except Exception as e: out["identity_error"] = str(e)
    if with_mail_imap:
        try:
            import imaplib
            email = out.get("identity", {}).get("email")
            if not email: raise RuntimeError("No email in identity; cannot IMAP")
            # XOAUTH2 via OAuth2 token
            M = imaplib.IMAP4_SSL("imap.mail.yahoo.com", 993)
            auth_string = f"user={email}\x01auth=Bearer {access_token}\x01\x01"
            def xoauth2(auth):
                return auth_string
            typ, data = M.authenticate("XOAUTH2", xoauth2)
            if typ != "OK": raise RuntimeError("IMAP auth failed")
            M.select("INBOX")
            typ, ids = M.search(None, 'SINCE', (datetime.now(timezone.utc) - timedelta(days=365)).strftime("%d-%b-%Y"))
            if typ == "OK":
                msg_ids = ids[0].split()[-50:] if ids and ids[0] else []
                for mid in reversed(msg_ids):
                    typ, msg = M.fetch(mid, "(BODY.PEEK[HEADER.FIELDS (SUBJECT FROM TO LIST-ID)])")
                    if typ != "OK": continue
                    header_blob = (msg[0][1] if isinstance(msg[0], tuple) else b"").decode(errors="ignore")
                    for mm in ENROLLMENT_URL_RE.findall(header_blob):
                        out["mail_indicators"].append({"match": mm if isinstance(mm,str) else mm[0], "message_id": mid.decode() if isinstance(mid, bytes) else str(mid)})
            try: M.logout()
            except Exception: pass
        except Exception as e:
            out["mail_error"] = str(e)
    return out

def run_flow(provider_builder, cfg, basic_auth=None):
    verifier, challenge = _pkce_pair()
    state = os.urandom(12).hex()
    client = provider_builder(cfg)
    auth_server = LocalAuthServer(port=cfg.redirect_port, path=urlparse(cfg.redirect_uri).path)
    auth_server.start()
    try:
        url = client.authorize_url(state=state, code_challenge=challenge if client.pkce_supported else None)
        _open(url)
        deadline = time.time() + cfg.auth_timeout
        while time.time() < deadline and not (auth_server.code or auth_server.error):
            time.sleep(0.2)
        if auth_server.error:
            raise RuntimeError(f"Auth error: {auth_server.error}")
        if not auth_server.code:
            raise TimeoutError("Auth timed out")
        token = client.exchange_code(auth_server.code, verifier if client.pkce_supported else None, basic_auth=basic_auth)
        scopes = token.get("scope","").split() if isinstance(token.get("scope"), str) else cfg.__dict__.get("scopes", [])
        return token, scopes
    finally:
        auth_server.stop()

def main():
    p = argparse.ArgumentParser(description="Authenticated Evidence Collector (consented, read-only)")
    p.add_argument("--provider", choices=["microsoft","google","github","apple","yahoo"], required=True)
    p.add_argument("--redirect-uri", default="http://127.0.0.1:8765/oauth/callback")
    p.add_argument("--redirect-port", type=int, default=8765)
    p.add_argument("--auth-timeout", type=int, default=300)

    # Microsoft
    p.add_argument("--ms-client-id", default=os.environ.get("MS_CLIENT_ID",""))
    p.add_argument("--ms-tenant", default=os.environ.get("MS_TENANT",""))
    p.add_argument("--with-graph-device-read", action="store_true")
    # Google
    p.add_argument("--google-client-id", default=os.environ.get("GOOGLE_CLIENT_ID",""))
    # GitHub
    p.add_argument("--github-client-id", default=os.environ.get("GITHUB_CLIENT_ID",""))
    # Apple (requires client secret JWT)
    p.add_argument("--apple-client-id", default=os.environ.get("APPLE_CLIENT_ID",""))
    p.add_argument("--apple-team-id", default=os.environ.get("APPLE_TEAM_ID",""))
    p.add_argument("--apple-key-id", default=os.environ.get("APPLE_KEY_ID",""))
    p.add_argument("--apple-key-file", default=os.environ.get("APPLE_KEY_FILE",""))
    # Yahoo (client secret often required)
    p.add_argument("--yahoo-client-id", default=os.environ.get("YAHOO_CLIENT_ID",""))
    p.add_argument("--yahoo-client-secret", default=os.environ.get("YAHOO_CLIENT_SECRET",""))

    # Optional mailbox/header scans
    p.add_argument("--with-mail", action="store_true", help="Read-only header/subject scan where supported (Google/Microsoft).")
    p.add_argument("--with-mail-imap", action="store_true", help="Yahoo IMAP header scan via XOAUTH2 (advanced, if scope/token allows).")

    p.add_argument("--out", default="-", help="Path to write JSON (default stdout)")
    args = p.parse_args()

    if args.provider == "microsoft" and not args.ms_client_id:
        log.error("Missing --ms-client-id or MS_CLIENT_ID"); sys.exit(2)
    if args.provider == "google" and not args.google_client_id:
        log.error("Missing --google-client-id or GOOGLE_CLIENT_ID"); sys.exit(2)
    if args.provider == "github" and not args.github_client_id:
        log.error("Missing --github-client-id or GITHUB_CLIENT_ID"); sys.exit(2)
    if args.provider == "apple":
        for k in ("apple_client_id","apple_team_id","apple_key_id","apple_key_file"):
            if not getattr(args, k):
                log.error("Apple requires --apple-client-id, --apple-team-id, --apple-key-id, --apple-key-file"); sys.exit(2)
        try:
            import jwt  # ensure PyJWT is available
        except Exception:
            log.error("Apple requires PyJWT: pip install PyJWT cryptography"); sys.exit(2)
    if args.provider == "yahoo" and not args.yahoo_client_id:
        log.error("Missing --yahoo-client-id or YAHOO_CLIENT_ID"); sys.exit(2)

    try:
        if args.provider == "microsoft":
            token, scopes = run_flow(ms_provider, args)
            evidence = fetch_ms_evidence(token.get("access_token"), scopes, with_mail=args.with_mail, with_graph_device_read=args.with_graph_device_read)
        elif args.provider == "google":
            token, scopes = run_flow(google_provider, args)
            evidence = fetch_google_evidence(token.get("access_token"), scopes, with_mail=args.with_mail)
        elif args.provider == "github":
            token, scopes = run_flow(github_provider, args)
            h = {"Authorization": f"Bearer {token.get('access_token')}"}
            evidence = fetch_github_evidence(token.get("access_token"), scopes)
        elif args.provider == "apple":
            token, scopes = run_flow(apple_provider, args)
            evidence = fetch_apple_evidence(token, scopes)
        elif args.provider == "yahoo":
            basic_auth = None
            if args.yahoo_client_secret:
                basic_auth = (args.yahoo_client_id, args.yahoo_client_secret)
            token, scopes = run_flow(yahoo_provider, args, basic_auth=basic_auth)
            evidence = fetch_yahoo_evidence(token.get("access_token"), scopes, with_mail_imap=args.with_mail_imap)
        else:
            raise RuntimeError("Unsupported provider")
    except KeyboardInterrupt:
        log.warning("Cancelled"); sys.exit(1)
    except Exception as e:
        log.error(str(e)); sys.exit(1)

    data = {
        "authenticated_evidence": evidence,
        "collection_metadata": {
            "provider": args.provider,
            "scopes_granted": evidence.get("scopes", []),
            "redirect_uri": args.redirect_uri,
            "timestamp": now_iso()
        }
    }

    if args.out == "-" or args.out == "":
        print(json.dumps(data, indent=2))
    else:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        log.info(f"Wrote {args.out}")

if __name__ == "__main__":
    main()