"""FastAPI application for MDMCheck backend services."""

from typing import Any
from datetime import datetime
from typing import Any

import requests
from .models import CheckRequest, CheckResult, DeepRequest, DeepResult, Signal
from fastapi import FastAPI, HTTPException, Request

from logging_config import configure_logging

from . import check_runner
from .services import subdomains as subdomain_service

configure_logging()

app = FastAPI()

_latest_results: list[dict[str, Any]] | None = None


def _probes_to_checkresult(probes: list[dict[str, Any]]) -> CheckResult:
    # Compute score as average of available probe scores (0-1 or 0-100), normalize to 0-100
    scores = []
    signals = []
    for p in probes:
        s = p.get("score")
        if isinstance(s, (int, float)):
            scores.append(float(s) if float(s) <= 100 else float(s) * 100.0)  # tolerate 0-1 or 0-100
        if not p.get("ok", True):
            name = p.get("name", "probe")
            detail = p.get("detail", {})
            title = detail.get("error") or detail.get("message") or f"{name} failed"
            level = "danger"
            signals.append(Signal(id=name, title=title, level=level))
    score = int(round(sum(scores) / len(scores))) if scores else 0
    status: str
    if score >= 85 and not signals:
        status = "ok"
    elif score >= 60:
        status = "warn"
    else:
        status = "risk"
    return CheckResult(status=status, score=score, signals=signals, checkedAt=datetime.utcnow())

@app.get("/myip")
async def myip(request: Request) -> dict[str, str]:
    """Return the requesting client's IP address."""
    ip = request.headers.get("CF-Connecting-IP") or request.client.host or ""
    return {"ip": ip}


@app.post("/archive")
async def archive(payload: dict[str, str]) -> dict[str, Any]:
    """Archive a page using Internet Archive's Save Page Now API."""
    url = payload.get("url")
    if not url:
        raise HTTPException(status_code=400, detail="Missing url")
    try:
        resp = requests.get(
            f"https://web.archive.org/save/{url}",
            headers={"Accept": "application/json"},
            timeout=10,
        )
        resp.raise_for_status()
    except requests.RequestException as exc:  # pragma: no cover - network issues
        raise HTTPException(status_code=502, detail="Archive request failed") from exc
    return resp.json()


@app.post("/subdomains")
async def subdomains(payload: dict[str, str]) -> dict[str, list[str]]:
    """Enumerate subdomains for a given domain."""
    domain = payload.get("domain")
    if not domain:
        raise HTTPException(status_code=400, detail="Missing domain")
    subs = subdomain_service.enumerate_subdomains(domain)
    return {"subdomains": subs}


@app.post("/scan")
async def scan() -> dict[str, Any]:
    """Run all checks and store results."""
    global _latest_results
    _latest_results = check_runner.run_all_checks()
    return {"status": "ok", "results": _latest_results}


@app.get("/status")
async def status() -> dict[str, Any]:
    """Return service status."""
    return {"status": "ok"}


@app.get("/report")
async def report() -> dict[str, Any]:
    """Return latest scan report."""
    if _latest_results is None:
        return {"status": "no results"}
    return {"status": "ok", "results": _latest_results}


@app.get("/oauth/{provider}")
async def oauth_provider(provider: str) -> dict[str, Any]:
    """Placeholder for OAuth provider handling."""
    return {"provider": provider}


@app.post("/check", response_model=CheckResult)
async def check(payload: CheckRequest) -> Any:
    """Quick check endpoint: runs standard probes and returns unified schema."""
    ident = payload.email or payload.domain
    if not ident:
        raise HTTPException(status_code=400, detail="Provide email or domain")
    probes = check_runner.run_all_checks()
    return _probes_to_checkresult(probes)

@app.post("/deep", response_model=DeepResult)
async def deep(payload: DeepRequest) -> Any:
    """Deep provider-assisted check. Placeholder logic aligned with frontend schema."""
    providers = [p.lower() for p in payload.providers]
    prov = providers[0] if providers else "unknown"
    # TODO: Expand with real provider flows
    mdm = []
    hygiene = []
    rules = []
    recommendations = []
    # Example heuristic: if microsoft present, suggest Entra audit
    if "microsoft" in providers:
        hygiene.append("Review Entra sign-in & conditional access")
    if "google" in providers:
        hygiene.append("Check Workspace Admin > Devices enrollment")
    score = 70 if hygiene else 50
    return DeepResult(provider=prov, score=score, mdm=mdm, rules=rules, hygiene=hygiene, recommendations=recommendations)

if __name__ == "__main__":  # pragma: no cover - entry point for local dev
    import uvicorn

    uvicorn.run("backend.app:app", host="0.0.0.0", port=8000)
