"""Dynamic check discovery and scoring utilities for MDMCheck.

Any Python module placed in the ``checks/`` subdirectory that exposes a
``run()`` function will be executed automatically. The ``run`` function
should return a mapping with at least ``{"ok": bool, "score": number}``.
Additional keys such as ``name`` or ``detail`` are preserved.
"""
from __future__ import annotations

from importlib import import_module
from pathlib import Path
from typing import Any, Dict, List, Optional

CHECKS_DIR = Path(__file__).with_name("checks")


def discover_checks() -> List[str]:
    """Return module names for available checks."""
    if not CHECKS_DIR.exists():
        return []
    return [p.stem for p in CHECKS_DIR.glob("*.py") if p.is_file() and not p.name.startswith("_")]


def run_all_checks(context: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Import and execute all available checks.

    Each check's ``run`` function is invoked with ``context`` when provided.
    Checks that do not accept arguments continue to work through a
    ``TypeError`` fallback.
    """
    results: List[Dict[str, Any]] = []
    for name in discover_checks():
        try:
            mod = import_module(f"backend.checks.{name}")
            if hasattr(mod, "run"):
                if context is not None:
                    try:
                        res = mod.run(context)  # type: ignore[attr-defined]
                    except TypeError:
                        res = mod.run()  # type: ignore[attr-defined]
                else:
                    res = mod.run()  # type: ignore[attr-defined]
                if isinstance(res, dict):
                    res.setdefault("name", name)
                    results.append(res)
        except Exception:
            results.append({"name": name, "ok": False, "detail": {"error": "check failed"}})
    return results


def average_score(probes: List[Dict[str, Any]]) -> float | None:
    """Compute the average score for probes that define ``score``."""
    scores = [p["score"] for p in probes if isinstance(p.get("score"), (int, float))]
    if not scores:
        return None
    return sum(float(s) for s in scores) / len(scores)
