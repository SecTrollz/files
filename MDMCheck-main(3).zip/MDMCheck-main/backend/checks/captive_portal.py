"""Detect potential captive portals by probing a known 204 endpoint."""
from __future__ import annotations

import requests
from typing import Dict, Any

TEST_URL = "http://www.gstatic.com/generate_204"


def run(context: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Return False if the probe is intercepted by a captive portal."""
    try:
        resp = requests.get(TEST_URL, timeout=3)
        ok = resp.status_code == 204
        return {"ok": ok, "score": 1.0 if ok else 0.0, "detail": {"status_code": resp.status_code}}
    except Exception as exc:  # pragma: no cover - network errors
        return {"ok": False, "detail": {"error": str(exc)}}
