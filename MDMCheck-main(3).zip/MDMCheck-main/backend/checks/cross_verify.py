"""Cross-validate identity and timeline checks to catch inconsistencies.

This plug-in reuses the built-in ``who``, ``when`` and ``root_ca`` checks and
compares their outputs.  It is meant to "double check the checks" so that
attackers have a harder time tricking a single probe.
"""
from __future__ import annotations

from typing import Any, Dict

from . import who, when, root_ca


def run(context: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Run a cross-verification pass over multiple check results.

    The function executes the ``who`` and ``when`` checks and, when certificate
    data is available, the ``root_ca`` check.  The discovered provider from the
    ``who`` check is compared against the certificate issuer.  Any mismatch will
    flag the check as failed.  All intermediate details are returned so the
    investigator can trace the reasoning.
    """
    context = context or {}
    detail: Dict[str, Any] = {}
    ok = True

    who_res = who.run(context)
    detail["who"] = who_res.get("detail", {})
    ok = ok and bool(who_res.get("ok"))
    provider = detail["who"].get("provider")

    when_res = when.run(context)
    detail["when"] = when_res.get("detail", {})
    ok = ok and bool(when_res.get("ok"))

    ca_res = None
    if provider and (context.get("certificate") or context.get("domain")):
        ca_res = root_ca.run(context)
        detail["root_ca"] = ca_res.get("detail", {}) if isinstance(ca_res, dict) else {}
        if isinstance(ca_res, dict) and ca_res.get("ok") and provider:
            issuer = ca_res["detail"].get("issuer", {})
            issuer_text = " ".join(str(v) for v in issuer.values()).lower()
            if provider.lower() not in issuer_text:
                ok = False
                detail["mismatch"] = {"provider": provider, "issuer": issuer}
        else:
            ok = False
    score = 1 if ok else 0
    return {"name": "cross_verify", "ok": ok, "score": score, "detail": detail}
