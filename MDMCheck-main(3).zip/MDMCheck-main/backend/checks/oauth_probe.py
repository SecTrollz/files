"""Verify OAuth login endpoints for common providers to spot phishing."""
from __future__ import annotations

from typing import Dict, Any
from urllib.parse import urlparse

PROVIDER_LOGIN_DOMAINS = {
    "google": "accounts.google.com",
    "microsoft": "login.microsoftonline.com",
    "apple": "appleid.apple.com",
}


def run(context: Dict[str, Any] | None = None) -> Dict[str, Any]:
    context = context or {}
    provider = context.get("provider")
    url = context.get("login_url")
    if not provider or not url:
        return {"ok": False, "detail": {"error": "missing provider or login_url"}}
    expected = PROVIDER_LOGIN_DOMAINS.get(provider.lower())
    actual = urlparse(url).netloc
    ok = actual == expected
    detail = {"expected_domain": expected, "actual_domain": actual}
    return {"ok": ok, "score": 1.0 if ok else 0.0, "detail": detail}
