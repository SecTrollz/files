"""Discover root certificate authority of a TLS endpoint.

The check accepts either a domain name or a PEM certificate string.
It parses the certificate issuer and returns it so investigators can
spot unexpected root CAs that might indicate interception.
"""
from __future__ import annotations

import ssl
import tempfile
import os
from typing import Dict, Any


def _parse_issuer_from_pem(pem: str) -> Dict[str, str]:
    """Decode certificate PEM and return issuer attributes."""
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(pem.encode())
        tmp.flush()
        path = tmp.name
    try:
        info = ssl._ssl._test_decode_cert(path)
        issuer = {entry[0][0]: entry[0][1] for entry in info.get("issuer", [])}
        return issuer
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def run(context: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Return issuer information for a domain or certificate.

    If neither a domain nor certificate is provided the check returns
    ``ok: False``.
    """
    context = context or {}
    pem = context.get("certificate")
    domain = context.get("domain")
    if not pem and not domain:
        return {"ok": False, "detail": {"error": "no certificate or domain"}}
    try:
        if not pem and domain:
            pem = ssl.get_server_certificate((domain, 443))
        issuer = _parse_issuer_from_pem(pem)
        return {"ok": True, "score": 1.0, "detail": {"issuer": issuer}}
    except Exception as exc:  # pragma: no cover - network/ssl errors
        return {"ok": False, "detail": {"error": str(exc)}}
