"""Example check module used to demonstrate dynamic loading."""

def run():
    return {"ok": True, "score": 10, "detail": {"info": "sample"}}
