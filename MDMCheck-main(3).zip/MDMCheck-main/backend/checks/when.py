from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Optional

import ssl
import socket
import dns.resolver

try:  # Optional dependency; we fall back gracefully when missing
    import whois  # type: ignore
except Exception:  # pragma: no cover - optional import
    whois = None


# Known consumer domains with approximate public launch dates.  These allow the
# check to remain useful even when network operations fail.
KNOWN_DATES = {
    "gmail.com": "2004-04-01",
    "outlook.com": "2012-07-31",
    "hotmail.com": "1996-07-04",
    "live.com": "2005-11-01",
    "yahoo.com": "1997-01-24",
    "icloud.com": "2011-06-06",
    "me.com": "2008-07-09",
    "proton.me": "2014-05-16",
    "protonmail.com": "2014-05-16",
}


def _extract_domain(context: Optional[Dict[str, Any]]) -> Optional[str]:
    if not context:
        return None
    domain = context.get("domain")
    if domain:
        return domain
    email = context.get("email")
    if email and "@" in email:
        return email.split("@")[-1]
    return None


def _lookup_certificate(domain: str) -> Optional[str]:
    """Return the certificate notBefore date if retrievable."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                return cert.get("notBefore")
    except Exception:  # pragma: no cover - network variability
        return None


def _lookup_whois(domain: str) -> Optional[str]:
    if not whois:
        return None
    try:
        data = whois.whois(domain)
        cd = data.creation_date
        if isinstance(cd, list):
            cd = cd[0]
        if hasattr(cd, "isoformat"):
            return cd.isoformat()
    except Exception:  # pragma: no cover - whois network variability
        return None
    return None


def _lookup_soa(domain: str) -> Optional[str]:
    """Return a date extracted from the DNS SOA serial if available."""
    try:
        answer = dns.resolver.resolve(domain, "SOA")[0]
        serial = str(answer.serial)
        if len(serial) >= 8 and serial[:8].isdigit():
            y, m, d = serial[:4], serial[4:6], serial[6:8]
            return f"{y}-{m}-{d}"
        return serial
    except Exception:  # pragma: no cover - network variability
        return None


def run(context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Estimate enrollment timing using SSL certificate dates.

    The check first tries to read the target domain's certificate ``notBefore``
    field.  If that fails, it falls back to WHOIS creation dates, DNS SOA
    serials, or a static launch map for common email providers.
    """

    domain = _extract_domain(context)

    detail: Dict[str, Any] = {"checked_at": datetime.now(timezone.utc).isoformat()}
    ok = False

    if domain:
        detail["domain"] = domain

        nb = _lookup_certificate(domain)
        if nb:
            detail["certificate_not_before"] = nb
            ok = True
        else:
            wd = _lookup_whois(domain)
            if wd:
                detail["domain_creation"] = wd
                ok = True
            else:
                sd = _lookup_soa(domain)
                if sd:
                    detail["dns_serial"] = sd
                    ok = True
                elif domain in KNOWN_DATES:
                    detail["known_launch"] = KNOWN_DATES[domain]
                    ok = True
                else:
                    detail["error"] = "certificate, whois, and DNS lookup failed"
    else:
        detail["error"] = "no domain provided"

    score = 1 if ok else 0
    return {"name": "when", "ok": ok, "score": score, "detail": detail}
