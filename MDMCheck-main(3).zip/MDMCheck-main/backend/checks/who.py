from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Optional, List

import dns.resolver

try:  # Optional dependency used for more aggressive attribution
    import whois  # type: ignore
except Exception:  # pragma: no cover - optional import may be absent
    whois = None

try:  # Optional dependency for accurate domain extraction
    import tldextract  # type: ignore
except Exception:  # pragma: no cover - optional import may be absent
    tldextract = None


# Common consumer email domains mapped to their providers.  These cover the
# major platforms so the check works even when DNS lookups are blocked.
KNOWN_PROVIDERS = {
    "gmail.com": "Google",
    "googlemail.com": "Google",
    "outlook.com": "Microsoft",
    "hotmail.com": "Microsoft",
    "live.com": "Microsoft",
    "yahoo.com": "Yahoo",
    "icloud.com": "Apple",
    "me.com": "Apple",
    "proton.me": "Proton",
    "protonmail.com": "Proton",
}


def _extract_domain(context: Optional[Dict[str, Any]]) -> Optional[str]:
    """Derive the domain from ``context`` data.

    Preference is given to an explicit ``domain`` field and then to any email
    address provided.  Returns ``None`` when no domain can be determined.
    """

    if not context:
        return None

    domain = context.get("domain")
    if domain:
        return domain

    email = context.get("email")
    if email and "@" in email:
        return email.split("@")[-1]
    return None


def _base_domain(host: str) -> str:
    """Return the registrable domain for ``host``.

    ``tldextract`` is used when available to handle multi-label TLDs.  A
    simple two-label heuristic is used as a fallback.
    """

    if tldextract:
        ext = tldextract.extract(host)
        return ".".join(part for part in [ext.domain, ext.suffix] if part)

    parts = host.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def _resolve_cname(host: str) -> str:
    """Follow CNAME chains to their final target."""

    seen = set()
    current = host.rstrip(".")
    while current not in seen:
        seen.add(current)
        try:
            answers = dns.resolver.resolve(current, "CNAME")
            current = answers[0].target.to_text().rstrip(".")
        except Exception:
            break
    return current


def _infer_provider_from_hosts(hosts: List[str]) -> Optional[str]:
    host_join = " ".join(hosts).lower()
    if "google" in host_join:
        return "Google"
    if any(k in host_join for k in ["outlook", "office365", "hotmail", "microsoft"]):
        return "Microsoft"
    if "yahoodns" in host_join or "yahoo" in host_join:
        return "Yahoo"
    if "protonmail" in host_join or "proton.me" in host_join:
        return "Proton"
    if "icloud" in host_join or "apple" in host_join or "me.com" in host_join:
        return "Apple"
    return None


def _infer_provider_from_spf(records: List[str]) -> Optional[str]:
    joined = " ".join(records).lower()
    if "google.com" in joined or "googlemail.com" in joined:
        return "Google"
    if "spf.protection.outlook.com" in joined or "outlook.com" in joined:
        return "Microsoft"
    if "yahoo.com" in joined:
        return "Yahoo"
    if "icloud.com" in joined or "apple.com" in joined or "me.com" in joined:
        return "Apple"
    if "protonmail.com" in joined or "protonmail.ch" in joined or "proton.me" in joined:
        return "Proton"
    return None


def _registrant(domain: str) -> Optional[str]:
    if not whois:
        return None
    try:
        data = whois.whois(domain)
        return data.get("org") or data.get("name")
    except Exception:  # pragma: no cover - whois network variability
        return None


def run(context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Identify the organization behind the target domain.

    Multiple techniques are combined to chase the identity of the enrolment
    source.  The check follows MX CNAME chains, inspects SPF records, and
    performs WHOIS lookups on both the target domain and any mail hosts.  A
    backwards validation step ensures the discovered provider matches WHOIS
    registrant data whenever possible.
    """

    domain = _extract_domain(context)

    detail: Dict[str, Any] = {"checked_at": datetime.now(timezone.utc).isoformat()}
    ok = False

    if domain:
        detail["domain"] = domain
        provider: Optional[str] = KNOWN_PROVIDERS.get(domain)

        mx_hosts: List[str] = []
        if not provider:
            try:
                answers = dns.resolver.resolve(domain, "MX")
                for r in answers:
                    host = r.exchange.to_text().rstrip(".")
                    mx_hosts.append(_resolve_cname(host))
                detail["mx_records"] = mx_hosts
                provider = _infer_provider_from_hosts(mx_hosts)
                ok = True
            except Exception as exc:  # pragma: no cover - network errors vary
                detail["dns_error"] = str(exc)

            # SPF lookup offers another attribution path
            try:
                txt_answers = dns.resolver.resolve(domain, "TXT")
                spf_records = [t.to_text().strip('"') for t in txt_answers if "spf1" in t.to_text().lower()]
                if spf_records:
                    detail["spf"] = spf_records
                    provider = provider or _infer_provider_from_spf(spf_records)
                    ok = True
            except Exception:  # pragma: no cover - TXT lookups optional
                pass
        else:
            ok = True

        if provider:
            detail["provider"] = provider

        domain_registrant = _registrant(domain)
        if domain_registrant:
            detail["registrant"] = domain_registrant
            ok = True

        mx_registrants: Dict[str, str] = {}
        for host in mx_hosts:
            host_domain = _base_domain(host)
            reg = _registrant(host_domain)
            if reg:
                mx_registrants[host_domain] = reg
        if mx_registrants:
            detail["mx_registrants"] = mx_registrants

        validated: Optional[bool] = None
        if provider and domain_registrant:
            validated = provider.lower() in domain_registrant.lower()
        if provider and mx_registrants and not validated:
            validated = any(provider.lower() in r.lower() for r in mx_registrants.values())

        if validated is not None:
            detail["validated"] = validated
            ok = ok and validated

    else:
        detail["error"] = "no domain provided"

    score = 1 if ok else 0
    return {"name": "who", "ok": ok, "score": score, "detail": detail}
