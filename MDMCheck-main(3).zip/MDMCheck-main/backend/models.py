from __future__ import annotations
from typing import List, Literal, Optional
from pydantic import BaseModel, Field
from datetime import datetime

Status = Literal["ok", "warn", "risk"]

class Signal(BaseModel):
    id: str
    title: str
    level: Literal["info", "warn", "danger"]

class CheckRequest(BaseModel):
    email: Optional[str] = None
    domain: Optional[str] = None

class CheckResult(BaseModel):
    status: Status
    score: int = Field(ge=0, le=100)
    signals: List[Signal] = []
    checkedAt: datetime

class DeepRequest(BaseModel):
    providers: List[str]

class DeepResult(BaseModel):
    provider: str
    score: int = Field(ge=0, le=100)
    tenant: Optional[str] = None
    lastScan: Optional[datetime] = None
    mdm: List[str] = []
    rules: List[str] = []
    hygiene: List[str] = []
    recommendations: List[str] = []
