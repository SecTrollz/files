"""Utilities for enumerating subdomains of a given domain."""

from __future__ import annotations

from collections.abc import Iterable

import dns.resolver

COMMON_PREFIXES: list[str] = [
    "www",
    "mail",
    "ftp",
    "dev",
    "staging",
]


def enumerate_subdomains(domain: str, prefixes: Iterable[str] | None = None) -> list[str]:
    """Return a list of discovered subdomains for *domain*.

    The function performs DNS A-record lookups for a small list of common
    subdomain prefixes. It purposely keeps the list short to avoid long-running
    network operations during tests. Failures to resolve a name are silently
    ignored.
    """

    prefixes = list(prefixes or COMMON_PREFIXES)
    found: list[str] = []
    for prefix in prefixes:
        sub = f"{prefix}.{domain}"
        try:
            dns.resolver.resolve(sub, "A")
        except Exception:
            continue
        found.append(sub)
    return found
