from __future__ import annotations
from pathlib import Path
import json, hashlib, zipfile, time
try:
    from signing import load_private_key, sign_bytes, get_public_key_pem
except Exception:  # pragma: no cover
    def load_private_key():  # type: ignore
        raise RuntimeError("signing module unavailable")

    def sign_bytes(data: bytes, key) -> bytes:  # type: ignore
        return b""

    def get_public_key_pem(key) -> str:  # type: ignore
        return ""

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def write_manifest(bundle_dir: Path) -> dict:
    # Minimal manifest with file hashes
    base = {"generated": int(time.time())}
    files = ["findings.json", "report.pdf"]
    if (bundle_dir / "evidence.json").exists():
        files.append("evidence.json")
    manifest_files = {}
    for name in files:
        path = bundle_dir / name
        if path.exists():
            manifest_files[name] = {"sha256": sha256_file(path), "size": path.stat().st_size}
    base["files"] = manifest_files
    (bundle_dir / "manifest.json").write_text(json.dumps(base, indent=2), encoding="utf-8")
    return base

def create_bundle_zip(bundle_dir: Path) -> Path:
    # Writes manifest + manifest.sig + public key, then zips
    manifest = write_manifest(bundle_dir)
    mbytes = (bundle_dir / "manifest.json").read_bytes()
    key = load_private_key()
    sig = sign_bytes(mbytes, key)
    (bundle_dir / "manifest.sig").write_bytes(sig)
    (bundle_dir / "public_key.pem").write_text(get_public_key_pem(key), encoding="utf-8")
    zpath = bundle_dir / "bundle.zip"

    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name in [
            "findings.json",
            "report.pdf",
            "evidence.json",
            "manifest.json",
            "manifest.sig",
            "public_key.pem",
            "bundle.sha256",
        ]:
            p = bundle_dir / name
            if p.exists():
                z.write(p, arcname=name)
        # include evidence_sources folder if present
        src_dir = bundle_dir / "evidence_sources"
        if src_dir.exists():
            for p in src_dir.rglob("*"):
                if p.is_file():
                    z.write(p, arcname=str(p.relative_to(bundle_dir)))

    # Write SHA256 of the zip for UI
    (bundle_dir / "bundle.sha256").write_text(sha256_file(zpath), encoding="utf-8")
    return zpath
