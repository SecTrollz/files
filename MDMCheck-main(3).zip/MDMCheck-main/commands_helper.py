
from __future__ import annotations
from pathlib import Path
from urllib.parse import quote

def write_commands(bundle_dir: Path, email: str, domain: str) -> None:
    out_dir = bundle_dir / "evidence_sources"
    out_dir.mkdir(parents=True, exist_ok=True)
    lines = []
    # DNS
    lines.append(f"# DNS evidence")
    lines.append(f"dig +dnssec CNAME enterpriseenrollment.{domain}")
    lines.append(f"dig A enterpriseenrollment.manage.microsoft.com")
    # OIDC / UserRealm
    userrealm = f"https://login.microsoftonline.com/common/UserRealm/{quote(email)}?api-version=2.1"
    lines.append("")
    lines.append("# OIDC / UserRealm")
    lines.append(f"curl -sS '{userrealm}' -H 'Accept: application/json'")
    # Vendor probe (Intune/Enrollment)
    lines.append("")
    lines.append("# Vendor probe")
    lines.append(f"curl -I --tlsv1.2 https://enterpriseenrollment.{domain}/EnrollmentServer/Discovery.svc")
    # CT logs example (crt.sh as a convenience)
    lines.append("")
    lines.append("# Certificate Transparency (public query)")
    lines.append(f"curl -sS 'https://crt.sh/?q=%25.{domain}&output=json'")
    (out_dir / "commands.txt").write_text("\n".join(lines), encoding="utf-8")
