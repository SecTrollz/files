# tests/conftest.py
import os
import json
import logging
import pathlib
import pytest
import tempfile
from typing import Iterator

# Ensure DEBUG logging for maximal visibility during tests
os.environ.setdefault("MDMCHECK_LOG_LEVEL", "DEBUG")

@pytest.fixture(scope="session", autouse=True)
def _configure_json_logging() -> None:
    """Configure JSON logging for all tests (if available)."""
    try:
        from logging_config import configure_logging
    except Exception as e:  # pragma: no cover
        # Fall back to basicConfig if module not present yet
        logging.basicConfig(level=logging.DEBUG)
        logging.getLogger(__name__).warning("logging_config not found: %s", e)
    else:
        configure_logging()
        logging.getLogger(__name__).debug("JSON logging configured for tests")

@pytest.fixture
def tmp_workdir() -> Iterator[pathlib.Path]:
    """Create an isolated working directory for filesystem tests."""
    d = pathlib.Path(tempfile.mkdtemp(prefix="mdmcheck_test_"))
    try:
        yield d
    finally:
        # Leave artifacts on failure to aid debugging; cleaned by CI automatically
        pass

@pytest.fixture
def capjson(capfd):
    """Capture stdout and parse as JSON (helper for CLI JSON outputs)."""
    def _read():
        out, err = capfd.readouterr()
        try:
            return json.loads(out), err
        except json.JSONDecodeError:
            return None, err
    return _read