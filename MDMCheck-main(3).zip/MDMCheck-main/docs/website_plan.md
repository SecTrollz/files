# MDMCheck Website Source Code Plan

This document consolidates the existing scripts into a coherent architecture for the MDMCheck website. MDMCheck is the world's first service focused on detecting **silent** MDM enrollment across devices and email accounts. The plan below explains how investigators can rely on open‑source and proprietary logic to verify *who* triggered an enrollment and *when* it occurred, while also providing deployment guidance for Cloudflare.

## Repository Layout

```text
frontend/   # React single page app, static pages, and styles
backend/    # FastAPI service, check runner, and pluggable checks
*.py        # legacy scan and helper scripts at repository root
```

### Root Script Index

The table below maps each top‑level script to its role within the service. It
provides a quick reference when deploying or extending the tool.

| Script | Purpose |
| --- | --- |
| `backend/app.py` | FastAPI app exposing scan APIs |
| `notsofast.py` | Main scanning orchestrator |
| `backend/check_runner.py` | Discovers and executes `backend/checks/` plug‑ins |
| `backend/services/mitm_detector.py` | Network MITM heuristics |
| `notsofastextended.py` | Extra network safety probes |
| `notso_automator.py` | Convenience wrapper to chain common commands |
| `notso_output.py` | Shared result formatting helpers |
| `authenticated_evidence_collector.py` | Fetches gated evidence |
| `sandbox_launcher.py` / `safety_net.py` | Executes code in isolation |
| `bundle_packager.py` / `verify_bundle.py` | Create and validate evidence bundles |
| `notsofast_report.py` / `pdf_report.py` | Render JSON and PDF reports |
| `notsofast_compare.py` / `notsofast_formatter.py` | Regression and summary tools |
| `commands_helper.py` / `logging_config.py` | Utility helpers |
| `storage.py` | Persistence for artifacts |
| `dto.py` | Typed data objects used across modules |
| `manifests_signer.py` | Optional manifest signing helper |


### Front-end

The front-end lives under [`frontend/`](../frontend) with the React entrypoint
[`app.tsx`](../frontend/app.tsx). API helpers, routing, and validation are split
into [`api.ts`](../frontend/api.ts), [`route.ts`](../frontend/route.ts), and
[`validators.ts`](../frontend/validators.ts). Styles are defined in
[`theme.css`](../frontend/theme.css) and [`styles.css`](../frontend/styles.css),
and the root HTML container is [`index.html`](../frontend/index.html).
Supporting static pages such as
[`pages/results.tsx`](../frontend/pages/results.tsx) (redacted result screen),
[`pages/paywall.tsx`](../frontend/pages/paywall.tsx),
[`pages/account.tsx`](../frontend/pages/account.tsx),
[`pages/billing.tsx`](../frontend/pages/billing.tsx), and
[`pages/contact.tsx`](../frontend/pages/contact.tsx) are served alongside the
bundled app.

To boost the site's utility, the dashboard also hosts small OSINT helpers under
dedicated routes:

- [`pages/MyIP.tsx`](../frontend/pages/MyIP.tsx) – shows IP geolocation and DNS
  leak checks by calling a Worker wrapper around the [MyIP](https://github.com/jason5ng32/MyIP)
  API.
- [`pages/SavePageNow.tsx`](../frontend/pages/SavePageNow.tsx) – provides a form
  to archive a URL on the Wayback Machine via `/api/archive`.
- [`pages/Subdomains.tsx`](../frontend/pages/Subdomains.tsx) – front end for
  [`xsubfind3r`](https://github.com/Hack-Team-ai/xsubfind3r); visitors submit a
  domain and the Worker streams discovered subdomains.

Each of these pages is powered by lightweight React components that reuse the
existing `api.ts` helper so the new tools feel native to the main app.

The results screen teases a few high‑level signals and then invites visitors to
unlock the **full PDF evidence pack**. The paywall page reinforces this message
with marketing copy and a feature list so casual visitors are encouraged to
upgrade for unredacted reports.

The client also supports OAuth sign-in flows for Google, Microsoft, and Apple
accounts. These flows obtain tokens that can be fed into back-end checks to
correlate enrollment messages with the identity that authorised them. Result
screens intentionally redact sensitive indicators and link to a paywall page
where subscribers can log in or manage billing before downloading the full PDF
report.

### Back-end

The Python service powers scanning and reporting. It is organized into the
following categories:

**Scanning core**

- [`notsofast.py`](../notsofast.py) – orchestrates scans.
- [`backend/check_runner.py`](../backend/check_runner.py) and [`backend/checks/`](../backend/checks) –
  auto-discovered plug‑ins. Each `backend/checks/*.py` file exposing `run()` is
  executed and its result merged into the overall report with a dynamic
  score. The plug-in system accepts both open-source and proprietary
  modules so investigators can continuously expand coverage. Context from
  the main scan is passed to these checks for deeper analysis.
- [`backend/checks/who.py`](../backend/checks/who.py) and
  [`backend/checks/when.py`](../backend/checks/when.py) – built‑in identity and timeline
  probes. They recognise popular consumer email providers such as Gmail,
  Outlook, Yahoo, iCloud and ProtonMail without requiring network access.
  The “who” check recursively follows MX CNAME chains, inspects SPF
  records and performs WHOIS lookups on both the target domain and its
  mail hosts. A backwards validation step confirms that any inferred
  provider matches WHOIS registrant data. The “when” check aggressively
  attributes custom domains using MX, WHOIS registrant data, SSL
  certificates and DNS SOA serials to pin down *who* enrolled a device and
  *when* it happened.
- [`backend/checks/oauth_probe.py`](../backend/checks/oauth_probe.py) – verifies that OAuth
  login links for Google, Microsoft, and Apple resolve to legitimate
  domains, flagging phishing enrolment pages.
- [`backend/checks/root_ca.py`](../backend/checks/root_ca.py) – extracts certificate issuer
  information from TLS endpoints so unexpected root certificate authorities
  can be spotted.
- [`backend/checks/captive_portal.py`](../backend/checks/captive_portal.py) – probes a known
  204 endpoint to detect captive portals that might tamper with network
  traffic.
- [`backend/checks/cross_verify.py`](../backend/checks/cross_verify.py) – cross-validates
  “who”, “when”, and certificate issuer results to catch tricks and ensure
  consistency across probes.
- [`backend/services/mitm_detector.py`](../backend/services/mitm_detector.py) and
  [`notsofastextended.py`](../notsofastextended.py) – perform network safety
  checks.

**Evidence collection**

- [`authenticated_evidence_collector.py`](../authenticated_evidence_collector.py)
  – retrieves protected resources.
- [`sandbox_launcher.py`](../sandbox_launcher.py) and
  [`safety_net.py`](../safety_net.py) – isolate untrusted code during scans.

**Packaging and reporting**

- [`bundle_packager.py`](../bundle_packager.py) and
  [`verify_bundle.py`](../verify_bundle.py) – create and verify evidence bundles.
- [`notsofast_report.py`](../notsofast_report.py) and
  [`pdf_report.py`](../pdf_report.py) – produce user-facing reports. The
  PDF generator emits a redacted summary by default so casual users cannot
  see sensitive evidence. Paying customers can request an unredacted PDF.
- [`notsofast_compare.py`](../notsofast_compare.py) – diff baseline and current
  results, flagging regressions in JSON or table form.

**Utilities**

- [`commands_helper.py`](../commands_helper.py) and
  [`logging_config.py`](../logging_config.py) – common helpers.
- [`storage.py`](../storage.py) – persistence layer for scan artifacts.
- [`notso_output.py`](../notso_output.py) – shared formatting for CLI and reports.
- [`notso_automator.py`](../notso_automator.py) – chains scans and packaging into one command.
- [`manifests_signer.py`](../manifests_signer.py) – optional bundle manifest signer.
- [`dto.py`](../dto.py) – common typed structures shared across modules.

Additional lightweight services expose external tooling through the Worker. A
MyIP wrapper returns network diagnostics, a Wayback Machine client saves pages
on demand, and an `xsubfind3r` runner handles subdomain enumeration.

These components expose the following Worker HTTP endpoints. Cloudflare routes
public requests through `/api/*`, while the Worker defines handlers without the
`/api` prefix. The examples below show both local development and production
URLs to reduce confusion:

- `GET /health`
  - Local: `http://localhost:8787/health`
  - Production: `https://mdmcheck.com/api/health`
  - Returns a heartbeat to verify the Worker is online.
- `POST /check`
  - Local: `http://localhost:8787/check`
  - Production: `https://mdmcheck.com/api/check`
  - Runs a quick synchronous domain or email check.
- `POST /scan`
  - Local: `http://localhost:8787/scan`
  - Production: `https://mdmcheck.com/api/scan`
  - Starts a full asynchronous scan.
- `GET /status?id=<job>`
  - Local: `http://localhost:8787/status?id=<job>`
  - Production: `https://mdmcheck.com/api/status?id=<job>`
  - Polls for scan progress.
- `GET /report?id=<job>`
  - Local: `http://localhost:8787/report?id=<job>`
  - Production: `https://mdmcheck.com/api/report?id=<job>`
  - Downloads the completed report.
- `GET /myip`
  - Local: `http://localhost:8787/myip`
  - Production: `https://mdmcheck.com/api/myip`
  - Returns IP geolocation and DNS leak data for the caller.
- `POST /archive`
  - Local: `http://localhost:8787/archive`
  - Production: `https://mdmcheck.com/api/archive`
  - Saves a URL to the Wayback Machine.
- `POST /subdomains`
  - Local: `http://localhost:8787/subdomains`
  - Production: `https://mdmcheck.com/api/subdomains`
  - Streams subdomain discovery results from `xsubfind3r`.

### Helper Scripts

Automation scripts such as [`scripts/run_notsofast.sh`](../scripts/run_notsofast.sh) invoke the
scanning pipeline locally. The `test_*.py` modules provide regression coverage
and demonstrate expected behaviors.

### Cloudflare Deployment

1. **Front-end (Cloudflare Pages)**
   - Run `make frontend-build` to compile the React app with Vite. Assets are emitted to `frontend/dist/`.
   - Deploy the contents of `frontend/dist/` along with static files such as `index.html`, `theme.css`, and `styles.css` via Cloudflare Pages.

2. **Back-end (Cloudflare Workers)**
   - Wrap the Python scanning logic in a Worker script that handles `/health`, `/check`, `/scan`, `/status`, and `/report` requests.
   - `wrangler.toml` at the repository root binds `SESSIONS` (KV) and `BUNDLES` (R2) and routes `mdmcheck.com/api/*` to `worker/src/index.ts`. The Worker uses bare paths without the `/api` prefix, so local development hits `http://localhost:8787/<endpoint>` while production clients call `https://mdmcheck.com/api/<endpoint>`.
   - Deploy with `npm --prefix worker run deploy` once your Cloudflare credentials and resource IDs are configured.

3. **Infrastructure**
   - Use Cloudflare Access or Turnstile for request protection.

This plan provides an organized foundation to finalize the MDMCheck website and deploy it on Cloudflare services, enabling investigators to run thorough checks and trust the unique results delivered by MDMCheck.

Adding new detection logic remains straightforward: dropping a module into `backend/checks/` immediately incorporates its findings and scores into the standard report, keeping the service extensible as threats evolve.

