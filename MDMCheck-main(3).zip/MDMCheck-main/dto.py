from pydantic import BaseModel, EmailStr
from typing import Optional

class ScanRequest(BaseModel):
    email: EmailStr
    include_evidence: bool = False

class ScanResponse(BaseModel):
    job: str

class StatusResponse(BaseModel):
    job: str
    state: str  # queued|running|done|error
    message: Optional[str] = None
