// All API requests go through the Worker under the `/api` route
const API_BASE = "/api";

export type CheckResult = {
  status: "ok" | "warn" | "risk";
  score: number;
  signals: { id: string; title: string; level: "info" | "warn" | "danger" }[];
  checkedAt: string;
};

export type DeepResult = {
  provider: string;
  score: number;
  tenant?: string;
  lastScan?: string;
  mdm: string[];
  rules: string[];
  hygiene: string[];
  recommendations: string[];
  __stale?: boolean;
};

export async function apiCheck(payload: { email?: string; domain?: string }): Promise<CheckResult> {
  const res = await fetch(`${API_BASE}/check`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ input: payload.email || payload.domain }),
  });
  if (!res.ok) throw new Error("Check failed");
  return res.json();
}

let lastGoodDeep: DeepResult | null = null;
export async function apiDeepCheck(payload: { providers: string[] }): Promise<DeepResult> {
  const res = await fetch(`${API_BASE}/deep`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Deep check failed");
  const data = (await res.json()) as DeepResult;
  lastGoodDeep = data;
  return data;
}

export async function apiDeepCheckResilient(payload: { providers: string[] }): Promise<DeepResult> {
  try {
    return await apiDeepCheck(payload);
  } catch (e) {
    if (lastGoodDeep) return { ...lastGoodDeep, __stale: true };
    throw e;
  }
}

export type MyIpResult = {
  ip: string;
  country?: string;
  dnsLeak?: boolean;
};

export async function apiMyIp(): Promise<MyIpResult> {
  const res = await fetch(`${API_BASE}/myip`);
  if (!res.ok) throw new Error("MyIP lookup failed");
  return res.json();
}

export async function apiArchive(url: string): Promise<{ saved: boolean }>
{
  const res = await fetch(`${API_BASE}/archive`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url }),
  });
  if (!res.ok) throw new Error("Archive request failed");
  return res.json();
}

export async function apiSubdomains(domain: string): Promise<{ subdomains: string[] }>
{
  const res = await fetch(`${API_BASE}/subdomains`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ domain }),
  });
  if (!res.ok) throw new Error("Subdomain lookup failed");
  return res.json();
}
