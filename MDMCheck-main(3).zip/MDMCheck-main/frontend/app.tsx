import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import QuickCheck from "./pages/QuickCheck";
import DeepResults from "./pages/DeepResults";
import MyIP from "./pages/MyIP";
import SavePageNow from "./pages/SavePageNow";
import Subdomains from "./pages/Subdomains";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/check" element={<QuickCheck />} />
        <Route path="/results" element={<DeepResults />} />
        <Route path="/myip" element={<MyIP />} />
        <Route path="/savepagenow" element={<SavePageNow />} />
        <Route path="/subdomains" element={<Subdomains />} />
      </Routes>
    </BrowserRouter>
  );
}

// Deep Results
function DeepResults() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<DeepResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    try {
      setLoading(true);
      setError(null);
      const res = await apiDeepCheckResilient({ providers: ["google"] });
      setData(res);
    } catch (e: any) {
      setError(e.message || "Failed to load deep results");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    run();
  }, []);

  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg center">Deep Results</h2>
        {data?.__stale && (
          <p className="mt-4 center warn small">Showing last known results (offline or retrying).</p>
        )}
        {loading && (
          <div className="mt-16 center-col gap-8 muted">
            <Icon.Spinner /> Running deep checks…
          </div>
        )}
        {error && <p className="mt-16 danger center">{error}</p>}
        {data && (
          <div className="stack gap-16 mt-16">
            <div className="card pad-16 br-xl shadow">
              <div className="row gap-12 center">
                <Icon.Shield />
                <div className="strong">Provider: {data.provider}</div>
              </div>
              <p className="muted small mt-8">Confidence Score: {data.score}%</p>
              {data.tenant && <p className="muted small">Tenant: {data.tenant}</p>}
              {data.lastScan && <p className="muted small">Last scan: {new Date(data.lastScan).toLocaleString()}</p>}
            </div>

            <SectionList title="MDM Indicators" items={data.mdm} empty="No MDM indicators detected." />
            <SectionList title="Suspicious Inbox Rules" items={data.rules} empty="No suspicious rules found." />
            <SectionList title="Security Hygiene" items={data.hygiene} empty="No hygiene issues found." />

            <div className="card pad-16 br-xl shadow">
              <div className="strong mb-8">Recommended Actions</div>
              {data.recommendations.length ? (
                <ul className="list">
                  {data.recommendations.map((r, i) => <li key={i}>{r}</li>)}
                </ul>
              ) : (
                <p className="muted small">No actions required.</p>
              )}
            </div>

            <div className="row between gap-12">
              <button className="btn primary" onClick={run}>Re-scan</button>
              <button className="btn" onClick={() => alert("PDF report stub")}>
                <Icon.Download /> Download PDF Report
              </button>
            </div>
          </div>
        )}
      </section>
    </Shell>
  );
}

function SectionList({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <div className="card pad-16 br-xl shadow">
      <div className="strong mb-8">{title}</div>
      {items.length ? (
        <ul className="list">
          {items.map((m, i) => <li key={i}>{m}</li>)}
        </ul>
      ) : (
        <p className="muted small">{empty}</p>
      )}
    </div>
  );
}

// Pricing
function Pricing() {
  const tiers = [
    {
      name: "Free",
      price: "$0",
      features: ["Quick email/domain check", "Basic MDM indicator scan", "Privacy-first"],
      cta: () => navigate("/"),
      ctaText: "Start free",
    },
    {
      name: "Pro",
      price: "$9/mo",
      features: [
        "Deep results via OAuth",
        "Suspicious inbox rules detection",
        "Security hygiene checks",
        "Downloadable PDF reports",
        "Priority re-scan access",
      ],
      cta: () => navigate("/signin"),
      ctaText: "Go Pro",
    },
    {
      name: "Team",
      price: "Contact us",
      features: ["Bulk domain checks", "Team dashboard", "Custom integrations", "Dedicated support"],
      cta: () => navigate("/contact"),
      ctaText: "Contact sales",
    },
  ];
  return (
    <Shell>
      <section className="container pad-24 center-col">
        <h2 className="title-lg">Pricing</h2>
        <p className="subtle mt-4">Simple, transparent plans to keep your accounts safe.</p>
        <div className="tiles-3 mt-24">
          {tiers.map((t) => (
            <div key={t.name} className="card pad-16 br-2xl shadow col gap-12">
              <div className="strong">{t.name}</div>
              <div className="price">{t.price}</div>
              <ul className="list small">
                {t.features.map((f) => <li key={f}>{f}</li>)}
              </ul>
              <button className="btn primary" onClick={t.cta}>{t.ctaText}</button>
            </div>
          ))}
        </div>
      </section>
    </Shell>
  );
}

// Billing
function Billing() {
  const [loading, setLoading] = useState(true);
  const [portalLoading, setPortalLoading] = useState(false);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        setError(null);
        await sleep(300);
        setData({
          plan: { name: "Pro", renewsAt: new Date(Date.now() + 27 * 864e5).toISOString() },
          invoices: [
            { id: "inv_001", date: new Date(Date.now() - 33 * 864e5).toISOString(), amount: 900, status: "paid", receiptUrl: "#" },
            { id: "inv_002", date: new Date(Date.now() - 3 * 864e5).toISOString(), amount: 900, status: "paid", receiptUrl: "#" },
          ],
        });
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg">Billing</h2>
        {loading && <div className="mt-12 muted row center gap-8"><Icon.Spinner /> Loading…</div>}
        {error && <p className="danger mt-12">{error}</p>}
        {data && (
          <div className="stack gap-16 mt-16">
            <div className="card pad-16 br-xl shadow">
              <div className="muted small">Current plan: {data.plan.name}</div>
              <p className="muted small">Renews on {new Date(data.plan.renewsAt).toLocaleDateString()}</p>
            </div>

            <div className="card pad-16 br-xl shadow">
              <div className="strong mb-8">Invoices</div>
              {data.invoices.length ? (
                <ul className="list small">
                  {data.invoices.map((inv: any) => (
                    <li key={inv.id} className="row between">
                      <span>{new Date(inv.date).toLocaleDateString()}</span>
                      <span className="row gap-8">
                        <span>${(inv.amount / 100).toFixed(2)}</span>
                        <a href={inv.receiptUrl} className="link">
                          Receipt
                        </a>
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="muted small">No invoices yet.</p>
              )}
            </div>

            <button
              className="btn"
              disabled={portalLoading}
              onClick={async () => {
                try {
                  setPortalLoading(true);
                  await sleep(300);
                  alert('Billing portal stub');
                } finally {
                  setPortalLoading(false);
                }
              }}
            >
              {portalLoading && <Icon.Spinner />} Manage billing
            </button>
          </div>
        )}
      </section>
    </Shell>
  );
}

// About
function About() {
  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg">About</h2>
        <p className="mt-4">About page coming soon.</p>
      </section>
    </Shell>
  );
}

// Terms
function Terms() {
  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg">Terms</h2>
        <p className="mt-4">Terms coming soon.</p>
      </section>
    </Shell>
  );
}

// Privacy
function Privacy() {
  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg">Privacy</h2>
        <p className="mt-4">Privacy policy coming soon.</p>
      </section>
    </Shell>
  );
}

// Sign in
function SignIn() {
  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg">Sign in</h2>
        <p className="mt-4">Sign-in flow coming soon.</p>
      </section>
    </Shell>
  );
}

// Account
function Account() {
  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg">Account</h2>
        <p className="mt-4">Account details coming soon.</p>
      </section>
    </Shell>
  );
}

// Status
function Status() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await apiStatus();
        setData(res);
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg">Status</h2>
        {loading && <div className="mt-12 muted row center gap-8"><Icon.Spinner /> Loading…</div>}
        {error && <p className="danger mt-12">{error}</p>}
        {data && (
          <div className="stack gap-8 mt-16">
            <div className="card pad-16 br-xl shadow">
              <div className="strong mb-8">Services</div>
              <ul className="list small">
                {data.services.map((s: any) => (
                  <li key={s.name} className="row between">
                    <span>{s.name}</span>
                    <span>{s.status}</span>
                  </li>
                ))}
              </ul>
            </div>
            <p className="muted small">Uptime: {data.uptime}%</p>
          </div>
        )}
      </section>
    </Shell>
  );
}

// Contact
function Contact() {
  return (
    <Shell>
      <section className="container pad-24">
        <h2 className="title-lg">Contact</h2>
        <p className="mt-4">Contact form coming soon.</p>
      </section>
    </Shell>
  );
}

function NotFound() {
  return (
    <Shell>
      <section className="container pad-24 center-col gap-16">
        <h2 className="title-lg">Page not found</h2>
        <button className="btn" onClick={() => navigate('/')}>Go home</button>
      </section>
    </Shell>
  );
}

function App() {
  const [route, setRoute] = useState<Route>(parseHash());

  useEffect(() => {
    const onHashChange = () => setRoute(parseHash());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  switch (route.name) {
    case 'home':
      return <Landing />;
    case 'check':
      return <QuickCheck email={route.email} domain={route.domain} />;
    case 'results':
      return <DeepResults />;
    case 'pricing':
      return <Pricing />;
    case 'billing':
      return <Billing />;
    case 'about':
      return <About />;
    case 'terms':
      return <Terms />;
    case 'privacy':
      return <Privacy />;
    case 'signin':
      return <SignIn />;
    case 'account':
      return <Account />;
    case 'status':
      return <Status />;
    case 'contact':
      return <Contact />;
    default:
      return <NotFound />;
  }
}

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(<App />);
}