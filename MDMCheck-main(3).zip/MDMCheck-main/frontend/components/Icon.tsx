import React from "react";

export const Icon = {
  Search: (p: any) => (
    <svg viewBox="0 0 24 24" width="1em" height="1em" {...p}>
      <path d="M21 21l-4.3-4.3M10 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  Check: (p: any) => (
    <svg viewBox="0 0 24 24" width="1em" height="1em" {...p}>
      <path d="M20 6L9 17l-5-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  Alert: (p: any) => (
    <svg viewBox="0 0 24 24" width="1em" height="1em" {...p}>
      <path d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  Info: (p: any) => (
    <svg viewBox="0 0 24 24" width="1em" height="1em" {...p}>
      <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M12 16v-4m0-4h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  Download: (p: any) => (
    <svg viewBox="0 0 24 24" width="1em" height="1em" {...p}>
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  Spinner: (p: any) => (
    <svg viewBox="0 0 50 50" width="1em" height="1em" className="spin" {...p}>
      <circle cx="25" cy="25" r="20" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeDasharray="31.4 31.4" />
    </svg>
  ),
  Shield: (p: any) => (
    <svg viewBox="0 0 24 24" width="1em" height="1em" {...p}>
      <path d="M12 22s8-3 8-10V5l-8-3-8 3v7c0 7 8 10 8 10z" fill="none" stroke="currentColor" strokeWidth="2" />
    </svg>
  ),
  Home: (p: any) => (
    <svg viewBox="0 0 24 24" width="1em" height="1em" {...p}>
      <path d="M3 10l9-7 9 7v10a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2V12H9v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" fill="none" stroke="currentColor" strokeWidth="2" />
    </svg>
  ),
};

export default Icon;
