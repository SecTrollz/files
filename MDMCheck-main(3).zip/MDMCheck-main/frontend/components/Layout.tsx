import React from "react";
import { NavLink, Link } from "react-router-dom";

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="app">
      <a href="#main" className="skip-link">Skip to content</a>
      <header className="header">
        <nav className="container row between center" aria-label="Primary">
          <Link className="brand link" to="/">MDMCheck</Link>
          <div className="row gap-24 nav-links">
            <NavLink className={({isActive}) => "link" + (isActive ? " active" : "")} to="/pricing">Pricing</NavLink>
            <NavLink className={({isActive}) => "link" + (isActive ? " active" : "")} to="/contact">Contact</NavLink>
            <NavLink className={({isActive}) => "link" + (isActive ? " active" : "")} to="/legal">Legal</NavLink>
            <Link className="btn ghost" to="/signin">Sign in</Link>
          </div>
        </nav>
      </header>
      <main className="main">{children}</main>
      <footer className="footer">
        <div className="container row between center wrap gap-12" aria-label="Footer">
          <p className="muted">© {new Date().getFullYear()} MDMCheck. All rights reserved.</p>
          <div className="row gap-16">
            <NavLink className={({isActive}) => "link" + (isActive ? " active" : "")} to="/contact">Contact</NavLink>
            <Link className="link" to="/legal#terms">Terms</Link>
            <NavLink className={({isActive}) => "link" + (isActive ? " active" : "")} to="/legal">Legal</NavLink>
            <Link className="link" to="/status">Status</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
