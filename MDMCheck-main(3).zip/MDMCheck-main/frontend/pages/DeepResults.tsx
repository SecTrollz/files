import React, { useEffect, useState } from "react";
import Layout from "../components/Layout";
import { Icon } from "../components/Icon";
import { apiDeepCheckResilient, DeepResult } from "../api";

export default function DeepResults() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<DeepResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    try {
      setLoading(true);
      setError(null);
      const res = await apiDeepCheckResilient({ providers: ["google"] });
      setData(res);
    } catch (e: any) {
      setError(e.message || "Failed to load deep results");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    run();
  }, []);

  return (
    <Layout>
      <section className="container pad-24">
        <h2 className="title-lg center">Deep Results</h2>
        {data?.__stale && <p className="mt-4 center warn small">Showing last known results (offline or retrying).</p>}
        {loading && (
          <div className="mt-16 center-col gap-8 muted">
            <Icon.Spinner /> Running deep checks…
          </div>
        )}
        {error && <p className="mt-16 danger center">{error}</p>}
        {data && (
          <div className="stack gap-16 mt-16">
            <div className="card pad-16 br-xl shadow" role="region" aria-label="Deep result summary">
              <div className="row gap-12 center">
                <Icon.Shield />
                <div className="strong">Provider: {data.provider}</div>
              </div>
              <p className="muted small mt-8">Confidence Score: {data.score}%</p>
              {data.tenant && <p className="muted small">Tenant: {data.tenant}</p>}
              {data.lastScan && <p className="muted small">Last scan: {new Date(data.lastScan).toLocaleString()}</p>}
            </div>

            <SectionList title="MDM Indicators" items={data.mdm} empty="No MDM indicators detected." />
            <SectionList title="Suspicious Inbox Rules" items={data.rules} empty="No suspicious rules found." />
            <SectionList title="Security Hygiene" items={data.hygiene} empty="No hygiene issues found." />

            <div className="card pad-16 br-xl shadow" role="region" aria-label="Deep result summary">
              <div className="strong mb-8">Recommended Actions</div>
              {data.recommendations.length ? (
                <ul className="list">
                  {data.recommendations.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              ) : (
                <p className="muted small">No actions required.</p>
              )}
            </div>

            <div className="row between gap-12">
              <button className="btn primary" onClick={run}>
                Re-scan
              </button>
              <button className="btn" onClick={() => alert("PDF report stub")}>
                <Icon.Download /> Download PDF Report
              </button>
            </div>
          </div>
        )}
      </section>
    </Layout>
  );
}

function SectionList({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <div className="card pad-16 br-xl shadow" role="region" aria-label="Deep result summary">
      <div className="strong mb-8">{title}</div>
      {items.length ? (
        <ul className="list">
          {items.map((m, i) => (
            <li key={i}>{m}</li>
          ))}
        </ul>
      ) : (
        <p className="muted small">{empty}</p>
      )}
    </div>
  );
}
