import { useState, useMemo, FormEvent } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import Layout from '@/components/Layout';

function isEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isDomain(value: string) {
  return /^(?!-)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,63}$/.test(value);
}

export default function Landing() {
  const router = useRouter();
  const [input, setInput] = useState('');
  const [touched, setTouched] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const trimmed = useMemo(() => input.trim().toLowerCase(), [input]);

  const validity: 'email' | 'domain' | 'invalid' | 'empty' = useMemo(() => {
    if (!trimmed) return 'empty';
    if (isEmail(trimmed)) return 'email';
    if (isDomain(trimmed)) return 'domain';
    return 'invalid';
  }, [trimmed]);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setTouched(true);
    
    if (validity === 'email' || validity === 'domain') {
      setIsLoading(true);
      // Small delay for better UX
      await new Promise(resolve => setTimeout(resolve, 800));
      
      if (validity === 'email') {
        router.push({
          pathname: '/results',
          query: { email: trimmed },
        });
      } else if (validity === 'domain') {
        router.push({
          pathname: '/results',
          query: { domain: trimmed },
        });
      }
      setIsLoading(false);
    }
  };

  const helperText = useMemo(() => {
    if (!touched) return 'Enter an email (name@domain.com) or a domain (example.com).';
    if (validity === 'empty') return 'Please enter an email or a domain.';
    if (validity === 'invalid') return 'That doesn’t look like a valid email or domain.';
    if (validity === 'email') return 'We’ll check signals for this email.';
    if (validity === 'domain') return 'We’ll check signals for this domain.';
    return '';
  }, [touched, validity]);

  const isCTAEnabled = (validity === 'email' || validity === 'domain') && !isLoading;

  return (
    <Layout>
      <Head>
        <title>MDMCheck — Device Management Detection</title>
        <meta
          name="description"
          content="Check whether an email or domain shows signs of Mobile Device Management (MDM) control and understand the reasoning."
        />
      </Head>

      {/* Enhanced Hero Section */}
      <section className="hero">
        <div className="hero-background">
          <div className="hero-gradient"></div>
        </div>
        <div className="container">
          <div className="hero-content">
            <div className="hero-text">
              <h1 className="hero-title">
                Know if a device is managed 
                <span className="title-accent">— and why</span>
              </h1>
              <p className="hero-subtitle">
                Check email addresses or domains for MDM enrollment signals. Get clear, 
                actionable results with detailed explanations.
              </p>

              <form onSubmit={handleSubmit} className="search-form" aria-label="MDM check form">
                <div className="input-wrapper">
                  <input
                    id="mdm-input"
                    type="text"
                    inputMode="email"
                    autoComplete="off"
                    placeholder="name@company.com  •  company.com"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onBlur={() => setTouched(true)}
                    aria-invalid={touched && validity === 'invalid'}
                    aria-describedby="helper"
                    className="search-input"
                    disabled={isLoading}
                  />
                  <button
                    type="submit"
                    className="search-button"
                    disabled={!isCTAEnabled}
                    aria-disabled={!isCTAEnabled}
                  >
                    {isLoading ? (
                      <span className="button-loading">
                        <span className="spinner"></span>
                        Checking...
                      </span>
                    ) : (
                      'Check Now'
                    )}
                  </button>
                </div>
                <p id="helper" className={`helper ${touched && validity === 'invalid' ? 'error' : ''}`}>
                  {helperText}
                </p>
              </form>

              <div className="quick-examples">
                <span className="quick-label">Try examples:</span>
                <button
                  type="button"
                  className="quick-chip"
                  onClick={() => setInput('alex@example.com')}
                  disabled={isLoading}
                >
                  alex@example.com
                </button>
                <button
                  type="button"
                  className="quick-chip"
                  onClick={() => setInput('contoso.com')}
                  disabled={isLoading}
                >
                  contoso.com
                </button>
              </div>
            </div>

            <div className="hero-visual">
              <div className="visual-card">
                <div className="card-content">
                  <div className="stat-row">
                    <div className="stat-item">
                      <div className="stat-icon">🔒</div>
                      <div className="stat-text">
                        <h4>Private by design</h4>
                        <p>Minimal collection. No intrusive prompts.</p>
                      </div>
                    </div>
                    <div className="stat-item">
                      <div className="stat-icon">📊</div>
                      <div className="stat-text">
                        <h4>Explainable result</h4>
                        <p>Signals are scored and described in plain language.</p>
                      </div>
                    </div>
                    <div className="stat-item">
                      <div className="stat-icon">🎯</div>
                      <div className="stat-text">
                        <h4>Actionable guidance</h4>
                        <p>Clear next steps whether managed or not.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="section how-it-works">
        <div className="container">
          <div className="section-header">
            <h2>How MDMCheck works</h2>
            <p>Our three-step process delivers clear, actionable insights</p>
          </div>
          <div className="process-steps">
            <div className="step-card">
              <div className="step-number">1</div>
              <div className="step-content">
                <h3>Gather signals</h3>
                <p>Client session and backend endpoints compile non-invasive indicators across account, environment, and network.</p>
              </div>
            </div>
            <div className="step-card">
              <div className="step-number">2</div>
              <div className="step-content">
                <h3>Score and explain</h3>
                <p>We weigh signal quality to reach a verdict: <strong>Managed</strong>, <strong>Unmanaged</strong>, or <strong>Inconclusive</strong>, with reasons.</p>
              </div>
            </div>
            <div className="step-card">
              <div className="step-number">3</div>
              <div className="step-content">
                <h3>Act with confidence</h3>
                <p>Follow tailored guidance—verification steps, remediation, or enrollment confirmation—depending on the result.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section features">
        <div className="container">
          <div className="section-header">
            <h2>Why choose MDMCheck</h2>
            <p>Comprehensive device management detection with transparency</p>
          </div>
          <div className="features-grid">
            <div className="feature">
              <div className="feature-icon">🛡️</div>
              <h3>Security Focused</h3>
              <p>We prioritize your privacy and data security with minimal collection and clear retention policies.</p>
            </div>
            <div className="feature">
              <div className="feature-icon">⚡</div>
              <h3>Instant Results</h3>
              <p>Get answers in seconds, not days. Our optimized process delivers rapid insights.</p>
            </div>
            <div className="feature">
              <div className="feature-icon">🔍</div>
              <h3>Deep Analysis</h3>
              <p>We examine multiple signal sources for comprehensive device management detection.</p>
            </div>
            <div className="feature">
              <div className="feature-icon">💡</div>
              <h3>Clear Explanations</h3>
              <p>Understand not just the result, but the reasoning behind it with plain-language insights.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section cta">
        <div className="container">
          <div className="cta-content">
            <h2>Ready to check your MDM status?</h2>
            <p>Enter an email or domain above to get started</p>
            <button 
              className="cta-button"
              onClick={() => document.getElementById('mdm-input')?.focus()}
            >
              Start Checking
            </button>
          </div>
        </div>
      </section>

      <style jsx>{`
        /* Layout primitives */
        .container {
          width: min(1200px, 92vw);
          margin: 0 auto;
        }
        
        .section {
          padding: 5rem 0;
        }
        
        .section-header {
          text-align: center;
          margin-bottom: 3rem;
        }
        
        .section-header h2 {
          font-size: 2.5rem;
          font-weight: 700;
          letter-spacing: -0.02em;
          margin-bottom: 1rem;
        }
        
        .section-header p {
          font-size: 1.2rem;
          color: #64748b;
          max-width: 600px;
          margin: 0 auto;
        }

        /* Enhanced Hero */
        .hero {
          position: relative;
          padding: 6rem 0 5rem;
          overflow: hidden;
        }
        
        .hero-background {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: -1;
        }
        
        .hero-gradient {
          position: absolute;
          top: -20%;
          left: -10%;
          right: -10%;
          height: 70%;
          background: radial-gradient(ellipse at center, rgba(99, 102, 241, 0.15) 0%, rgba(99, 102, 241, 0) 70%);
        }
        
        .hero-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 4rem;
          align-items: center;
        }
        
        .hero-title {
          font-size: clamp(2.5rem, 5vw, 3.5rem);
          font-weight: 800;
          line-height: 1.1;
          letter-spacing: -0.02em;
          margin-bottom: 1.5rem;
          color: #0f172a;
        }
        
        .title-accent {
          color: #6366f1;
          display: block;
        }
        
        .hero-subtitle {
          font-size: 1.25rem;
          line-height: 1.6;
          color: #475569;
          margin-bottom: 2.5rem;
          max-width: 90%;
        }
        
        .search-form {
          margin-bottom: 1.5rem;
        }
        
        .input-wrapper {
          display: flex;
          background: white;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.04);
          overflow: hidden;
          transition: all 0.2s ease;
        }
        
        .input-wrapper:focus-within {
          box-shadow: 0 6px 25px rgba(99, 102, 241, 0.15), 0 0 0 2px rgba(99, 102, 241, 0.5);
          transform: translateY(-2px);
        }
        
        .search-input {
          flex: 1;
          padding: 1.25rem 1.5rem;
          border: none;
          font-size: 1.1rem;
          outline: none;
          background: transparent;
        }
        
        .search-input::placeholder {
          color: #94a3b8;
        }
        
        .search-button {
          padding: 0 2rem;
          background: #6366f1;
          color: white;
          border: none;
          font-weight: 600;
          font-size: 1rem;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        
        .search-button:hover:not(:disabled) {
          background: #4f46e5;
        }
        
        .search-button:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        
        .button-loading {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .spinner {
          width: 16px;
          height: 16px;
          border: 2px solid transparent;
          border-top: 2px solid white;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        .helper {
          margin-top: 0.75rem;
          font-size: 0.9rem;
          color: #64748b;
        }
        
        .helper.error {
          color: #ef4444;
          background: rgba(239, 68, 68, 0.08);
          padding: 0.5rem 0.75rem;
          border-radius: 6px;
          display: inline-block;
        }
        
        .quick-examples {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          flex-wrap: wrap;
        }
        
        .quick-label {
          font-size: 0.9rem;
          color: #64748b;
        }
        
        .quick-chip {
          background: white;
          color: #6366f1;
          border: 1px solid #e2e8f0;
          border-radius: 20px;
          padding: 0.5rem 1rem;
          font-size: 0.9rem;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        
        .quick-chip:hover:not(:disabled) {
          background: #f1f5f9;
          border-color: #cbd5e1;
        }
        
        .quick-chip:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        
        .hero-visual {
          display: flex;
          justify-content: center;
        }
        
        .visual-card {
          background: white;
          border-radius: 16px;
          padding: 2rem;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
          width: 100%;
          max-width: 400px;
        }
        
        .stat-row {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        .stat-item {
          display: flex;
          align-items: flex-start;
          gap: 1rem;
        }
        
        .stat-icon {
          font-size: 1.5rem;
          flex-shrink: 0;
        }
        
        .stat-text h4 {
          margin: 0 0 0.25rem;
          font-weight: 600;
          color: #0f172a;
        }
        
        .stat-text p {
          margin: 0;
          color: #64748b;
          font-size: 0.9rem;
          line-height: 1.5;
        }

        /* How it works */
        .how-it-works {
          background: #f8fafc;
        }
        
        .process-steps {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
        }
        
        .step-card {
          background: white;
          border-radius: 16px;
          padding: 2rem;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          position: relative;
          overflow: hidden;
        }
        
        .step-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .step-number {
          position: absolute;
          top: -15px;
          right: -15px;
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: #6366f1;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
          font-weight: 700;
          opacity: 0.1;
        }
        
        .step-content h3 {
          font-size: 1.25rem;
          font-weight: 600;
          margin: 0 0 1rem;
          color: #0f172a;
        }
        
        .step-content p {
          color: #64748b;
          line-height: 1.6;
          margin: 0;
        }

        /* Features */
        .features-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
        }
        
        .feature {
          text-align: center;
          padding: 2rem 1.5rem;
          border-radius: 12px;
          background: white;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
          transition: transform 0.2s ease;
        }
        
        .feature:hover {
          transform: translateY(-5px);
        }
        
        .feature-icon {
          font-size: 2.5rem;
          margin-bottom: 1rem;
        }
        
        .feature h3 {
          font-size: 1.25rem;
          font-weight: 600;
          margin: 0 0 1rem;
          color: #0f172a;
        }
        
        .feature p {
          color: #64748b;
          line-height: 1.6;
          margin: 0;
        }

        /* CTA */
        .cta {
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          color: white;
          text-align: center;
        }
        
        .cta-content h2 {
          font-size: 2.5rem;
          font-weight: 700;
          margin: 0 0 1rem;
        }
        
        .cta-content p {
          font-size: 1.2rem;
          margin: 0 0 2rem;
          opacity: 0.9;
        }
        
        .cta-button {
          background: white;
          color: #6366f1;
          border: none;
          padding: 1rem 2.5rem;
          border-radius: 50px;
          font-size: 1.1rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .cta-button:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 25px rgba(0, 0, 0, 0.2);
        }

        /* Responsive */
        @media (max-width: 900px) {
          .hero-content {
            grid-template-columns: 1fr;
            gap: 3rem;
          }
          
          .hero-subtitle {
            max-width: 100%;
          }
          
          .input-wrapper {
            flex-direction: column;
          }
          
          .search-button {
            padding: 1rem;
          }
          
          .visual-card {
            max-width: 100%;
          }
        }
        
        @media (max-width: 600px) {
          .section {
            padding: 3rem 0;
          }
          
          .section-header h2 {
            font-size: 2rem;
          }
          
          .hero {
            padding: 4rem 0 3rem;
          }
          
          .hero-title {
            font-size: 2.2rem;
          }
          
          .hero-subtitle {
            font-size: 1.1rem;
          }
          
          .quick-examples {
            flex-direction: column;
            align-items: flex-start;
          }
          
          .cta-content h2 {
            font-size: 2rem;
          }
        }
      `}</style>
    </Layout>
  );
}
