import React, { useEffect, useState } from "react";
import Layout from "../components/Layout";
import { apiMyIp, MyIpResult } from "../api";

export default function MyIP() {
  const [data, setData] = useState<MyIpResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        setData(await apiMyIp());
      } catch (e: any) {
        setError(e.message || "Lookup failed");
      }
    })();
  }, []);

  return (
    <Layout>
      <section className="container center-col pad-24">
        <h2 className="title-lg">My IP</h2>
        {error && <p className="mt-16 danger">{error}</p>}
        {data && (
          <div className="mt-16 center-col gap-8">
            <p>IP: {data.ip}</p>
            {data.country && <p>Country: {data.country}</p>}
            {data.dnsLeak !== undefined && (
              <p>DNS Leak: {data.dnsLeak ? "Yes" : "No"}</p>
            )}
          </div>
        )}
      </section>
    </Layout>
  );
}
