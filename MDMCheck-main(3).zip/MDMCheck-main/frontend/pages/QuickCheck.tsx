import React, { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import Layout from "../components/Layout";
import { Icon } from "../components/Icon";
import { apiCheck, CheckResult } from "../api";

export default function QuickCheck() {
  const [searchParams] = useSearchParams();
  const email = searchParams.get("email") || undefined;
  const domain = searchParams.get("domain") || undefined;

  const [loading, setLoading] = useState(true);
  const [result, setResult] = useState<CheckResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        setError(null);
        setResult(null);
        const data = await apiCheck({ email, domain });
        if (mounted) setResult(data);
      } catch (e: any) {
        if (mounted) setError(e.message || "Scan failed");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [email, domain]);

  return (
    <Layout>
      <section className="container center-col pad-24">
        <h2 className="title-lg">Quick Check Results</h2>
        {loading && (
          <div className="mt-16 center-col gap-8 muted">
            <Icon.Spinner /> Scanning…
          </div>
        )}
        {error && <p className="mt-16 danger">{error}</p>}
        {result && (
          <div className="card br-xl shadow pad-16 mt-16 center-col gap-8">
            {result.status === "ok" ? (
              <>
                <div className="status success"><Icon.Check /> No indicators found</div>
                <p className="muted">Confidence Score: {result.score}%</p>
              </>
            ) : result.status === "warn" ? (
              <>
                <div className="status warn"><Icon.Info /> Potential indicators worth reviewing</div>
                <p className="muted">Confidence Score: {result.score}%</p>
              </>
            ) : (
              <>
                <div className="status danger"><Icon.Alert /> Potential indicators found</div>
                <p className="muted">Confidence Score: {result.score}%</p>
                <Link className="btn primary" to="/results">Connect account for deeper checks</Link>
              </>
            )}

            <div className="grid-2 mt-12 gap-12">
              {result.signals.map((s) => (
                <div key={s.id} className={`tile ${s.level}`}>
                  <div className="tile-title">{s.title}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </Layout>
  );
}
