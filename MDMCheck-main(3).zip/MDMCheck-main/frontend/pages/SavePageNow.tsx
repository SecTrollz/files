import React, { useState } from "react";
import Layout from "../components/Layout";
import { apiArchive } from "../api";

export default function SavePageNow() {
  const [url, setUrl] = useState("");
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus(null);
    setError(null);
    try {
      await apiArchive(url);
      setStatus("Saved to Wayback Machine");
    } catch (e: any) {
      setError(e.message || "Archive failed");
    }
  };

  return (
    <Layout>
      <section className="container center-col pad-24">
        <h2 className="title-lg">Save Page Now</h2>
        <form onSubmit={onSubmit} className="mt-16 center-col gap-12">
          <input
            className="input"
            type="url"
            placeholder="https://example.com"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            required
          />
          <button className="btn primary" type="submit">
            Archive
          </button>
        </form>
        {status && <p className="mt-12 success">{status}</p>}
        {error && <p className="mt-12 danger">{error}</p>}
      </section>
    </Layout>
  );
}
