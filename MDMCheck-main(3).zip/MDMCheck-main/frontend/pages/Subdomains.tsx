import React, { useState } from "react";
import Layout from "../components/Layout";
import { apiSubdomains } from "../api";

export default function Subdomains() {
  const [domain, setDomain] = useState("");
  const [subs, setSubs] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSubs([]);
    try {
      const res = await apiSubdomains(domain);
      setSubs(res.subdomains);
    } catch (e: any) {
      setError(e.message || "Lookup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <section className="container center-col pad-24">
        <h2 className="title-lg">Subdomain Finder</h2>
        <form onSubmit={onSubmit} className="mt-16 center-col gap-12">
          <input
            className="input"
            type="text"
            placeholder="example.com"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            required
          />
          <button className="btn primary" type="submit" disabled={loading}>
            {loading ? "Searching…" : "Find"}
          </button>
        </form>
        {error && <p className="mt-12 danger">{error}</p>}
        {subs.length > 0 && (
          <ul className="mt-12 list-disc">
            {subs.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ul>
        )}
      </section>
    </Layout>
  );
}
