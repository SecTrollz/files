import Link from "next/link";

export default function AccountPage() {
  return (
    <section className="mx-auto max-w-3xl py-16">
      <h2 className="text-3xl font-bold">Account</h2>
      <p className="mt-4">Manage your profile and subscriptions here.</p>
      <p className="mt-8 text-sm text-muted-foreground">
        Need to update billing? <Link href="/billing" className="underline">Go to billing</Link>.
      </p>
    </section>
  );
}
