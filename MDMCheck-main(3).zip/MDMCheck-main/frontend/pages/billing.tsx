export default function BillingPage() {
  return (
    <section className="mx-auto max-w-3xl py-16">
      <h2 className="text-3xl font-bold">Billing</h2>
      <p className="mt-4">Billing portal coming soon.</p>
    </section>
  );
}
