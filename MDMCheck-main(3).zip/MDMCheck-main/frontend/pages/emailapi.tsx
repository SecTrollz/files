// app/api/contact/route.ts
import { z } from "zod";

// Simple in-memory rate limit per IP (dev/demo only)
const WINDOW_MS = 60_000; // 1 minute
const MAX_REQ = 5;
const bucket = new Map<string, { count: number; reset: number }>();

const ContactSchema = z.object({
  name: z.string().trim().min(1).max(120),
  email: z.string().trim().email().max(254),
  message: z.string().trim().min(1).max(5000),
});

function rateLimit(ip: string) {
  const now = Date.now();
  const rec = bucket.get(ip);
  if (!rec || now > rec.reset) {
    bucket.set(ip, { count: 1, reset: now + WINDOW_MS });
    return true;
  }
  if (rec.count >= MAX_REQ) return false;
  rec.count += 1;
  return true;
}

export default {
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    if (request.method !== "POST" || url.pathname !== "/api/contact") {
      return new Response("Not found", { status: 404 });
    }

    try {
      const ip =
        (request.headers.get("x-forwarded-for") || "")
          .split(",")[0]
          .trim() ||
        request.headers.get("x-real-ip") ||
        "unknown";

      if (!rateLimit(ip)) {
        return new Response(
          JSON.stringify({
            error: {
              code: "RATE_LIMITED",
              message: "Too many requests. Please try again shortly.",
            },
          }),
          {
            status: 429,
            headers: { "content-type": "application/json" },
          }
        );
      }

      const body = await request.json().catch(() => ({}));
      const parsed = ContactSchema.safeParse(body);
      if (!parsed.success) {
        return new Response(
          JSON.stringify({
            error: {
              code: "INVALID_INPUT",
              message: "Please check the form fields.",
              issues: parsed.error.issues.map((i) => ({
                path: i.path,
                message: i.message,
              })),
            },
          }),
          {
            status: 400,
            headers: { "content-type": "application/json" },
          }
        );
      }

      const { name, email, message } = parsed.data;
      console.log("[CONTACT] incoming", { ip, name, email, message });

      return new Response(
        JSON.stringify({ ok: true, receivedAt: new Date().toISOString() }),
        { headers: { "content-type": "application/json" } }
      );
    } catch (e: any) {
      return new Response(
        JSON.stringify({
          error: {
            code: "SERVER_ERROR",
            message: e?.message || "Unexpected error",
          },
        }),
        { status: 500, headers: { "content-type": "application/json" } }
      );
    }
  },
};
