import { Inter } from "next/font/google"; import "./globals.css"; import { cn } from "@/lib/utils"; import Link from "next/link";

const inter = Inter({ subsets: ["latin"] });

export const metadata = { title: "MDMCheck – Contact", description: "Get in touch with the MDMCheck team for support, feedback, or partnerships.", };

function Header() { return ( <header className="border-b border-border bg-background"> <nav className="mx-auto flex max-w-7xl items-center justify-between p-4"> <Link href="/" className="text-xl font-bold"> MDMCheck </Link> <div className="flex gap-6"> <Link href="/pricing">Pricing</Link> <Link href="/about">About</Link> <Link href="/legal/privacy">Privacy</Link> <Link href="/status">Status</Link> </div> </nav> </header> ); }

function Footer() { return ( <footer className="border-t border-border bg-background"> <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 p-6 text-sm text-muted-foreground md:flex-row"> <p>© {new Date().getFullYear()} MDMCheck. All rights reserved.</p> <div className="flex gap-6"> <Link href="/about">About</Link> <Link href="/legal/terms">Terms</Link> <Link href="/legal/privacy">Privacy</Link> <Link href="/status">Status</Link> </div> </div> </footer> ); }

function ContactPage() { async function handleSubmit(e: React.FormEvent<HTMLFormElement>) { e.preventDefault(); const form = e.currentTarget; const formData = new FormData(form); const payload = Object.fromEntries(formData.entries());

try {
  const res = await fetch("/api/contact", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const json = await res.json();
  if (!res.ok || json.error) throw new Error(json.error?.message || "Failed to send message");
  alert("Message sent successfully!");
  form.reset();
} catch (err: any) {
  alert(err.message);
}

}

return ( <section className="mx-auto max-w-2xl py-16"> <h2 className="text-3xl font-bold text-center">Contact Us</h2> <p className="mt-4 text-center text-muted-foreground"> Questions, issues, or ideas? We’d love to hear from you. </p>

<form onSubmit={handleSubmit} className="mt-8 space-y-4">
    <div>
      <label htmlFor="name" className="block text-sm font-medium">
        Name
      </label>
      <input
        id="name"
        name="name"
        type="text"
        required
        className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2"
      />
    </div>
    <div>
      <label htmlFor="email" className="block text-sm font-medium">
        Email
      </label>
      <input
        id="email"
        name="email"
        type="email"
        required
        className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2"
      />
    </div>
    <div>
      <label htmlFor="message" className="block text-sm font-medium">
        Message
      </label>
      <textarea
        id="message"
        name="message"
        rows={4}
        required
        className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2"
      />
    </div>
    <button
      type="submit"
      className="w-full rounded-lg bg-primary px-4 py-2 font-medium text-primary-foreground hover:bg-primary/90"
    >
      Send message
    </button>
  </form>

  <div className="mt-12 text-center text-sm text-muted-foreground">
    <p>You can also reach us directly at</p>
    <a
      href="mailto:contact@mdmcheck.com"
      className="text-primary hover:underline"
    >
      contact@mdmcheck.com
    </a>
  </div>
</section>

); }

export default function ContactLayout({ children, }: { children: React.ReactNode; }) { return ( <html lang="en" suppressHydrationWarning> <body className={cn( "min-h-screen bg-background font-sans antialiased flex flex-col", inter.className )} > <Header /> <main className="flex-1"> <ContactPage /> {children} </main> <Footer /> </body> </html> ); }

