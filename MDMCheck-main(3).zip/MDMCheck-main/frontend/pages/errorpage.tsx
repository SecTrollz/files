.// app/error.tsx
"use client";

import Link from "next/link";
import { TriangleAlert, RotateCw, Home } from "lucide-react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <section className="mx-auto flex max-w-2xl flex-col items-center justify-center py-32 text-center">
      <TriangleAlert className="h-12 w-12 text-amber-500" />
      <h1 className="mt-4 text-3xl font-semibold">Something went wrong</h1>
      <p className="mt-2 text-muted-foreground">
        An unexpected error occurred while loading this page.
      </p>
      {error?.digest ? (
        <p className="mt-2 text-xs text-muted-foreground">
          Error ID: <span className="font-mono">{error.digest}</span>
        </p>
      ) : null}
      <div className="mt-6 flex items-center gap-3">
        <button
          onClick={() => reset()}
          className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 font-medium text-primary-foreground hover:bg-primary/90"
        >
          <RotateCw className="h-4 w-4" />
          Try again
        </button>
        <Link
          href="/"
          className="inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2 font-medium hover:bg-accent"
        >
          <Home className="h-4 w-4" />
          Go home
        </Link>
      </div>
    </section>
  );
}
