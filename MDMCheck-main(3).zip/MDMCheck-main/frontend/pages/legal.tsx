import React from "react";
import Layout from "../components/Layout";

export default function Legal() {
  return (
    <Layout>
      <section className="container pad-24">
        <h1 className="title-lg">Legal</h1>
        <p className="subtle mt-12 max-720">
          These terms are meant to be clear and respectful of your rights. Please read them carefully.
        </p>

        <div className="stack mt-24 max-720">
          <div id="terms" className="stack">
            <h2 className="title-md">Terms & Conditions</h2>
            <p className="muted">
              By using MDMCheck, you agree to use it only for lawful purposes and in a way that doesn’t infringe the rights of
              others. We provide our service “as is,” without warranties of any kind. We are not liable for any damages arising
              from your use of the site. You are responsible for maintaining the confidentiality of your account and any
              activity that occurs under it.
            </p>
          </div>

          <div id="privacy" className="stack">
            <h2 className="title-md">Privacy Policy</h2>
            <p className="muted">
              Privacy is at the core of MDMCheck. We minimize personal data collected: quick checks process only the email or
              domain entered, and deep checks analyze metadata returned from providers after your explicit consent. We never
              store message content. You can delete your data or revoke provider access at any time. Analytics are optional and
              loaded only after consent.
            </p>
            <p className="muted">
              Last updated: {new Date().toLocaleDateString()}. For a full copy of this policy, or to request a PDF, contact us
              at <a href="mailto:legal@mdmcheck.com" className="link">legal@mdmcheck.com</a>.
            </p>
          </div>
        </div>
      </section>
    </Layout>
  );
}

