import { Inter } from "next/font/google"; import "./globals.css"; import { cn } from "@/lib/utils"; import Link from "next/link"; import { Loader2, User, Server, ListChecks, RefreshCw, Download, ShieldAlert, ShieldCheck, } from "lucide-react"; import { useState, useEffect } from "react";

const inter = Inter({ subsets: ["latin"] });

export const metadata = { title: "MDMCheck – Deep Results", description: "View enriched analysis of your account: MDM enrollment artifacts, risky inbox rules, and account hygiene.", };

function Header() { return ( <header className="border-b border-border bg-background"> <nav className="mx-auto flex max-w-7xl items-center justify-between p-4"> <Link href="/" className="text-xl font-bold"> MDMCheck </Link> <div className="flex gap-6"> <Link href="/pricing">Pricing</Link> <Link href="/about">About</Link> <Link href="/legal/privacy">Privacy</Link> <Link href="/signin">Sign in</Link> </div> </nav> </header> ); }

function Footer() { return ( <footer className="border-t border-border bg-background"> <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 p-6 text-sm text-muted-foreground md:flex-row"> <p>© {new Date().getFullYear()} MDMCheck. All rights reserved.</p> <div className="flex gap-6"> <Link href="/about">About</Link> <Link href="/legal/terms">Terms</Link> <Link href="/legal/privacy">Privacy</Link> <Link href="/status">Status</Link> </div> </div> </footer> ); }

function DeepResultsPage() { const [loading, setLoading] = useState(true); const [data, setData] = useState<any>(null);

useEffect(() => { // Simulated API call – here we would fetch from /api/deep-check const timer = setTimeout(() => { setData({ provider: "Google", score: 42, mdm: [ "Enrollment artifact detected: device enrolled via MDM", "Configuration profile present (mobileconfig)", ], rules: [ "Auto-forwarding enabled to external domain", "Suspicious filtering rule: forwards to attacker@example.com", ], hygiene: [ "2FA disabled", "Recovery email outdated", "Weak password reset questions", ], recommendations: [ "Disable auto-forwarding rules you don't recognize", "Enable 2FA on this account", "Update recovery information", "Review device list in your account security settings", ], }); setLoading(false); }, 1500);

return () => clearTimeout(timer);

}, []);

return ( <section className="mx-auto max-w-4xl py-16"> <h2 className="text-3xl font-bold text-center">Deep Results</h2> {loading && ( <div className="mt-6 flex flex-col items-center gap-2 text-center"> <Loader2 className="h-6 w-6 animate-spin" /> <p className="text-muted-foreground">Running deep checks…</p> </div> )} {data && ( <div className="mt-8 space-y-8"> {/* Account overview */} <div className="rounded-xl border border-border bg-card p-6 shadow-sm"> <div className="flex items-center gap-3"> <User className="h-5 w-5 text-muted-foreground" /> <p className="font-medium">Provider: {data.provider}</p> </div> <p className="mt-2 text-sm text-muted-foreground"> Confidence Score: {data.score}% </p> </div>

{/* MDM Indicators */}
      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          <Server className="h-5 w-5 text-muted-foreground" />
          <p className="font-medium">MDM Indicators</p>
        </div>
        <ul className="list-disc pl-6 text-sm text-muted-foreground">
          {data.mdm.map((m: string, i: number) => (
            <li key={i}>{m}</li>
          ))}
        </ul>
      </div>

      {/* Suspicious Rules */}
      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          <ListChecks className="h-5 w-5 text-muted-foreground" />
          <p className="font-medium">Suspicious Inbox Rules</p>
        </div>
        <ul className="list-disc pl-6 text-sm text-muted-foreground">
          {data.rules.map((r: string, i: number) => (
            <li key={i}>{r}</li>
          ))}
        </ul>
      </div>

      {/* Security Hygiene */}
      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          {data.hygiene.length ? (
            <ShieldAlert className="h-5 w-5 text-rose-500" />
          ) : (
            <ShieldCheck className="h-5 w-5 text-emerald-500" />
          )}
          <p className="font-medium">Security Hygiene</p>
        </div>
        <ul className="list-disc pl-6 text-sm text-muted-foreground">
          {data.hygiene.map((h: string, i: number) => (
            <li key={i}>{h}</li>
          ))}
        </ul>
      </div>

      {/* Recommendations */}
      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <p className="font-medium mb-2">Recommended Actions</p>
        <ul className="list-disc pl-6 text-sm text-muted-foreground">
          {data.recommendations.map((rec: string, i: number) => (
            <li key={i}>{rec}</li>
          ))}
        </ul>
      </div>

      {/* Actions */}
      <div className="flex justify-between gap-4">
        <button className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 font-medium text-primary-foreground hover:bg-primary/90">
          <RefreshCw className="h-4 w-4" /> Re-scan
        </button>
        <button className="flex items-center gap-2 rounded-lg border border-border px-4 py-2 font-medium hover:bg-accent">
          <Download className="h-4 w-4" /> Download PDF Report
        </button>
      </div>
    </div>
  )}
</section>

); }

export default function DeepResultsLayout({ children, }: { children: React.ReactNode; }) { return ( <html lang="en" suppressHydrationWarning> <body className={cn( "min-h-screen bg-background font-sans antialiased flex flex-col", inter.className )} > <Header /> <main className="flex-1"> <DeepResultsPage /> {children} </main> <Footer /> </body> </html> ); }

