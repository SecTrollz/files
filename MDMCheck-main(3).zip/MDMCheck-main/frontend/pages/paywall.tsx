import Link from "next/link";

export default function PaywallPage() {
  return (
    <section className="mx-auto max-w-md py-24 text-center">
      <h2 className="text-3xl font-bold">Upgrade Required</h2>
      <p className="mt-4">Subscribe to unlock full reports and PDF downloads.</p>

      <ul className="mt-8 list-disc text-left pl-6">
        <li>Unredacted evidence for every enrollment</li>
        <li>Detailed timeline and provider attribution</li>
        <li>Downloadable, shareable PDF reports</li>
      </ul>

      <div className="mt-10 flex justify-center gap-4">
        <Link href="/billing" className="btn primary">View Plans</Link>
        <Link href="/account" className="btn">Sign in</Link>
      </div>

      <p className="mt-6 text-sm text-muted-foreground">
        One click to reclaim your privacy. Cancel anytime.
      </p>
    </section>
  );
}
