import { Inter } from "next/font/google"; import "./globals.css"; import { cn } from "@/lib/utils"; import Link from "next/link"; import { Loader2, User, Server, ListChecks, RefreshCw, Download, ShieldAlert, ShieldCheck, } from "lucide-react"; import { useState, useEffect } from "react";

const inter = Inter({ subsets: ["latin"] });

export const metadata = { title: "MDMCheck – Pricing", description: "Compare free and pro plans for MDMCheck: quick checks, deep results, and team options.", };

function Header() { return ( <header className="border-b border-border bg-background"> <nav className="mx-auto flex max-w-7xl items-center justify-between p-4"> <Link href="/" className="text-xl font-bold"> MDMCheck </Link> <div className="flex gap-6"> <Link href="/pricing">Pricing</Link> <Link href="/about">About</Link> <Link href="/legal/privacy">Privacy</Link> <Link href="/signin">Sign in</Link> </div> </nav> </header> ); }

function Footer() { return ( <footer className="border-t border-border bg-background"> <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 p-6 text-sm text-muted-foreground md:flex-row"> <p>© {new Date().getFullYear()} MDMCheck. All rights reserved.</p> <div className="flex gap-6"> <Link href="/about">About</Link> <Link href="/legal/terms">Terms</Link> <Link href="/legal/privacy">Privacy</Link> <Link href="/status">Status</Link> </div> </div> </footer> ); }

function PricingPage() { const tiers = [ { name: "Free", price: "$0", features: [ "Quick email/domain check", "Basic MDM indicator scan", "Privacy-first, no tracking", ], cta: "Start free", href: "/check", }, { name: "Pro", price: "$9/mo", features: [ "Deep results via OAuth", "Suspicious inbox rules detection", "Security hygiene checks", "Downloadable PDF reports", "Priority re-scan access", ], cta: "Go Pro", href: "/signin", }, { name: "Team", price: "Contact us", features: [ "Bulk domain checks", "Team dashboard", "Custom integrations", "Dedicated support", ], cta: "Contact sales", href: "/about", }, ];

return ( <section className="mx-auto max-w-6xl py-16"> <h2 className="text-3xl font-bold text-center">Pricing</h2> <p className="mt-2 text-center text-muted-foreground"> Simple, transparent plans to keep your accounts safe. </p> <div className="mt-12 grid gap-8 md:grid-cols-3"> {tiers.map((tier) => ( <div
key={tier.name}
className="flex flex-col rounded-2xl border border-border bg-card p-6 shadow-sm"
> <h3 className="text-xl font-semibold">{tier.name}</h3> <p className="mt-2 text-3xl font-bold">{tier.price}</p> <ul className="mt-4 flex-1 list-disc pl-6 text-sm text-muted-foreground"> {tier.features.map((f) => ( <li key={f}>{f}</li> ))} </ul> <Link
href={tier.href}
className="mt-6 inline-block rounded-lg bg-primary px-4 py-2 text-center font-medium text-primary-foreground hover:bg-primary/90"
> {tier.cta} </Link> </div> ))} </div> </section> ); }

export default function PricingLayout({ children, }: { children: React.ReactNode; }) { return ( <html lang="en" suppressHydrationWarning> <body className={cn( "min-h-screen bg-background font-sans antialiased flex flex-col", inter.className )} > <Header /> <main className="flex-1"> <PricingPage /> {children} </main> <Footer /> </body> </html> ); }

