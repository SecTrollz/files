import Link from "next/link";

export default function ResultsPage() {
  // placeholder data normally supplied by the backend
  const data = {
    score: 42,
    signals: ["Enrollment domain matched", "Suspicious forwarding rule"],
  };
  return (
    <section className="mx-auto max-w-3xl py-16">
      <h2 className="text-3xl font-bold">Scan Results</h2>
      <p className="mt-4">Confidence score: {data.score}%</p>
      <ul className="mt-8 list-disc pl-6">
        {data.signals.map((s, i) => (
          <li key={i}>{s.slice(0, 10)}…</li>
        ))}
      </ul>

      <p className="mt-8 text-sm text-muted-foreground">
        These results are trimmed for your privacy. Upgrade to reveal every signal and receive a downloadable PDF evidence pack.
      </p>
      <div className="mt-6 text-sm">
        <span>Full report includes:</span>
        <ul className="mt-2 list-disc pl-6">
          <li>Who enrolled the device and when</li>
          <li>Certificate chain and root CA checks</li>
          <li>Timeline and cross‑verification proofs</li>
        </ul>
      </div>
      <div className="mt-8">
        <Link href="/paywall" className="btn primary w-full sm:w-auto">
          Unlock Full PDF
        </Link>
      </div>
    </section>
  );
}
