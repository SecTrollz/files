import { Inter } from "next/font/google"; import "./globals.css"; import { cn } from "@/lib/utils"; import Link from "next/link"; import { Github, Apple, Mail, Shield } from "lucide-react";

const inter = Inter({ subsets: ["latin"] });

export const metadata = { title: "MDMCheck – Sign In", description: "Sign in with a provider to run deeper MDM exposure checks.", };

function Header() { return ( <header className="border-b border-border bg-background"> <nav className="mx-auto flex max-w-7xl items-center justify-between p-4"> <Link href="/" className="text-xl font-bold"> MDMCheck </Link> <div className="flex gap-6"> <Link href="/pricing">Pricing</Link> <Link href="/about">About</Link> <Link href="/legal/privacy">Privacy</Link> </div> </nav> </header> ); }

function Footer() { return ( <footer className="border-t border-border bg-background"> <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 p-6 text-sm text-muted-foreground md:flex-row"> <p>© {new Date().getFullYear()} MDMCheck. All rights reserved.</p> <div className="flex gap-6"> <Link href="/about">About</Link> <Link href="/legal/terms">Terms</Link> <Link href="/legal/privacy">Privacy</Link> <Link href="/status">Status</Link> </div> </div> </footer> ); }

function SignInPage() { const providers = [ { name: "Google", icon: <Mail className="h-4 w-4" />, href: "/api/auth/signin/google" }, { name: "Microsoft", icon: <Mail className="h-4 w-4" />, href: "/api/auth/signin/microsoft" }, { name: "Apple", icon: <Apple className="h-4 w-4" />, href: "/api/auth/signin/apple" }, { name: "GitHub", icon: <Github className="h-4 w-4" />, href: "/api/auth/signin/github" }, { name: "Yahoo", icon: <Mail className="h-4 w-4" />, href: "/api/auth/signin/yahoo" }, ];

return ( <section className="mx-auto max-w-md py-16"> <h2 className="text-3xl font-bold text-center">Sign in</h2> <p className="mt-2 text-center text-muted-foreground"> Connect with a provider to run deeper checks on your account security. </p> <div className="mt-8 space-y-3"> {providers.map((p) => ( <Link
key={p.name}
href={p.href}
className="flex items-center justify-center gap-2 rounded-lg border border-border bg-card px-4 py-2 font-medium hover:bg-accent"
> {p.icon} Continue with {p.name} </Link> ))} </div> <div className="mt-8 rounded-lg border border-border bg-card p-4 text-sm text-muted-foreground"> <div className="flex items-center gap-2"> <Shield className="h-4 w-4" /> <span>What we access</span> </div> <p className="mt-2"> We only analyze metadata necessary to detect MDM exposure: device enrollment records, mailbox rules, and basic account hygiene. We never store your inbox contents. </p> <p className="mt-2"> You can revoke access anytime from your provider’s account settings. </p> </div> </section> ); }

export default function SignInLayout({ children, }: { children: React.ReactNode; }) { return ( <html lang="en" suppressHydrationWarning> <body className={cn( "min-h-screen bg-background font-sans antialiased flex flex-col", inter.className )} > <Header /> <main className="flex-1"> <SignInPage /> {children} </main> <Footer /> </body> </html> ); }

