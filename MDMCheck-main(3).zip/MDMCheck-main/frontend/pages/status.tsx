import { Inter } from "next/font/google";
import "./globals.css";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { CheckCircle2, XCircle, Loader2, Server } from "lucide-react";
import { useEffect, useState } from "react";
import { fetchWithRetry } from "@/lib/fetcher";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "MDMCheck – Status",
  description: "View real-time system status and uptime for MDMCheck services.",
};

function Header() {
  return (
    <header className="border-b border-border bg-background">
      <nav className="mx-auto flex max-w-7xl items-center justify-between p-4">
        <Link href="/" className="text-xl font-bold">
          MDMCheck
        </Link>
        <div className="flex gap-6">
          <Link href="/pricing">Pricing</Link>
          <Link href="/about">About</Link>
          <Link href="/legal/privacy">Privacy</Link>
        </div>
      </nav>
    </header>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 p-6 text-sm text-muted-foreground md:flex-row">
        <p>© {new Date().getFullYear()} MDMCheck. All rights reserved.</p>
        <div className="flex gap-6">
          <Link href="/about">About</Link>
          <Link href="/legal/terms">Terms</Link>
          <Link href="/legal/privacy">Privacy</Link>
          <Link href="/status">Status</Link>
        </div>
      </div>
    </footer>
  );
}

function StatusPage() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        setError(null);
        // Uses resilient fetch; if final attempt fails,
        // it returns the last successful response with __stale: true.
        const json: any = await fetchWithRetry("/api/status", {}, { retries: 2, backoffMs: 400 });
        setData(json);
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <section className="mx-auto max-w-3xl py-16">
      <h2 className="text-3xl font-bold">System Status</h2>
      {data?.__stale && (
        <p className="mt-2 text-xs text-amber-600">
          Showing last known results (offline or retrying).
        </p>
      )}
      <p className="mt-2 text-muted-foreground">
        Real-time health of our services and last uptime checks.
      </p>

      {loading && (
        <div className="mt-6 flex items-center gap-2 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Checking system status…
        </div>
      )}

      {error && <p className="mt-6 text-rose-600">{error}</p>}

      {data && (
        <div className="mt-8 space-y-6">
          {data.services?.map((s: any) => (
            <div
              key={s.name}
              className="flex items-center justify-between rounded-lg border border-border bg-card p-4 shadow-sm"
            >
              <div className="flex items-center gap-2">
                <Server className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">{s.name}</span>
              </div>
              {s.status === "ok" ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              ) : (
                <XCircle className="h-5 w-5 text-rose-500" />
              )}
            </div>
          ))}

          <div className="rounded-xl border border-border bg-card p-6 text-sm text-muted-foreground">
            <p>Last checked: {new Date(data.checkedAt).toLocaleString()}</p>
            <p>Uptime (30d): {data.uptime}%</p>
          </div>
        </div>
      )}
    </section>
  );
}

export default function StatusLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={cn(
          "min-h-screen bg-background font-sans antialiased flex flex-col",
          inter.className
        )}
      >
        <Header />
        <main className="flex-1">
          <StatusPage />
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
