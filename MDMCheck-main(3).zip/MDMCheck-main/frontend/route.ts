// app/api/status/route.ts
export default {
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    if (request.method !== "GET" || url.pathname !== "/api/status") {
      return new Response("Not found", { status: 404 });
    }

    // Simulate minor variability for demos
    const up = 99.9 + Math.round(Math.random() * 10) / 1000; // 99.90–100.00
    const services = [
      { name: "API – Quick Check", status: "ok" },
      {
        name: "API – Deep Check",
        status: Math.random() > 0.1 ? "ok" : "degraded",
      },
      { name: "OAuth", status: "ok" },
      { name: "Billing", status: "ok" },
    ];

    const body = JSON.stringify({
      services,
      uptime: up.toFixed(3),
      checkedAt: new Date().toISOString(),
    });

    return new Response(body, {
      headers: { "content-type": "application/json" },
    });
  },
};
