(() => {
  try {
    const saved = localStorage.getItem("mdm-theme");
    const prefersDark = matchMedia && matchMedia("(prefers-color-scheme: dark)").matches;
    document.documentElement.dataset.theme = saved || (prefersDark ? "dark" : "light");
  } catch {}
})();
