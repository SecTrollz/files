"""Central logging configuration for MDMCheck.

This module sets up structured JSON logging using ``logging.config.dictConfig``.
Each log record includes a timestamp, a per-process session ID, and an
integrity hash derived from the message content.
"""

from __future__ import annotations

import hashlib
import json
import logging
import logging.config
import os
import sys
import uuid
from typing import Any, Dict


# Stable identifier for all logs emitted by this process. Can be overridden via
# ``MDMCHECK_SESSION_ID`` env var.
SESSION_ID = os.getenv("MDMCHECK_SESSION_ID", str(uuid.uuid4()))


class ContextFilter(logging.Filter):
    """Attach session context to each log record."""

    def filter(self, record: logging.LogRecord) -> bool:  # pragma: no cover - trivial
        record.session_id = SESSION_ID
        return True


class JsonLogFormatter(logging.Formatter):
    """Format log records as structured JSON with integrity hash."""

    def format(self, record: logging.LogRecord) -> str:
        timestamp = self.formatTime(record, datefmt="%Y-%m-%dT%H:%M:%S%z")
        msg = record.getMessage()
        session_id = getattr(record, "session_id", SESSION_ID)
        integrity = hashlib.sha256(
            f"{session_id}:{timestamp}:{msg}".encode("utf-8")
        ).hexdigest()
        base: Dict[str, Any] = {
            "level": record.levelname,
            "logger": record.name,
            "msg": msg,
            "time": timestamp,
            "session_id": session_id,
            "integrity_hash": integrity,
        }
        if record.exc_info:
            base["exc_info"] = self.formatException(record.exc_info)
        if record.stack_info:
            base["stack_info"] = self.formatStack(record.stack_info)
        return json.dumps(base, ensure_ascii=False)


class StdoutHandler(logging.Handler):
    """Emit logs to the current ``sys.stdout`` (pytest-safe)."""

    def emit(self, record: logging.LogRecord) -> None:  # pragma: no cover - trivial
        msg = self.format(record)
        sys.stdout.write(msg + "\n")


def configure_logging() -> None:
    """Configure root logger with JSON formatter and env-based level."""

    level = os.getenv("MDMCHECK_LOG_LEVEL", "INFO").upper()
    config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json": {"()": JsonLogFormatter},
        },
        "filters": {
            "context": {"()": ContextFilter},
        },
        "handlers": {
            "stdout": {
                "()": StdoutHandler,
                "formatter": "json",
                "filters": ["context"],
            }
        },
        "root": {
            "handlers": ["stdout"],
            "level": level,
        },
    }
    logging.config.dictConfig(config)


# Configure logging immediately when imported so simply importing this module
# activates JSON logging.
configure_logging()

