#!/usr/bin/env python3
"""
tools/manifest_signer.py — Ed25519 keygen, sign, and verify for MDMCheck manifests.

This utility is OPTIONAL. It does not modify your packaging/verifier flows.
Use it to generate keys, sign `manifest.json`, and verify signatures offline.

Subcommands:
  gen-key   → generate Ed25519 keypair (PEM private, raw-hex public)
  sign     → sign the normalized payload of a manifest (files array only)
  verify   → verify an existing signature in the manifest

Manifest convention (aligned with verify_bundle.py):
  - We sign the canonical payload: JSON of {"files": manifest["files"]} with
    separators=(",", ":"), ensure_ascii=False.
  - Fields embedded into manifest when signing:
      "public_key": <hex of 32-byte Ed25519 public key>
      "signature":  <hex of 64-byte Ed25519 signature>

Security notes:
  - Private keys are PEM-encoded; protect file permissions.
  - We do not print private keys to stdout.
  - This tool will refuse to overwrite existing keys unless --force is given.
"""

from __future__ import annotations
import argparse
import binascii
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Tuple

EXIT_OK = 0
EXIT_FAIL = 2
EXIT_DEP = 20

def _need_crypto():
    try:
        import cryptography  # noqa: F401
        return True
    except Exception:
        return False

def _die_dep():
    sys.stderr.write(
        "error: 'cryptography' package is required for manifest_signer.\n"
        "Install it or run with your own signing flow.\n"
    )
    sys.exit(EXIT_DEP)

def _load_manifest(path: Path) -> Dict[str, Any]:
    try:
        return json.loads(path.read_text())
    except Exception as e:
        raise SystemExit(f"error: failed to read JSON from {path}: {e}")

def _write_manifest(path: Path, doc: Dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=2))
    tmp.replace(path)

def _canonical_payload(doc: Dict[str, Any]) -> bytes:
    files = doc.get("files")
    if not isinstance(files, list) or not files:
        raise SystemExit("error: manifest must contain non-empty 'files' array to sign")
    payload = {"files": files}
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()

def _gen_keypair() -> Tuple[bytes, bytes]:
    # Returns (private_pem, public_raw)
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization

    sk = Ed25519PrivateKey.generate()
    pk = sk.public_key()

    private_pem = sk.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_raw = pk.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return private_pem, public_raw

def _save_keypair(private_path: Path, public_path: Path, private_pem: bytes, public_raw: bytes, force: bool) -> None:
    if (private_path.exists() or public_path.exists()) and not force:
        raise SystemExit(f"error: {private_path} or {public_path} exists; use --force to overwrite")

    # Write private key with restrictive permissions
    private_path.parent.mkdir(parents=True, exist_ok=True)
    with open(private_path, "wb") as f:
        f.write(private_pem)
    try:
        os.chmod(private_path, 0o600)
    except Exception:
        pass

    public_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.write_text(binascii.hexlify(public_raw).decode("ascii"))

def cmd_gen_key(args: argparse.Namespace) -> int:
    if not _need_crypto():
        _die_dep()
    private_p = Path(args.private)
    public_p = Path(args.public)
    priv_pem, pub_raw = _gen_keypair()
    _save_keypair(private_p, public_p, priv_pem, pub_raw, args.force)
    sys.stdout.write(f"wrote private key: {private_p}\n")
    sys.stdout.write(f"wrote public key (hex): {public_p}\n")
    return EXIT_OK

def _load_private_key(private_path: Path):
    from cryptography.hazmat.primitives import serialization
    data = private_path.read_bytes()
    try:
        return serialization.load_pem_private_key(data, password=None)
    except Exception as e:
        raise SystemExit(f"error: failed to load PEM private key {private_path}: {e}")

def _load_public_key_raw(public_hex: str) -> bytes:
    try:
        raw = binascii.unhexlify(public_hex.strip())
    except Exception:
        raise SystemExit("error: 'public_key' must be hex-encoded raw Ed25519 key (32 bytes)")
    if len(raw) != 32:
        raise SystemExit("error: 'public_key' must be 32 raw bytes (hex)")
    return raw

def cmd_sign(args: argparse.Namespace) -> int:
    if not _need_crypto():
        _die_dep()
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    manifest_path = Path(args.manifest)
    doc = _load_manifest(manifest_path)
    payload = _canonical_payload(doc)

    sk = _load_private_key(Path(args.private))
    if not isinstance(sk, Ed25519PrivateKey):
        raise SystemExit("error: private key is not an Ed25519 key")

    sig = sk.sign(payload)  # 64 bytes
    pk_raw = sk.public_key().public_bytes(  # 32 bytes
        encoding=__import__("cryptography.hazmat.primitives").hazmat.primitives.serialization.Encoding.Raw,
        format=__import__("cryptography.hazmat.primitives").hazmat.primitives.serialization.PublicFormat.Raw,
    )

    doc["signature"] = sig.hex()
    doc["public_key"] = pk_raw.hex()
    _write_manifest(manifest_path, doc)
    sys.stdout.write(f"signed manifest: {manifest_path}\n")
    return EXIT_OK

def cmd_verify(args: argparse.Namespace) -> int:
    if not _need_crypto():
        _die_dep()
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    manifest_path = Path(args.manifest)
    doc = _load_manifest(manifest_path)
    payload = _canonical_payload(doc)

    sig_hex = doc.get("signature")
    pub_hex = doc.get("public_key")
    if not isinstance(sig_hex, str) or not isinstance(pub_hex, str):
        raise SystemExit("error: manifest is missing 'signature' and/or 'public_key' fields")

    try:
        sig = binascii.unhexlify(sig_hex)
        pub_raw = _load_public_key_raw(pub_hex)
    except SystemExit:
        raise
    except Exception:
        raise SystemExit("error: invalid hex encoding for signature/public key")

    if len(sig) != 64:
        raise SystemExit("error: signature must be 64 raw bytes (hex)")

    pk = Ed25519PublicKey.from_public_bytes(pub_raw)
    try:
        pk.verify(sig, payload)
        sys.stdout.write("signature: VALID\n")
        return EXIT_OK
    except Exception:
        sys.stdout.write("signature: INVALID\n")
        return EXIT_FAIL

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="manifest-signer",
        description="Generate Ed25519 keys, sign MDMCheck manifests, verify signatures.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("gen-key", help="Generate Ed25519 keypair")
    sp.add_argument("--private", required=True, help="Path to write PEM private key")
    sp.add_argument("--public", required=True, help="Path to write public key (hex)")
    sp.add_argument("--force", action="store_true", help="Overwrite existing files")
    sp.set_defaults(func=cmd_gen_key)

    sp = sub.add_parser("sign", help="Sign manifest.json with Ed25519 private key")
    sp.add_argument("--manifest", required=True, help="Path to manifest.json")
    sp.add_argument("--private", required=True, help="Path to Ed25519 private key (PEM)")
    sp.set_defaults(func=cmd_sign)

    sp = sub.add_parser("verify", help="Verify signature in manifest.json")
    sp.add_argument("--manifest", required=True, help="Path to manifest.json")
    sp.set_defaults(func=cmd_verify)

    return p

def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    code = args.func(args)
    raise SystemExit(code)

if __name__ == "__main__":
    main()