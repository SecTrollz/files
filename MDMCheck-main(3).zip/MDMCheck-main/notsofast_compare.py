#!/usr/bin/env python3
"""
notsofast_compare.py — Compare two MDMCheck result JSONs (baseline vs current).

Usage:
  notsofast-compare --pretty baseline.json current.json
  notsofast-compare --json   baseline.json current.json
  notsofast-compare --pretty --csv diff.csv baseline.json current.json

Exit codes:
  0 = no regressions
  4 = regressions detected (one or more probes flipped pass→fail or new fails)
  2 = invalid input / parse error
  1 = unexpected error

Notes:
- Compares probes by `name`.
- Accepts either schema: {"probes":[{name, ok, detail}...]} or {"results":[...]}.
- Treats missing probes as NEW (potentially a regression if they fail).
"""

from __future__ import annotations
import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional

SAFE_MAX_BYTES = int(os.getenv("MDMCHECK_COMPARE_MAX_INPUT_BYTES", "5242880"))  # 5 MiB cap


def _isatty(stream) -> bool:
    try:
        return stream.isatty()
    except Exception:
        return False


def _color(s: str, fg: str) -> str:
    if not _isatty(sys.stdout):
        return s
    C = {"green": "\033[32m", "red": "\033[31m", "yellow": "\033[33m", "cyan": "\033[36m", "reset": "\033[0m"}
    return f"{C.get(fg,'')}{s}{C['reset']}"


def _safe_read_json(p: str) -> Dict[str, Any]:
    """Safely load JSON from *p* without allowing symlink tricks or huge files.

    Tests write temporary files outside the repository, so this helper resolves the
    provided path directly instead of forcing it to live under the current working
    directory.  Only regular files are allowed and input size is bounded to prevent
    memory exhaustion.
    """

    path = Path(p).expanduser().resolve(strict=False)
    if not path.exists():
        raise FileNotFoundError(path)
    if path.is_dir():
        raise IsADirectoryError(path)
    if path.is_symlink():
        raise ValueError("symlink not allowed")
    data = path.read_bytes()
    if len(data) > SAFE_MAX_BYTES:
        raise ValueError("input too large")
    return json.loads(data.decode("utf-8"))


def _probe_list(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    items = doc.get("probes")
    if isinstance(items, list):
        return items
    items = doc.get("results")
    return items if isinstance(items, list) else []


def _ok_value(p: Dict[str, Any]) -> Optional[bool]:
    if "ok" in p:
        return bool(p.get("ok"))
    if "status" in p:
        return p.get("status") == "pass"
    return None


def _index_by_name(items: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    idx: Dict[str, Dict[str, Any]] = {}
    for it in items:
        name = str(it.get("name", "")).strip() or "(unnamed)"
        # Keep the first occurrence; duplicates are ignored to avoid ambiguity
        if name not in idx:
            idx[name] = it
    return idx


def _summarize_changes(base: Dict[str, Dict[str, Any]], cur: Dict[str, Dict[str, Any]]):
    """
    Return (rows, stats) where rows are per-probe diffs:
      name, base_ok, cur_ok, change ('unchanged_pass', 'unchanged_fail', 'improved', 'regressed', 'new_pass', 'new_fail', 'missing')
    """
    names = sorted(set(base.keys()) | set(cur.keys()))
    rows: List[Dict[str, Any]] = []
    stats = {"total": 0, "unchanged_pass": 0, "unchanged_fail": 0, "improved": 0, "regressed": 0, "new_pass": 0, "new_fail": 0, "missing": 0}
    for n in names:
        b = base.get(n)
        c = cur.get(n)
        b_ok = _ok_value(b) if b is not None else None
        c_ok = _ok_value(c) if c is not None else None

        if b is None and c is not None:
            change = "new_pass" if c_ok else "new_fail"
        elif b is not None and c is None:
            change = "missing"
        else:
            if b_ok is True and c_ok is True:
                change = "unchanged_pass"
            elif b_ok is False and c_ok is False:
                change = "unchanged_fail"
            elif b_ok is True and c_ok is False:
                change = "regressed"
            elif b_ok is False and c_ok is True:
                change = "improved"
            else:
                # covers None/unknown mixed cases; treat as unchanged for now
                change = "unchanged_fail" if (c_ok is False or b_ok is False) else "unchanged_pass"

        stats["total"] += 1
        stats[change] += 1
        rows.append({"name": n, "base_ok": b_ok, "current_ok": c_ok, "change": change})
    return rows, stats


def _pretty_table(rows: List[Dict[str, Any]], stats: Dict[str, int]) -> str:
    out: List[str] = []
    out.append("MDMCheck — Result Comparison")
    out.append("")
    out.append("Legend: ✓ pass  ✗ fail  ↘ regressed  ↗ improved  ◻ unchanged")
    out.append("")
    out.append(f"Summary: total={stats['total']}  "
               f"{_color('regressed='+str(stats['regressed']), 'red')},  "
               f"improved={stats['improved']},  "
               f"unchanged_pass={stats['unchanged_pass']},  unchanged_fail={stats['unchanged_fail']},  "
               f"new_pass={stats['new_pass']},  new_fail={_color(str(stats['new_fail']), 'red')},  "
               f"missing={stats['missing']}")
    out.append("")
    out.append(f"{'Status':<10} {'Probe':<22} Notes")
    out.append("-" * 72)

    for r in rows:
        ch = r["change"]
        name = r["name"]
        if ch == "regressed":
            status = _color("↘ regressed", "red")
            note = "was ✓, now ✗"
        elif ch == "improved":
            status = _color("↗ improved", "green")
            note = "was ✗, now ✓"
        elif ch == "unchanged_pass":
            status = _color("◻ pass", "green")
            note = ""
        elif ch == "unchanged_fail":
            status = _color("◻ fail", "yellow")
            note = ""
        elif ch == "new_fail":
            status = _color("✗ new fail", "red")
            note = "missing in baseline"
        elif ch == "new_pass":
            status = _color("✓ new pass", "green")
            note = "missing in baseline"
        elif ch == "missing":
            status = _color("— missing", "yellow")
            note = "present in baseline only"
        else:
            status = ch
            note = ""
        out.append(f"{status:<10} {name:<22} {note}")
    return "\n".join(out)


def _json_diff(rows: List[Dict[str, Any]], stats: Dict[str, int]) -> Dict[str, Any]:
    return {
        "summary": stats,
        "diff": rows,
        "regressions": [r for r in rows if r["change"] == "regressed" or r["change"] == "new_fail"],
    }


def _write_csv(path: str, rows: List[Dict[str, Any]], stats: Dict[str, int]) -> None:
    # Minimal CSV export of row-level diffs
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["probe", "baseline_ok", "current_ok", "change"])
        for r in rows:
            w.writerow([r["name"], r["base_ok"], r["current_ok"], r["change"]])
        # Append summary as commented lines
        w.writerow([])
        w.writerow(["# summary"])
        for k, v in stats.items():
            w.writerow([f"#{k}", v])


def _parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="notsofast-compare",
        description="Compare two MDMCheck result JSON files (baseline vs current).",
    )
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--pretty", action="store_true", help="Human-readable table")
    mode.add_argument("--json", action="store_true", help="JSON diff output")
    p.add_argument("--csv", help="Optional path to write CSV of per-probe diffs")
    p.add_argument("baseline", help="Path to baseline result JSON")
    p.add_argument("current", help="Path to current result JSON")
    return p.parse_args(argv)


def main(argv=None) -> None:
    try:
        args = _parse_args(argv)
        base_doc = _safe_read_json(args.baseline)
        cur_doc = _safe_read_json(args.current)

        base_idx = _index_by_name(_probe_list(base_doc))
        cur_idx = _index_by_name(_probe_list(cur_doc))
        rows, stats = _summarize_changes(base_idx, cur_idx)

        # Optional CSV
        if args.csv:
            _write_csv(args.csv, rows, stats)

        # Render output
        if args.json:
            print(json.dumps(_json_diff(rows, stats), ensure_ascii=False, indent=2))
        else:
            print(_pretty_table(rows, stats))

        # Regressions trigger non-zero to fail CI (but still show output)
        if stats["regressed"] > 0 or stats["new_fail"] > 0:
            raise SystemExit(4)
        raise SystemExit(0)

    except (json.JSONDecodeError, FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        raise SystemExit(2)
    except SystemExit:
        raise
    except Exception:
        print("error: unexpected failure during comparison", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":  # pragma: no cover
    main()
