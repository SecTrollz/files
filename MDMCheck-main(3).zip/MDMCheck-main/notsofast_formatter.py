#!/usr/bin/env python3
"""
notsofast_formatter.py — Presentation helpers for MDMCheck results.

Accepts a generic results dict (from notsofast JSON) and renders:
- JSON with a computed summary block
- Pretty terminal table
- Optional PDF hand-off via pdf_report.py

This module NEVER runs notsofast; it only formats given results.
"""

from __future__ import annotations
import json
import sys
from typing import Any, Dict, List


def _isatty(stream) -> bool:
    try:
        return stream.isatty()
    except Exception:
        return False


def _color(s: str, fg: str) -> str:
    # ANSI colors only when terminal is interactive
    if not _isatty(sys.stdout):
        return s
    colors = {
        "green": "\033[32m",
        "red": "\033[31m",
        "yellow": "\033[33m",
        "cyan": "\033[36m",
        "reset": "\033[0m",
    }
    return f"{colors.get(fg, '')}{s}{colors['reset']}"


def _compute_summary(results: Dict[str, Any]) -> Dict[str, Any]:
    items = results.get("probes") or results.get("results") or []
    total = len(items)
    passed = 0
    failed = 0
    scores: List[float] = []
    for r in items:
        ok = r.get("ok")
        if ok is None:  # support alt schema: status: pass/fail
            ok = r.get("status") == "pass"
        if ok:
            passed += 1
        else:
            failed += 1
        sc = r.get("score")
        if isinstance(sc, (int, float)):
            scores.append(float(sc))
    warnings = len(results.get("warnings", []))
    summary: Dict[str, Any] = {
        "total_probes": total,
        "passed": passed,
        "failed": failed,
        "warnings": warnings,
    }
    if scores:
        summary["average_score"] = sum(scores) / len(scores)
    return summary


def format_json(results: Dict[str, Any], include_summary: bool = True) -> str:
    """Pretty-printed JSON (adds 'summary' if missing)."""
    doc = dict(results)
    if include_summary and "summary" not in doc:
        doc["summary"] = _compute_summary(doc)
    return json.dumps(doc, ensure_ascii=False, indent=2)


def _gist_from_detail(detail: Dict[str, Any]) -> str:
    if not detail:
        return ""
    if isinstance(detail.get("addresses"), list) and detail["addresses"]:
        tgt = detail.get("target", "")
        addrs = ", ".join(map(str, detail["addresses"][:3]))
        return f"{tgt} → {addrs}".strip()
    if "system" in detail and "release" in detail:
        return f"{detail['system']} {detail['release']}"
    if "warning" in detail:
        return _color(str(detail["warning"]), "yellow")
    if "error" in detail:
        return _color(str(detail["error"]), "red")
    # fallback: first key/value
    k, v = next(iter(detail.items()))
    return f"{k}: {v}"


def format_pretty(results: Dict[str, Any]) -> str:
    """Human-friendly summary table."""
    mode = results.get("mode", "unknown")
    started = results.get("started", "")
    finished = results.get("finished", "")
    host = results.get("host", {})
    hostname = host.get("hostname") or host.get("name") or "unknown-host"
    system = host.get("system", "?")
    release = host.get("release", "?")
    pyver = host.get("python", "?")
    summary = _compute_summary(results)

    header = [
        f"MDMCheck — notsofast ({mode} mode)",
        f"Run started: {started}",
        f"Host: {hostname} ({system} {release}, Python {pyver})",
        "",
        "Probes:",
    ]

    lines: List[str] = []
    items = results.get("probes") or results.get("results") or []
    for r in items:
        name = r.get("name", "probe")
        ok = r.get("ok")
        if ok is None:
            ok = r.get("status") == "pass"
        mark = _color("✓", "green") if ok else _color("✗", "red")
        gist = _gist_from_detail(r.get("detail") or {})
        lines.append(f"  {mark} {name:<14} {gist}")

    footer = [
        "",
        f"Summary: {summary['passed']} passed, {summary['failed']} failed, {summary['warnings']} warnings",
    ]
    if "average_score" in summary:
        footer.append(f"Average score: {summary['average_score']:.2f}")

    return "\n".join(header + lines + footer)


def maybe_generate_pdf(results: Dict[str, Any], output_pdf: str) -> bool:
    """
    Attempt to generate a PDF via pdf_report.py if available.
    Returns True on success; False otherwise. No printing here.
    """
    try:
        import tempfile
        import os
        import json as _json
        import pdf_report  # type: ignore
    except Exception:
        return False

    try:
        tmpdir = tempfile.mkdtemp(prefix="mdmcheck_report_")
        data_path = os.path.join(tmpdir, "results.json")
        with open(data_path, "w", encoding="utf-8") as f:
            _json.dump(results, f, ensure_ascii=False, indent=2)

        argv = ["--input", data_path, "--output", output_pdf]
        if hasattr(pdf_report, "main"):
            pdf_report.main(argv)  # type: ignore[arg-type]
            return os.path.exists(output_pdf)
        return False
    except Exception:
        return False
