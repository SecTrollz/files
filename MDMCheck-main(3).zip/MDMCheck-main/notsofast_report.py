#!/usr/bin/env python3
"""
notsofast_report.py — Professional client presentation without touching notsofast.py.

What it does:
- Runs the original `notsofast` as a subprocess with your chosen args (verbatim behavior).
- Captures stdout; if it’s JSON, renders a professional pretty table (and/or JSON).
- Optional: generate a PDF via pdf_report.py.

It NEVER alters notsofast’s own stdout/stderr. It prints its own formatted
output only after notsofast completes successfully, based on the JSON captured.

Usage examples:
  notsofast-report -- pretty       -- <any notsofast args...>
  notsofast-report -- json         -- <any notsofast args...>
  notsofast-report -- pretty --pdf report.pdf -- --mode quick --json

Note: Arguments before `--` are for the reporter; arguments after `--` go to notsofast.
"""

from __future__ import annotations
import argparse
import json
import os
import subprocess
import sys
from typing import List, Any, Dict

from notsofast_formatter import format_json, format_pretty, maybe_generate_pdf


def _run_notsofast(nsf_args: List[str], timeout: int) -> subprocess.CompletedProcess:
    # Run original notsofast verbatim, capturing stdout/stderr.
    # We DO NOT modify its output; we only consume the stdout afterwards.
    cmd = [sys.executable, "-m", "notsofast", *nsf_args]
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )


def main(argv: List[str] | None = None) -> None:
    p = argparse.ArgumentParser(
        prog="notsofast-report",
        description="Present professional client output from notsofast without modifying original behavior.",
        add_help=True,
    )
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--json", action="store_true", help="Emit structured JSON (adds summary if missing)")
    mode.add_argument("--pretty", action="store_true", help="Print a professional, human-friendly summary table")
    p.add_argument("--pdf", metavar="PATH", help="Also generate a polished PDF report at PATH")
    p.add_argument("--timeout", type=int, default=int(os.getenv("WRAP_TIMEOUT_SEC", "180")),
                   help="Overall runtime timeout in seconds (default: 180, or WRAP_TIMEOUT_SEC)")
    p.add_argument("separator", nargs="?", default="--",
                   help="Separator token before notsofast args (default: --)")
    p.add_argument("nsf_args", nargs=argparse.REMAINDER,
                   help="Arguments passed through to notsofast (after the separator)")
    args = p.parse_args(argv)

    # Extract passthrough args after the first occurrence of the separator
    nsf_args = args.nsf_args
    if nsf_args and nsf_args[0] == "--":
        nsf_args = nsf_args[1:]

    # Execute original notsofast
    try:
        cp = _run_notsofast(nsf_args, timeout=args.timeout)
    except subprocess.TimeoutExpired:
        # Mirror common timeout semantics; do not print partials
        sys.stderr.write(f"notsofast-report: timed out after {args.timeout}s\n")
        sys.exit(124)
    except Exception as e:
        sys.stderr.write(f"notsofast-report: failed to run notsofast: {e}\n")
        sys.exit(1)

    # If notsofast failed, forward its exact output and exit code (verbatim)
    if cp.returncode != 0:
        stream = cp.stderr if cp.stderr.strip() else cp.stdout
        if stream:
            sys.stderr.write(stream)
            sys.stderr.flush()
        sys.exit(cp.returncode)

    # Try to parse stdout as JSON
    result: Dict[str, Any] | None = None
    try:
        text = cp.stdout.strip()
        if text.startswith("{") and text.endswith("}"):
            result = json.loads(text)
    except Exception:
        result = None

    # If we couldn't parse JSON, just print the original stdout verbatim and exit 0
    if result is None:
        sys.stdout.write(cp.stdout)
        sys.stdout.flush()
        sys.exit(0)

    # Render presentation
    if args.json:
        sys.stdout.write(format_json(result))
        sys.stdout.write("\n")
    elif args.pretty:
        sys.stdout.write(format_pretty(result))
        sys.stdout.write("\n")

    # Optional PDF report
    if args.pdf:
        ok = maybe_generate_pdf(result, args.pdf)
        if not ok:
            sys.stderr.write(
                f"warning: could not generate PDF at {args.pdf} "
                "(pdf_report.py not available or failed)\n"
            )
            sys.stderr.flush()

    sys.exit(0)


if __name__ == "__main__":
    main()