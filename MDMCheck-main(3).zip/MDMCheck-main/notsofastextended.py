#!/usr/bin/env python3
import argparse, json, logging, os, subprocess, sys, tempfile, time
from datetime import datetime, timezone

from logging_config import configure_logging

configure_logging()
log = logging.getLogger("notsofast.v3")

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def run_cmd(cmd, timeout=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"

def load_json(path_or_text):
    try:
        if os.path.exists(path_or_text):
            with open(path_or_text, "r", encoding="utf-8") as f:
                return json.load(f)
        return json.loads(path_or_text)
    except Exception:
        return None

def merge_reports(base, auth_blocks):
    out = {
        "forensics_report": base or {},
        "authenticated_evidence": auth_blocks,
        "collection_metadata": {
            "tool": "notsofastextended_updated_v3.0",
            "timestamp": now_iso(),
            "passive_source": "notsofast.py" if base else None,
            "auth_providers": [b.get("collection_metadata", {}).get("provider") for b in auth_blocks],
        }
    }
    try:
        if base and "active_endpoints" in base:
            out["summary"] = {
                "active_endpoints": len(base.get("active_endpoints", [])),
                "active_subdomains": len(base.get("discovered_subdomains", [])),
                "dns_indicators": len(base.get("dns_history", {}).get("external_service_indicators", [])),
                "providers": out["collection_metadata"]["auth_providers"]
            }
    except Exception:
        pass
    return out

def build_auth_cmd(provider, args, out_path):
    base = [sys.executable, "authenticated_evidence_collector.py", "--provider", provider, "--redirect-uri", args.redirect_uri, "--redirect-port", str(args.redirect_port), "--auth-timeout", str(args.auth_timeout), "--out", out_path]
    if provider == "microsoft":
        if args.ms_client_id: base += ["--ms-client-id", args.ms_client_id]
        if args.ms_tenant: base += ["--ms-tenant", args.ms_tenant]
        if args.with_mail: base += ["--with-mail"]
        if args.with_graph_device_read: base += ["--with-graph-device-read"]
    elif provider == "google":
        if args.google_client_id: base += ["--google-client-id", args.google_client_id]
        if args.with_mail: base += ["--with-mail"]
    elif provider == "github":
        if args.github_client_id: base += ["--github-client-id", args.github_client_id]
    elif provider == "apple":
        if not all([args.apple_client_id, args.apple_team_id, args.apple_key_id, args.apple_key_file]):
            raise ValueError("Apple requires --apple-client-id, --apple-team-id, --apple-key-id, --apple-key-file")
        base += ["--apple-client-id", args.apple_client_id, "--apple-team-id", args.apple_team_id, "--apple-key-id", args.apple_key_id, "--apple-key-file", args.apple_key_file]
    elif provider == "yahoo":
        if args.yahoo_client_id: base += ["--yahoo-client-id", args.yahoo_client_id]
        if args.yahoo_client_secret: base += ["--yahoo-client-secret", args.yahoo_client_secret]
        if args.with_mail_imap: base += ["--with-mail-imap"]
    return base

def run_passive(email, save_tmp_json):
    cmd = [sys.executable, "notsofast.py", email, "--json"]
    if save_tmp_json:
        fd, tmp = tempfile.mkstemp(prefix="notsofast_", suffix=".json")
        os.close(fd)
        code, out, err = run_cmd(cmd)
        if code != 0:
            return None, code, err.strip()
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(out)
            return tmp, 0, ""
        except Exception as e:
            return None, 1, str(e)
    code, out, err = run_cmd(cmd)
    if code != 0:
        return None, code, err.strip()
    return load_json(out), 0, ""

def main():
    ap = argparse.ArgumentParser(prog="notsofastextended_updated_v3.0", description="Passive + optional authenticated evidence orchestrator")
    ap.add_argument("email", help="Target email address for passive scan (used by notsofast.py)")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--save-evidence", default="")
    ap.add_argument("--skip-passive", action="store_true")
    ap.add_argument("--passive-json-in", default="")
    ap.add_argument("--providers", nargs="*", choices=["microsoft","google","github","apple","yahoo"], default=[])
    ap.add_argument("--with-mail", action="store_true")
    ap.add_argument("--with-graph-device-read", action="store_true")
    ap.add_argument("--with-mail-imap", action="store_true")
    ap.add_argument("--redirect-uri", default="http://127.0.0.1:8765/oauth/callback")
    ap.add_argument("--redirect-port", type=int, default=8765)
    ap.add_argument("--auth-timeout", type=int, default=300)
    ap.add_argument("--ms-client-id", default=os.environ.get("MS_CLIENT_ID",""))
    ap.add_argument("--ms-tenant", default=os.environ.get("MS_TENANT",""))
    ap.add_argument("--google-client-id", default=os.environ.get("GOOGLE_CLIENT_ID",""))
    ap.add_argument("--github-client-id", default=os.environ.get("GITHUB_CLIENT_ID",""))
    ap.add_argument("--apple-client-id", default=os.environ.get("APPLE_CLIENT_ID",""))
    ap.add_argument("--apple-team-id", default=os.environ.get("APPLE_TEAM_ID",""))
    ap.add_argument("--apple-key-id", default=os.environ.get("APPLE_KEY_ID",""))
    ap.add_argument("--apple-key-file", default=os.environ.get("APPLE_KEY_FILE",""))
    ap.add_argument("--yahoo-client-id", default=os.environ.get("YAHOO_CLIENT_ID",""))
    ap.add_argument("--yahoo-client-secret", default=os.environ.get("YAHOO_CLIENT_SECRET",""))
    args = ap.parse_args()

    base_report = None
    passive_tmp = None

    if args.passive_json_in:
        base_report = load_json(args.passive_json_in)
        if base_report is None:
            log.error("Failed to load passive JSON input"); sys.exit(2)
    elif not args.skip_passive:
        log.info("Running passive scan via notsofast.py")
        passive, code, err = run_passive(args.email, save_tmp_json=False)
        if code != 0:
            log.error(f"notsofast.py failed: {err}"); sys.exit(code)
        base_report = passive

    auth_blocks = []
    for p in args.providers:
        try:
            fd, out_path = tempfile.mkstemp(prefix=f"auth_{p}_", suffix=".json")
            os.close(fd)
            cmd = build_auth_cmd(p, args, out_path)
            log.info(f"Starting authenticated flow: {p}")
            code, out, err = run_cmd(cmd, timeout=args.auth_timeout + 60)
            if code != 0:
                log.warning(f"{p} auth collector failed: {err.strip() or out.strip()}")
                try:
                    os.unlink(out_path)
                except Exception:
                    pass
                continue
            with open(out_path, "r", encoding="utf-8") as f:
                block = json.load(f)
            auth_blocks.append(block)
            try:
                os.unlink(out_path)
            except Exception:
                pass
            log.info(f"Collected authenticated evidence: {p}")
        except KeyboardInterrupt:
            log.warning("Cancelled")
            break
        except Exception as e:
            log.warning(f"{p} collection error: {e}")

    merged = merge_reports(base_report, auth_blocks)

    if args.save_evidence:
        pkg = {
            "forensics_report": merged.get("forensics_report"),
            "authenticated_evidence": merged.get("authenticated_evidence"),
            "legal_metadata": {
                "victim_email": args.email,
                "evidence_collection_date": now_iso(),
                "analysis_tool": "notsofastextended_updated_v3.0",
                "chain_of_custody": "User-consented passive and authenticated reads",
                "evidence_integrity_hash": None
            },
            "collection_metadata": merged.get("collection_metadata"),
            "summary": merged.get("summary", {})
        }
        try:
            with open(args.save_evidence, "w", encoding="utf-8") as f:
                json.dump(pkg, f, indent=2)
            log.info(f"Saved evidence: {args.save_evidence}")
        except Exception as e:
            log.error(f"Failed to save evidence: {e}")
            sys.exit(1)

    if args.json or not args.save_evidence:
        print(json.dumps(merged, indent=2))

if __name__ == "__main__":
    main()