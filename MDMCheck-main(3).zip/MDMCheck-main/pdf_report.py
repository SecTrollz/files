
from __future__ import annotations
from pathlib import Path
import json, datetime

from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    HRFlowable,
    Image,
)
from reportlab.lib import colors

try:
    import qrcode
    QR_OK = True
except Exception:
    QR_OK = False

def _load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


def _redact_results(results: dict) -> dict:
    """Return a copy of *results* with sensitive fields removed.

    Evidence details can contain information we only want to expose to paying
    customers.  For the free PDF we replace any ``detail`` blocks with a simple
    placeholder string so investigators still see which probes ran without
    leaking data.
    """

    red = json.loads(json.dumps(results))  # deep copy
    items = red.get("probes") or red.get("results")
    if isinstance(items, list):
        for r in items:
            if "detail" in r:
                r["detail"] = "[redacted]"
    return red


def generate_from_results(results: dict, output: Path, *, redact: bool = True) -> None:
    """Create a small PDF report summarising *results* at ``output``.

    When ``redact`` is True (default) sensitive fields are removed using
    :func:`_redact_results`.
    """

    if redact:
        results = _redact_results(results)

    styles = getSampleStyleSheet()
    H1 = styles["Heading1"]
    Body = styles["BodyText"]

    doc = SimpleDocTemplate(str(output), pagesize=LETTER, title="MDMCheck Report")
    flow = [
        Paragraph("MDMCheck – Scan Report", H1),
        Paragraph(
            datetime.datetime.utcnow().strftime("Generated (UTC): %Y-%m-%d %H:%M:%S"),
            Body,
        ),
        Spacer(1, 12),
    ]

    items = results.get("probes") or results.get("results") or []
    if items:
        data = [["Probe", "Status", "Score"]]
        for r in items:
            status = "pass" if r.get("ok") or r.get("status") == "pass" else "fail"
            data.append([r.get("name", "probe"), status, str(r.get("score", ""))])
        table = Table(data, colWidths=[240, 80, 80])
        table.setStyle(
            TableStyle(
                [
                    ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                ]
            )
        )
        flow.append(table)
        flow.append(Spacer(1, 12))

    flow.append(
        Paragraph(
            "Detailed evidence has been redacted. Upgrade your account to view the full report.",
            Body,
        )
    )

    doc.build(flow)


def main(argv: list[str] | None = None) -> None:
    """Command line entry point used by notsofast_formatter."""

    import argparse

    p = argparse.ArgumentParser(description="Generate a redacted PDF report")
    p.add_argument("--input", required=True, help="Path to JSON results file")
    p.add_argument("--output", required=True, help="Destination PDF path")
    p.add_argument(
        "--no-redact",
        action="store_true",
        help="Include full details without redaction",
    )
    args = p.parse_args(argv)

    with open(args.input, "r", encoding="utf-8") as f:
        results = json.load(f)

    generate_from_results(results, Path(args.output), redact=not args.no_redact)

def render(bundle_dir: str) -> None:
    d = Path(bundle_dir)
    findings = _load_json(d / "findings.json") or {}
    manifest = _load_json(d / "manifest.json") or {}
    sha_path = d / "bundle.sha256"
    bundle_sha = sha_path.read_text(encoding="utf-8").strip() if sha_path.exists() else "N/A"

    # Build PDF
    pdf = d / "report.pdf"
    doc = SimpleDocTemplate(str(pdf), pagesize=LETTER, title="SilentMDMCheck Court Report")
    styles = getSampleStyleSheet()
    H1 = styles['Heading1']
    H2 = styles['Heading2']
    H3 = styles['Heading3']
    Body = styles['BodyText']
    Mono = ParagraphStyle('Mono', parent=Body, fontName='Courier', fontSize=9, leading=11)

    flow = []
    # Cover / Executive Summary
    flow.append(Paragraph("SilentMDMCheck — Court Report", H1))
    flow.append(Paragraph(datetime.datetime.utcnow().strftime("Generated (UTC): %Y-%m-%d %H:%M:%S"), Body))
    flow.append(Spacer(1, 12))

    subj = findings.get("subject", {})
    attr = findings.get("attribution", {})
    onset = findings.get("onset", {})

    flow.append(Paragraph("<b>Executive Summary</b>", H2))
    flow.append(Paragraph(f"Subject: <b>{subj.get('email','')}</b> ({subj.get('domain','')})", Body))
    org = (attr.get("org") or {}).get("display_name", "Unknown")
    conf = attr.get("confidence", 0.0)
    flow.append(Paragraph(f"WHO: <b>{org}</b> (confidence {conf:.2f})", Body))
    ts = onset.get("timestamp", "Unknown")
    win = f"{onset.get('window_start','?')} → {onset.get('window_end','?')}"
    flow.append(Paragraph(f"WHEN: <b>{ts}</b> (window {win})", Body))
    flow.append(Spacer(1, 12))

    # Attribution
    flow.append(Paragraph("Attribution (WHO)", H2))
    sigs = attr.get("signals", []) or []
    if sigs:
        data = [["Source", "Indicator", "Weight"]]
        for s in sigs:
            data.append([s.get("source",""), s.get("indicator",""), str(s.get("weight",""))])
        t = Table(data, colWidths=[100, 340, 60])
        t.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.25,colors.grey),
                               ("BACKGROUND",(0,0),(-1,0),colors.lightgrey)]))
        flow.append(t)
    flow.append(Spacer(1, 8))

    # Onset
    flow.append(Paragraph("Incident Onset (WHEN)", H2))
    flow.append(Paragraph(f"Earliest credible timestamp: <b>{ts}</b>", Body))
    flow.append(Paragraph(f"Supporting evidence window: {win}", Body))
    flow.append(Spacer(1, 12))

    # Chain of Custody
    flow.append(Paragraph("Chain of Custody & Integrity", H2))
    files = (manifest.get("files") or {})
    rows = [["File", "SHA-256", "Size (bytes)"]]
    for name, meta in files.items():
        rows.append([name, meta.get("sha256",""), str(meta.get("size",""))])
    if rows:
        t2 = Table(rows, colWidths=[130, 300, 90])
        t2.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.25,colors.grey),
                                ("BACKGROUND",(0,0),(-1,0),colors.lightgrey),
                                ("FONT",(1,1),(-2,-1),"Courier",8)]))
        flow.append(t2)
    flow.append(Spacer(1, 8))
    flow.append(Paragraph(f"Bundle SHA-256: <font name='Courier'>{bundle_sha}</font>", Body))
    flow.append(Spacer(1, 12))

    # Verification Guide
    flow.append(Paragraph("Verification Guide", H2))
    flow.append(Paragraph("Use the included public_key.pem and manifest.sig to verify integrity. Example:", Body))
    flow.append(Paragraph("<font name='Courier'>python tools/verify_bundle.py bundle.zip</font>", Mono))
    flow.append(Spacer(1, 6))

    # Include commands.txt if present
    cmd = (d / "evidence_sources" / "commands.txt")
    if cmd.exists():
        flow.append(Paragraph("Reproduce Evidence (Commands)", H3))
        flow.append(Paragraph("The following commands were used to collect the evidence at the time of observation:", Body))
        try:
            text = cmd.read_text(encoding="utf-8")
            # Show as monospaced block; truncate if huge
            text = text[:4000]
            for line in text.splitlines():
                flow.append(Paragraph(line.replace(" ", "&nbsp;"), Mono))
        except Exception:
            pass
        flow.append(Spacer(1, 8))

    # Footer QR to verification doc if we can render it
    if QR_OK:
        from io import BytesIO
        qr = qrcode.make("https://example.com/silentmdmcheck/verify")  # placeholder URL
        bio = BytesIO()
        qr.save(bio, format="PNG")
        bio.seek(0)
        flow.append(Spacer(1, 12))
        flow.append(Paragraph("Learn how to verify this bundle:", Body))
        flow.append(Image(bio, width=96, height=96))

    doc.build(flow)


if __name__ == "__main__":  # pragma: no cover - manual invocation
    main()
