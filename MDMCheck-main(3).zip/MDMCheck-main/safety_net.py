#!/usr/bin/env python3
"""
Security helpers for network I/O, concurrency, and ownership verification.
"""

from __future__ import annotations
import re
import socket
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Optional, Iterable
import dns.resolver
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from concurrent.futures import ThreadPoolExecutor
import threading

SAFE_TIMEOUT = (5, 15)  # (connect, read)
MAX_WORKERS_DEFAULT = 8
MAX_PER_HOST = 4

def _retrying_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=4, connect=4, read=4, backoff_factor=0.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET","POST","PUT","PATCH","DELETE","HEAD","OPTIONS"])
    )
    adapter = HTTPAdapter(pool_connections=MAX_PER_HOST, pool_maxsize=MAX_PER_HOST, max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.verify = True           # <— enforce TLS verification
    session.trust_env = True        # honor HTTPS proxy/certs if set
    session.headers.update({"User-Agent": "SilentMDMCheck/secure-client"})
    return session

SESSION = _retrying_session()
SEM = threading.Semaphore(MAX_WORKERS_DEFAULT)

def safe_request(method: str, url: str, **kwargs) -> requests.Response:
    """Bounded, verified HTTP request with sane timeouts."""
    kwargs.setdefault("timeout", SAFE_TIMEOUT)
    with SEM:
        return SESSION.request(method.upper(), url, **kwargs)

@contextmanager
def bounded_executor(max_workers: int = MAX_WORKERS_DEFAULT):
    """ThreadPool with global semaphore to prevent resource exhaustion."""
    exec_sem = threading.Semaphore(max_workers)
    class _LimitedExecutor(ThreadPoolExecutor):
        def submit(self, fn, *a, **k):
            exec_sem.acquire()
            def _wrap(*aa, **kk):
                try:
                    return fn(*aa, **kk)
                finally:
                    exec_sem.release()
            return super().submit(_wrap, *a, **k)
    with _LimitedExecutor(max_workers=max_workers) as ex:
        yield ex

_OWNERSHIP_TOKEN_NAME = "_mdmcheck"
_OWNERSHIP_HTTP_PATH = "/.well-known/mdmcheck.txt"

@dataclass
class OwnershipProof:
    domain: str
    token: str

DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))*\.[A-Za-z]{2,}$")

def validate_domain(domain: str) -> bool:
    return bool(DOMAIN_RE.match(domain.strip().lower()))

def prove_domain_ownership(proof: OwnershipProof) -> bool:
    """
    Accept either:
      1) DNS TXT:  name=_mdmcheck.<domain>  value=<token>
      2) HTTPS file: https://<domain>/.well-known/mdmcheck.txt  (exact body == token)
    """
    domain = proof.domain.strip().lower()
    token = proof.token.strip()

    if not validate_domain(domain) or not token:
        return False

    # Method 1: DNS TXT
    try:
        resolver = dns.resolver.Resolver()
        for rr in resolver.resolve(f"{_OWNERSHIP_TOKEN_NAME}.{domain}", "TXT"):
            txt = str(rr).strip('"').strip()
            if txt == token:
                return True
    except Exception:
        pass

    # Method 2: HTTPS file
    try:
        r = safe_request("GET", f"https://{domain}{_OWNERSHIP_HTTP_PATH}")
        if r.status_code == 200 and r.text.strip() == token:
            return True
    except Exception:
        pass

    return False