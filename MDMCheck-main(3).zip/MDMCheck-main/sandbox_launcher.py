#!/usr/bin/env python3
"""
Runs notsofast.py with OS resource limits, stable env, and a wall clock timeout.
Preserves CLI, prompts, outputs, and exit codes.
"""
import os, sys, subprocess, shlex, signal, time

# Configurable limits (tune if desired)
TIMEOUT_SECONDS = 1800  # 30 minutes
MAX_OPEN_FILES = 1024
MAX_PROCS = 512
NICE_LEVEL = 10

def set_limits():
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_NOFILE, (MAX_OPEN_FILES, MAX_OPEN_FILES))
        resource.setrlimit(resource.RLIMIT_NPROC, (MAX_PROCS, MAX_PROCS))
    except Exception:
        pass

def main():
    if len(sys.argv) < 2:
        print("Usage: sandbox_launcher.py [args for notsofast.py]", file=sys.stderr)
        sys.exit(2)

    # clean env but keep PATH
    env = {
        "PATH": os.environ.get("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/bin"),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "PYTHONUNBUFFERED": "1",
        "HOME": os.environ.get("HOME", "/tmp"),
    }

    cmd = ["python3", "notsofast.py"] + sys.argv[1:]

    # lower CPU priority if possible
    preexec = None
    try:
        def _preexec():
            os.nice(NICE_LEVEL)
            set_limits()
        preexec = _preexec
    except Exception:
        pass

    proc = subprocess.Popen(
        cmd,
        env=env,
        preexec_fn=preexec,
        stdout=sys.stdout,
        stderr=sys.stderr,
        text=False,  # pass through exactly
        bufsize=0,
    )

    try:
        start = time.time()
        while True:
            ret = proc.poll()
            if ret is not None:
                sys.exit(ret)
            if time.time() - start > TIMEOUT_SECONDS:
                proc.terminate()
                try:
                    proc.wait(10)
                except Exception:
                    proc.kill()
                sys.exit(124)  # like `timeout`
            time.sleep(0.5)
    except KeyboardInterrupt:
        try:
            proc.send_signal(signal.SIGINT)
            proc.wait(10)
        finally:
            sys.exit(proc.returncode if proc.returncode is not None else 130)

if __name__ == "__main__":
    main()