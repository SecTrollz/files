#!/usr/bin/env bash
set -euo pipefail

# --- hard caps that don't alter script behavior ---
# nice/ionice: lower CPU/IO priority
# ulimit: prevent file/socket exhaustion
# stdbuf: line-buffer logs for better live viewing
# timeout: keep runaway jobs in check (adjust if you need)
# env: keep env clean and predictable

ulimit -n 1024           # max open files/sockets
ulimit -u 512            # max processes/threads
ulimit -m 0              # (informational on many systems)
ulimit -v 0              # (informational on many systems)

# 30m wall timeout, SIGTERM then SIGKILL if needed
exec timeout --preserve-status 30m \
  nice -n 10 ionice -c2 -n7 \
  stdbuf -oL -eL \
  env -i PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/bin" \
      LANG="C.UTF-8" \
      LC_ALL="C.UTF-8" \
      PYTHONUNBUFFERED="1" \
      HOME="${HOME:-/tmp}" \
  python -m notsofast "$@"
