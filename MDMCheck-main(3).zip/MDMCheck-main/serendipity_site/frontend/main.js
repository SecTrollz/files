async function loadOptions() {
  const titleEl = document.querySelector('#title');
  const bodyEl = document.querySelector('#body');
  const optionsEl = document.querySelector('#options');

  try {
    const res = await fetch('/api/options');
    if (!res.ok) throw new Error('Network response was not ok');
    const data = await res.json();
    if (optionsEl) {
      optionsEl.innerHTML = '';
      data.forEach(opt => {
        const option = document.createElement('option');
        option.value = opt.value || opt;
        option.textContent = opt.label || opt;
        optionsEl.appendChild(option);
      });
    }
    if (titleEl) titleEl.textContent = 'Options loaded';
    if (bodyEl) bodyEl.textContent = '';
  } catch (err) {
    if (titleEl) titleEl.textContent = 'Error fetching options';
    if (bodyEl) bodyEl.textContent = 'Unable to load options. Please try again.';
    if (optionsEl) optionsEl.innerHTML = '';

    let retryBtn = document.getElementById('retry-button');
    if (!retryBtn) {
      retryBtn = document.createElement('button');
      retryBtn.id = 'retry-button';
      retryBtn.textContent = 'Retry';
      retryBtn.addEventListener('click', () => {
        retryBtn.remove();
        loadOptions();
      });
      if (bodyEl) bodyEl.appendChild(retryBtn);
    }
  }
}

// Initial load
loadOptions();
