from __future__ import annotations
import os
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

ENV_KEY = "SIGNING_PRIVATE_KEY_PEM"

def load_private_key() -> ed25519.Ed25519PrivateKey:
    pem = os.getenv(ENV_KEY)
    if pem:
        if not pem.strip().startswith("-----BEGIN"):
            pem = pem.encode("utf-8")
        else:
            pem = pem.encode("utf-8")
        return serialization.load_pem_private_key(pem, password=None)
    # Fallback: dev key (DO NOT USE IN PROD)
    return ed25519.Ed25519PrivateKey.generate()

def get_public_key_pem(key: ed25519.Ed25519PrivateKey) -> str:
    pub = key.public_key()
    pem = pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return pem.decode("utf-8")

def sign_bytes(data: bytes, key: ed25519.Ed25519PrivateKey) -> bytes:
    return key.sign(data)
