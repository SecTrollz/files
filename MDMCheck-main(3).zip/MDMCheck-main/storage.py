
from __future__ import annotations
from pathlib import Path
import os, json, hashlib, time, tempfile
from typing import Optional

USE_S3 = os.getenv("STORAGE_BACKEND", "local").lower() == "s3"
S3_BUCKET = os.getenv("S3_BUCKET", "")
S3_PREFIX = os.getenv("S3_PREFIX", "bundles/").rstrip("/") + "/"
S3_REGION = os.getenv("AWS_REGION", os.getenv("AWS_DEFAULT_REGION", "us-east-1"))
PRESIGN_EXPIRES = int(os.getenv("PRESIGN_EXPIRES", "900"))  # 15 min

_s3 = None
def _client():
    global _s3
    if _s3 is None:
        import boto3
        _s3 = boto3.client("s3", region_name=S3_REGION)
    return _s3

ROOT = Path(".bundles")
QUEUE_ROOT = Path(".queue")
TMP_ROOT = Path(".tmpbundles")

def init():
    ROOT.mkdir(parents=True, exist_ok=True)
    QUEUE_ROOT.mkdir(parents=True, exist_ok=True)
    TMP_ROOT.mkdir(parents=True, exist_ok=True)

def bundle_dir(job_id: str) -> Path:
    init()
    p = TMP_ROOT / job_id if USE_S3 else ROOT / job_id
    p.mkdir(parents=True, exist_ok=True)
    return p

def write_status(job_id: str, state: str, message: str = "") -> None:
    b = bundle_dir(job_id)
    (b / "status.json").write_text(json.dumps({"state": state, "message": message}, indent=2), encoding="utf-8")

def read_status(job_id: str) -> dict:
    b = bundle_dir(job_id)
    p = b / "status.json"
    if not p.exists():
        return {"state": "unknown", "message": ""}
    return json.loads(p.read_text(encoding="utf-8"))

def write_file(job_id: str, name: str, content: bytes) -> None:
    b = bundle_dir(job_id)
    path = b / name
    path.write_bytes(content)
    if USE_S3:
        key = f"{S3_PREFIX}{job_id}/{name}"
        _client().put_object(Bucket=S3_BUCKET, Key=key, Body=content, ServerSideEncryption="aws:kms")

def file_path(job_id: str, name: str) -> Path:
    return bundle_dir(job_id) / name

def upload_dir(job_id: str) -> None:
    if not USE_S3:
        return
    b = bundle_dir(job_id)
    for p in b.glob("*"):
        if p.is_file():
            key = f"{S3_PREFIX}{job_id}/{p.name}"
            _client().put_object(Bucket=S3_BUCKET, Key=key, Body=p.read_bytes(), ServerSideEncryption="aws:kms")

def presign(job_id: str, name: str) -> Optional[str]:
    if not USE_S3:
        return None
    key = f"{S3_PREFIX}{job_id}/{name}"
    try:
        url = _client().generate_presigned_url(
            "get_object",
            Params={"Bucket": S3_BUCKET, "Key": key},
            ExpiresIn=PRESIGN_EXPIRES,
        )
        return url
    except Exception:
        return None
