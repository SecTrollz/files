"""Tests for new backend routes."""

from fastapi.testclient import TestClient

import backend.app as app_module

client = TestClient(app_module.app)


def test_myip_header() -> None:
    resp = client.get("/myip", headers={"CF-Connecting-IP": "1.2.3.4"})
    assert resp.status_code == 200
    assert resp.json() == {"ip": "1.2.3.4"}


def test_archive_success(monkeypatch) -> None:
    class MockResponse:
        def json(self) -> dict:
            return {"status": "ok"}

        def raise_for_status(self) -> None:
            pass

    def fake_get(url, headers, timeout):  # type: ignore[override]
        assert "example.com" in url
        return MockResponse()

    monkeypatch.setattr(app_module.requests, "get", fake_get)
    resp = client.post("/archive", json={"url": "https://example.com"})
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


def test_archive_missing_url() -> None:
    resp = client.post("/archive", json={})
    assert resp.status_code == 400


def test_archive_failure(monkeypatch) -> None:
    def fake_get(url, headers, timeout):  # type: ignore[override]
        raise app_module.requests.RequestException("fail")

    monkeypatch.setattr(app_module.requests, "get", fake_get)
    resp = client.post("/archive", json={"url": "https://example.com"})
    assert resp.status_code == 502


def test_subdomains_success(monkeypatch) -> None:
    monkeypatch.setattr(
        app_module.subdomain_service, "enumerate_subdomains", lambda domain: [f"www.{domain}"]
    )
    resp = client.post("/subdomains", json={"domain": "example.com"})
    assert resp.status_code == 200
    assert resp.json() == {"subdomains": ["www.example.com"]}


def test_subdomains_missing_domain() -> None:
    resp = client.post("/subdomains", json={})
    assert resp.status_code == 400
