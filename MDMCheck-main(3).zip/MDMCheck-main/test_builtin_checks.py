import backend.checks.who as who
import backend.checks.when as when
import backend.checks.root_ca as root_ca
import backend.checks.captive_portal as captive_portal
import backend.checks.oauth_probe as oauth_probe


def test_who_maps_common_provider():
    result = who.run({"email": "alice@gmail.com"})
    assert result["ok"] is True
    assert result["detail"].get("provider") == "Google"


def test_when_uses_known_launch_for_common_provider():
    result = when.run({"email": "bob@gmail.com"})
    assert result["ok"] is True
    detail = result["detail"]
    assert "certificate_not_before" in detail or "domain_creation" in detail or "known_launch" in detail
    if "known_launch" in detail:
        assert detail["known_launch"] == "2004-04-01"


def test_who_uses_whois_when_provider_unknown(monkeypatch):
    monkeypatch.setattr(who.dns.resolver, "resolve", lambda *a, **k: (_ for _ in ()).throw(Exception()))

    class FakeWhois:
        def __init__(self):
            self.org = "Example Corp"
            self.name = None

        def get(self, key):  # mimic dict-like access from python-whois
            return getattr(self, key, None)

    import types
    monkeypatch.setattr(who, "whois", types.SimpleNamespace(whois=lambda domain: FakeWhois()))
    result = who.run({"email": "user@unknown.example"})
    assert result["ok"] is True
    assert result["detail"].get("registrant") == "Example Corp"


def test_when_uses_dns_serial_as_fallback(monkeypatch):
    monkeypatch.setattr(when, "_lookup_certificate", lambda domain: None)
    monkeypatch.setattr(when, "_lookup_whois", lambda domain: None)

    class SOA:
        serial = 2024010101

    monkeypatch.setattr(when.dns.resolver, "resolve", lambda *a, **k: [SOA()])
    result = when.run({"domain": "example.com"})
    assert result["ok"] is True
    assert result["detail"].get("dns_serial") == "2024-01-01"

TEST_CERT = """-----BEGIN CERTIFICATE-----\nMIIDBTCCAe2gAwIBAgIUafyzIte8SS6nZzVQBOKR0bHUZqkwDQYJKoZIhvcNAQEL\nBQAwEjEQMA4GA1UEAwwHVGVzdCBDQTAeFw0yNTA5MTIxOTE3NDFaFw0yNTA5MTMx\nOTE3NDFaMBIxEDAOBgNVBAMMB1Rlc3QgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IB\nDwAwggEKAoIBAQCkYmSruWdwDe5D76IdC10x1WCGw1Kx+J7hdlqq5QrTEl5pV6vu\nBf6EU8R3ZXSi/pKkkSXMbS6VQPfphA2P/XyfLMSrNGv8hcVbmnARD4apRPLNf7SN\nz2kFm//qssqSzAvJAsdN1L99V57F8CGdAe4sKTDjeVdl8nh/zHdWtU0xtYUImS4r\nv9/JqPuxFWpjmPDRtBDxJXVz42hYG4iyg1vgqZgWsvIbcIsM7MZIA1zTrC6qXY3r\nFCDkpPwRQecu3TSWuCra+9LLgLyxntgKJLmaL58Jaoe5dstZB9SqeRpr3FaLTggg\nQyVJCdWTUkgTVFZylL5RuBQUjZE0/cxw1pq3AgMBAAGjUzBRMB0GA1UdDgQWBBRO\nRo7CPNwmcB37xSC3pAmhVIixXzAfBgNVHSMEGDAWgBRORo7CPNwmcB37xSC3pAmh\nVIixXzAPBgNVHRMBAf8EBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBzUEuJrodw\nqwqI44WbXprfxL2vum/4aFAi8vsb++DIcCBoM8ekP3nW+gdSU3f10xW4F1GTFPxi\n9swkEXEVkkrRcjE7RHBUUYtjuMFMKT55/UBNU0bGjsE5+iot9csQttao7H4hwDCx\nBbShaX3Vl4VITWCpTlER9L0WMu9YHRtfaTyOrMaA7I01oJawn2lKfV5kODMuKH06\n98qUtOF3xN7UjQMiqPqZ8UqWk2oJ62PXik5X0Zv2zPk18I8/BQGCKivdul0WwLQJ\ntLiXBfI0o8RMt7j669krSDCvycBaHTIwwvJrT3i6KUZxLpyxfDLZ8/NoaJjnzFjJ\npptnK1zYI3s0\n-----END CERTIFICATE-----\n"""

def test_root_ca_issuer_extracted():
    result = root_ca.run({"certificate": TEST_CERT})
    assert result["ok"] is True
    assert result["detail"]["issuer"]["commonName"] == "Test CA"


def test_captive_portal_detection(monkeypatch):
    class Resp:
        status_code = 200
    monkeypatch.setattr(captive_portal.requests, "get", lambda *a, **k: Resp())
    result = captive_portal.run()
    assert result["ok"] is False
    assert result["detail"]["status_code"] == 200


def test_oauth_probe_flags_bad_domain():
    result = oauth_probe.run({"provider": "google", "login_url": "https://evil.example.com"})
    assert result["ok"] is False
    assert result["detail"]["expected_domain"] == "accounts.google.com"


def test_who_follows_cname_and_validates(monkeypatch):
    """Ensure MX chains and WHOIS validation tie provider to registrant."""

    class MX:
        exchange = type("_", (), {"to_text": lambda self: "mx.example.com."})()

    class CNAME:
        target = type("_", (), {"to_text": lambda self: "aspmx.l.google.com."})()

    def fake_resolve(name, rtype):
        if (name, rtype) == ("example.com", "MX"):
            return [MX()]
        if (name.rstrip("."), rtype) == ("mx.example.com", "CNAME"):
            return [CNAME()]
        raise Exception("unpatched query")

    import types

    class FakeWhois:
        def __init__(self, org):
            self.org = org
            self.name = None

        def get(self, key):
            return getattr(self, key, None)

    def fake_whois(domain):
        if domain == "example.com":
            return FakeWhois("Example Corp")
        if domain == "google.com":
            return FakeWhois("Google LLC")
        raise Exception("unknown domain")

    monkeypatch.setattr(who.dns.resolver, "resolve", fake_resolve)
    monkeypatch.setattr(who, "whois", types.SimpleNamespace(whois=fake_whois))

    result = who.run({"domain": "example.com"})
    assert result["ok"] is True
    detail = result["detail"]
    assert detail["provider"] == "Google"
    assert detail.get("validated") is True
