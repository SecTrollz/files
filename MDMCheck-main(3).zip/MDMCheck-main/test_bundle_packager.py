"""
Contract tests for bundle_packager.py

Guarantees:
- All files added to a bundle are canonicalized under the base directory.
- Path traversal and symlinks are rejected.
- Files larger than MAX_FILE_BYTES are rejected.
- Manifest includes correct SHA-256 for each file.
"""

from __future__ import annotations
import hashlib
import json
import pathlib
import pytest

def _import_mod():
    try:
        import bundle_packager as mod
        return mod
    except Exception as e:
        pytest.skip(f"bundle_packager not importable: {e}")

def _find_fn(mod, names):
    for n in names:
        if hasattr(mod, n) and callable(getattr(mod, n)):
            return getattr(mod, n)
    return None

@pytest.fixture
def tmpd(tmp_path: pathlib.Path) -> pathlib.Path:
    return tmp_path

def _write(p: pathlib.Path, data: bytes) -> str:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    return hashlib.sha256(data).hexdigest()

def test_add_path_rejects_traversal(tmpd):
    mod = _import_mod()
    add_path = _find_fn(mod, ("add_path",))
    if add_path is None:
        pytest.skip("bundle_packager.add_path not found; please implement")
    base = tmpd / "root"
    base.mkdir()
    evil = pathlib.Path("../escape.txt")
    with pytest.raises(Exception):
        add_path(base, evil)

def test_add_path_rejects_symlink(tmpd):
    mod = _import_mod()
    add_path = _find_fn(mod, ("add_path",))
    if add_path is None:
        pytest.skip("bundle_packager.add_path not found")
    base = tmpd / "root"
    base.mkdir()
    target = base / "real.txt"
    target.write_text("ok")
    link = base / "link"
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError):
        pytest.skip("Symlinks not supported here")
    with pytest.raises(Exception):
        add_path(base, link)

def test_size_limit(tmpd):
    mod = _import_mod()
    max_bytes = getattr(mod, "MAX_FILE_BYTES", 1024 * 1024)
    create_bundle = _find_fn(mod, ("create_bundle",))
    if create_bundle is None:
        pytest.skip("bundle_packager.create_bundle not found")

    big = tmpd / "root" / "big.bin"
    big.parent.mkdir(parents=True, exist_ok=True)
    big.write_bytes(b"\x00" * (max_bytes + 1))
    out = tmpd / "bundle.out"
    with pytest.raises(Exception):
        create_bundle(tmpd / "root", out)

def test_manifest_contains_sha256(tmpd):
    mod = _import_mod()
    create_bundle = _find_fn(mod, ("create_bundle",))
    if create_bundle is None:
        pytest.skip("bundle_packager.create_bundle not found")

    f = tmpd / "root" / "file.txt"
    expected_hash = _write(f, b"hello world")
    out = tmpd / "bundle.out"
    create_bundle(tmpd / "root", out)

    manifest = json.loads((out / "manifest.json").read_text())
    entries = {e["path"]: e["sha256"] for e in manifest.get("files", [])}
    assert "file.txt" in entries
    assert entries["file.txt"] == expected_hash