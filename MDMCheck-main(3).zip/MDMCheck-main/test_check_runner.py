from pathlib import Path
import importlib

from backend.check_runner import CHECKS_DIR, run_all_checks, average_score


def test_new_check_auto_discovered():
    mod_path = CHECKS_DIR / "temp_test_check.py"
    mod_path.write_text("def run():\n    return {'ok': True, 'score': 5}")
    try:
        importlib.invalidate_caches()
        results = run_all_checks()
        names = {r.get('name') for r in results}
        assert 'temp_test_check' in names
        avg = average_score(results)
        assert isinstance(avg, float) and avg > 0
    finally:
        mod_path.unlink(missing_ok=True)
        importlib.invalidate_caches()
