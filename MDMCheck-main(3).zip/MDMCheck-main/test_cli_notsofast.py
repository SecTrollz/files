"""
CLI contract tests for notsofast.py

Goals:
- `--help` prints usage and exits 0.
- Invalid flags/values exit non-zero with a useful error.
- JSON logging is emitted (level/logger/msg/time) when running a trivial command.
- `--mode {quick,extended}` is validated; unknown modes are rejected.
- The CLI exposes a `main(argv=None)` entrypoint compatible with console_scripts.

These tests SKIP gracefully if main() is not yet implemented, but with actionable messages.
"""

from __future__ import annotations
import json
import logging
import sys
import pytest

def _import_mod():
    try:
        import notsofast as mod
        return mod
    except Exception as e:
        pytest.skip(f"notsofast not importable: {e}")

def _has_main(mod) -> bool:
    return hasattr(mod, "main") and callable(getattr(mod, "main"))

@pytest.fixture(autouse=True)
def _debug_logs(monkeypatch):
    # Max verbosity for troubleshooting
    monkeypatch.setenv("MDMCHECK_LOG_LEVEL", "DEBUG")

def test_help_exits_zero(capfd, monkeypatch):
    mod = _import_mod()
    if not _has_main(mod):
        pytest.skip("notsofast.main() not implemented; add a CLI entrypoint")

    monkeypatch.setattr(sys, "argv", ["notsofast", "--help"])
    with pytest.raises(SystemExit) as e:
        mod.main()
    assert e.value.code == 0, "Expected --help to exit with code 0"
    out, err = capfd.readouterr()
    assert "usage" in (out + err).lower()
    assert "--mode" in (out + err)

@pytest.mark.parametrize("bad_args", [
    ["--mode"],                    # missing value
    ["--mode", "unknown"],         # invalid mode
    ["--does-not-exist"],          # unknown flag
])
def test_invalid_args_fail_usefully(bad_args, capfd, monkeypatch):
    mod = _import_mod()
    if not _has_main(mod):
        pytest.skip("notsofast.main() not implemented")

    monkeypatch.setattr(sys, "argv", ["notsofast"] + bad_args)
    with pytest.raises(SystemExit) as e:
        mod.main()
    assert e.value.code != 0, "Invalid args should exit non-zero"
    out, err = capfd.readouterr()
    msg = (out + err).lower()
    assert "error" in msg or "invalid" in msg or "unrecognized" in msg, \
        "Expected a clear validation error message for bad args"

def test_quick_mode_runs_and_logs_json(capfd, monkeypatch, tmp_path):
    mod = _import_mod()
    if not _has_main(mod):
        pytest.skip("notsofast.main() not implemented")

    # Prefer a no-op-ish run that still exercises logging and control flow
    outdir = tmp_path / "out"
    monkeypatch.setattr(sys, "argv", ["notsofast", "--mode", "quick", "--output", str(outdir)])
    try:
        # main may sys.exit(); accept 0 as success
        mod.main()
    except SystemExit as e:
        assert e.code == 0

    # Expect JSON log line on stdout/stderr (from logging_config)
    out, err = capfd.readouterr()
    stream = out.strip() or err.strip()
    assert stream, "Expected some log output from notsofast"
    # Try to parse the first JSON line (some CLIs may print multiple lines)
    first_line = stream.splitlines()[0]
    try:
        js = json.loads(first_line)
    except json.JSONDecodeError:
        pytest.skip("Logs not JSON-formatted; ensure logging_config.configure_logging() is called in main()")
    assert {"level", "logger", "msg", "time"} <= set(js.keys())

def test_extended_mode_is_supported_or_rejected_clearly(capfd, monkeypatch):
    mod = _import_mod()
    if not _has_main(mod):
        pytest.skip("notsofast.main() not implemented")

    monkeypatch.setattr(sys, "argv", ["notsofast", "--mode", "extended"])
    try:
        mod.main()
    except SystemExit as e:
        # Either extended is supported (0) or clearly rejected (!=0) with a message
        out, err = capfd.readouterr()
        if e.code == 0:
            assert "extended" in (out + err).lower()
        else:
            msg = (out + err).lower()
            assert "unsupported" in msg or "not implemented" in msg or "invalid" in msg, \
                "If extended mode isn't implemented, explain it clearly"