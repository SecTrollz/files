from __future__ import annotations
import json
import pytest
import notsofast_compare as cmp

BASE = {
    "probes": [
        {"name": "dns", "ok": True, "detail": {}},
        {"name": "net", "ok": False, "detail": {}},
    ]
}
CURR = {
    "probes": [
        {"name": "dns", "ok": False, "detail": {}},   # regressed
        {"name": "newp", "ok": False, "detail": {}},  # new fail
    ]
}

def test_diff_json_mode(capsys, tmp_path):
    b = tmp_path / "b.json"
    c = tmp_path / "c.json"
    b.write_text(json.dumps(BASE))
    c.write_text(json.dumps(CURR))

    with pytest.raises(SystemExit) as e:
        cmp.main(["--json", str(b), str(c)])

    out = capsys.readouterr().out
    data = json.loads(out)
    # Summary should reflect 1 regression (dns) and 1 new fail (newp)
    assert data["summary"]["regressed"] == 1
    assert data["summary"]["new_fail"] == 1
    # Diff should include newp as new_fail
    assert any(d["name"] == "newp" and d["change"] == "new_fail" for d in data["diff"])
    # CI-failing exit when regressions exist
    assert e.value.code == 4

def test_diff_pretty_mode(capsys, tmp_path):
    b = tmp_path / "b.json"
    c = tmp_path / "c.json"
    b.write_text(json.dumps(BASE))
    c.write_text(json.dumps(CURR))

    with pytest.raises(SystemExit) as e:
        cmp.main(["--pretty", str(b), str(c)])

    out = capsys.readouterr().out
    # Human-readable markers/phrases should appear
    assert "regressed" in out.lower()
    assert "new fail" in out.lower()
    # Same non-zero code when regressions exist
    assert e.value.code == 4