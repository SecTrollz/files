def test_cross_verify_pass(monkeypatch):
    from backend.checks import cross_verify, root_ca

    monkeypatch.setattr(root_ca, 'run', lambda ctx: {'ok': True, 'detail': {'issuer': {'commonName': 'Google Trust Services'}}})
    result = cross_verify.run({'email': 'user@gmail.com', 'certificate': 'dummy'})
    assert result['ok'] is True
    assert 'mismatch' not in result['detail']


def test_cross_verify_mismatch(monkeypatch):
    from backend.checks import cross_verify, root_ca

    monkeypatch.setattr(root_ca, 'run', lambda ctx: {'ok': True, 'detail': {'issuer': {'commonName': 'Evil CA'}}})
    result = cross_verify.run({'email': 'user@gmail.com', 'certificate': 'dummy'})
    assert result['ok'] is False
    assert 'mismatch' in result['detail']
