# tests/test_imports.py
import importlib
import pytest

@pytest.mark.parametrize("mod", [
    "notsofast",
    "notsofastextended",
    "verify_bundle",
    "bundle_packager",
    "backend.services.mitm_detector",
])
def test_modules_import(mod):
    try:
        importlib.import_module(mod)
    except Exception as e:
        pytest.fail(f"Failed importing {mod}: {e}")