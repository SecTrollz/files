# tests/test_logging_format.py
import json
import logging

from logging_config import configure_logging


def test_json_logging_structure(capfd):
    configure_logging()
    log = logging.getLogger("mdmcheck.test")
    log.info("hello world")
    out, err = capfd.readouterr()
    assert out.strip(), "No log output captured on stdout"
    data = json.loads(out)
    expected = {"level", "logger", "msg", "time", "session_id", "integrity_hash"}
    assert expected <= data.keys()
    assert data["msg"] == "hello world"

