"""
Contract tests for ``backend/services/mitm_detector.py``

Goals:
- Inputs are validated/normalized; garbage is rejected with clear exceptions.
- Network probes honor timeouts and never use shell=True.
- Structured JSON logging is emitted.
- DNS/SSL/TLS probe functions can be mocked; tests don't require network.

These tests 'discover' functions dynamically so you can evolve the module
without constantly rewriting tests. Missing pieces are SKIPPED with actionable messages.
"""

from __future__ import annotations
import json
import logging
import inspect
import subprocess
import pytest


def _import_mod():
    try:
        from backend.services import mitm_detector as mod
        return mod
    except Exception as e:
        pytest.skip(f"backend.services.mitm_detector not importable: {e}")


def _find_fn(mod, names):
    for n in names:
        fn = getattr(mod, n, None)
        if callable(fn):
            return fn
    return None


@pytest.fixture(autouse=True, scope="module")
def _debug_logs():
    # Ensure we see maximum detail during tests
    import os
    os.environ.setdefault("MDMCHECK_LOG_LEVEL", "DEBUG")


# ---------- Input validation / normalization ----------

def test_validate_target_rejects_bad_values():
    mod = _import_mod()
    validator = _find_fn(mod, ("validate_target", "normalize_target"))
    if validator is None:
        pytest.skip("No validate_target/normalize_target found; please implement a strict validator")

    bad_values = ["", " ", " http://", "://", "..", "/", "\\", "\x00", "a" * 4096]
    for val in bad_values:
        with pytest.raises(Exception):
            validator(val)

def test_validate_target_accepts_domain_and_returns_normalized():
    mod = _import_mod()
    validator = _find_fn(mod, ("validate_target", "normalize_target"))
    if validator is None:
        pytest.skip("No validator implemented")

    ok = validator("Example.COM")
    # allow True/normalized string return; but it must not raise
    assert ok is True or isinstance(ok, str)


# ---------- Subprocess safety (no shell=True, enforce timeouts) ----------

def test_subprocess_never_shell_true(monkeypatch):
    mod = _import_mod()

    # Find any function that calls subprocess.run
    suspects = []
    for name in dir(mod):
        obj = getattr(mod, name)
        if callable(obj):
            try:
                src = inspect.getsource(obj)
            except (OSError, TypeError):
                continue
            if "subprocess.run" in src:
                suspects.append(obj)

    if not suspects:
        pytest.skip("No subprocess.run usage found; if you add probes using subprocess, route through a helper with timeouts")

    called = {}
    def fake_run(cmd, *args, **kwargs):
        called["cmd"] = cmd
        called["kwargs"] = kwargs
        # Succeed quickly without touching the real system
        return subprocess.CompletedProcess(cmd, 0, "", "")

    monkeypatch.setattr(subprocess, "run", fake_run)

    # Try to invoke first suspect with best-effort defaults
    fn = suspects[0]
    try:
        # call with no args if possible; else skip with message
        fn()  # noqa: FBT003
    except TypeError:
        pytest.skip(f"{fn.__name__} requires args; add a small wrapper suitable for testing")

    assert isinstance(called.get("cmd"), (list, tuple)), "subprocess.run must receive list/tuple, not string"
    assert not called["kwargs"].get("shell"), "shell=True is forbidden for security"
    assert "timeout" in called["kwargs"], "subprocess.run must specify a timeout"


# ---------- Probes honor timeouts (socket/aiohttp/etc.) ----------

@pytest.mark.parametrize("probe_name", [
    "probe_dns",
    "probe_tls",
    "probe_http",
])
def test_probes_accept_timeout_param(monkeypatch, probe_name):
    mod = _import_mod()
    probe = getattr(mod, probe_name, None)
    if probe is None or not callable(probe):
        pytest.skip(f"{probe_name} not implemented; please add it or adjust test list")

    # Introspect signature: require a timeout or **kwargs to pass timeout
    sig = inspect.signature(probe)
    if "timeout" not in sig.parameters and not any(p.kind == p.VAR_KEYWORD for p in sig.parameters.values()):
        pytest.skip(f"{probe_name} should accept a 'timeout' parameter or **kwargs")

    # Monkeypatch any network dependency inside the probe if used (example: socket.getaddrinfo)
    # We do this defensively; if attribute isn't used, no problem.
    try:
        import socket
        monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [])
    except Exception:
        pass

    try:
        # We care that calling with timeout doesn't raise synchronously for parameter handling.
        probe("example.com", timeout=1.0)
    except Exception:
        # It's OK for probe to raise a custom exception (e.g., timeout or connect error), so don't assert here.
        pass


# ---------- JSON logging presence ----------

def test_logs_are_json(capfd):
    # Emit a log and ensure it parses as JSON (formatter from logging_config)
    log = logging.getLogger("mdmcheck.mitmdetector.test")
    log.info("probe start")
    out, err = capfd.readouterr()
    stream = out or err
    assert stream.strip(), "No log output captured"
    try:
        js = json.loads(stream)
    except json.JSONDecodeError:
        pytest.skip("Logs are not JSON-formatted; ensure logging_config.configure_logging() is called")
    assert {"level", "logger", "msg", "time"} <= set(js.keys())


# ---------- Property-based (optional if Hypothesis installed) ----------

hypothesis = pytest.importorskip("hypothesis", reason="Install hypothesis to enable property tests")
from hypothesis import given, strategies as st  # type: ignore  # noqa: E402


@given(st.text(min_size=0, max_size=256))
def test_validator_never_crashes_on_random_input(s):
    mod = _import_mod()
    validator = _find_fn(mod, ("validate_target", "normalize_target"))
    if validator is None:
        pytest.skip("No validator implemented")
    try:
        validator(s)
    except Exception:
        # Rejections are fine; we only assert no unexpected type errors or crashes
        pass