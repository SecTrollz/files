"""
Contract tests for notsofast_report.py + notsofast_formatter.py.

Focus:
- JSON mode returns valid JSON and adds summary.
- Pretty mode produces a table with ✓/✗ marks.
- Passthrough behavior: if stdout isn't JSON, it's emitted verbatim.
- PDF generation hook: returns False cleanly if pdf_report is missing.
"""

from __future__ import annotations
import io
import json
import sys
import types
import pytest

import notsofast_formatter as fmt
import notsofast_report as report


# ---------- Formatter tests ----------

def test_summary_computation():
    sample = {
        "mode": "quick",
        "probes": [
            {"name": "one", "ok": True, "detail": {"foo": "bar"}},
            {"name": "two", "ok": False, "detail": {"error": "bad"}},
        ],
    }
    doc = json.loads(fmt.format_json(sample))
    assert "summary" in doc
    s = doc["summary"]
    assert s["total_probes"] == 2
    assert s["passed"] == 1
    assert s["failed"] == 1

def test_pretty_format_includes_marks():
    sample = {
        "mode": "quick",
        "started": "now",
        "host": {"hostname": "h", "system": "Linux", "release": "1", "python": "3"},
        "probes": [
            {"name": "dns", "ok": True, "detail": {"addresses": ["1.1.1.1"], "target": "example.com"}},
            {"name": "net_tools", "ok": False, "detail": {"error": "missing"}},
        ],
    }
    out = fmt.format_pretty(sample)
    # Must include both ✓ and ✗
    assert "✓" in out
    assert "✗" in out
    # Must show gist details
    assert "example.com" in out or "missing" in out


def test_pdf_generation_fails_cleanly(tmp_path, monkeypatch):
    sample = {"mode": "quick", "probes": []}
    # Force import error
    monkeypatch.setitem(sys.modules, "pdf_report", None)
    ok = fmt.maybe_generate_pdf(sample, str(tmp_path / "out.pdf"))
    assert ok is False


# ---------- Report wrapper tests ----------

class DummyCompleted:
    def __init__(self, returncode: int, stdout: str = "", stderr: str = ""):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr


def test_passthrough_non_json(monkeypatch, capsys):
    # Patch _run_notsofast to return plain text
    monkeypatch.setattr(report, "_run_notsofast", lambda args, timeout: DummyCompleted(0, stdout="hello\n"))
    sys.argv = ["notsofast-report", "--json", "--", "--mode", "quick"]
    with pytest.raises(SystemExit) as e:
        report.main()
    # Should exit 0 and emit the raw text
    captured = capsys.readouterr()
    assert "hello" in captured.out
    assert e.value.code == 0


def test_json_mode_outputs_summary(monkeypatch, capsys):
    sample = {"mode": "quick", "probes": [{"name": "x", "ok": True, "detail": {}}]}
    monkeypatch.setattr(report, "_run_notsofast", lambda args, timeout: DummyCompleted(0, stdout=json.dumps(sample)))
    sys.argv = ["notsofast-report", "--json", "--", "--mode", "quick", "--json"]
    with pytest.raises(SystemExit) as e:
        report.main()
    out = capsys.readouterr().out
    data = json.loads(out)
    assert "summary" in data
    assert e.value.code == 0


def test_pretty_mode_outputs_table(monkeypatch, capsys):
    sample = {
        "mode": "quick",
        "started": "now",
        "host": {"hostname": "h", "system": "Linux", "release": "1", "python": "3"},
        "probes": [{"name": "x", "ok": True, "detail": {}}],
    }
    monkeypatch.setattr(report, "_run_notsofast", lambda args, timeout: DummyCompleted(0, stdout=json.dumps(sample)))
    sys.argv = ["notsofast-report", "--pretty", "--", "--mode", "quick", "--json"]
    with pytest.raises(SystemExit) as e:
        report.main()
    out = capsys.readouterr().out
    assert "✓" in out
    assert "Summary:" in out
    assert e.value.code == 0


def test_propagates_failure_code(monkeypatch, capsys):
    monkeypatch.setattr(report, "_run_notsofast", lambda args, timeout: DummyCompleted(2, stdout="", stderr="bad\n"))
    sys.argv = ["notsofast-report", "--json", "--", "--mode", "quick"]
    with pytest.raises(SystemExit) as e:
        report.main()
    err = capsys.readouterr().err
    assert "bad" in err
    assert e.value.code == 2