import json, tempfile, os
from pathlib import Path

import pdf_report


def test_redaction_replaces_detail():
    data = {"probes": [{"name": "p", "detail": {"secret": "x"}}]}
    red = pdf_report._redact_results(data)
    assert red["probes"][0]["detail"] == "[redacted]"


def test_cli_generates_pdf(tmp_path: Path):
    data = {"probes": [{"name": "p", "ok": True, "score": 1.0, "detail": {"secret": "x"}}]}
    inp = tmp_path / "res.json"
    out = tmp_path / "out.pdf"
    inp.write_text(json.dumps(data), encoding="utf-8")
    pdf_report.main(["--input", str(inp), "--output", str(out)])
    assert out.exists()
    assert out.stat().st_size > 0
