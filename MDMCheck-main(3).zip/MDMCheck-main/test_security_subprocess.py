# tests/test_security_subprocess.py
import builtins
import inspect
import subprocess
import pytest

def _find_proc_wrappers():
    wrappers = []
    for name in ("commands_helper", "notsofast", "notsofastextended"):
        try:
            mod = __import__(name)
        except Exception:
            continue
        for attr in dir(mod):
            fn = getattr(mod, attr)
            if callable(fn) and inspect.isfunction(fn) and "subprocess" in inspect.getsource(fn):
                wrappers.append((name, attr, fn))
    return wrappers

def test_subprocess_calls_use_list_and_timeout(monkeypatch):
    wrappers = _find_proc_wrappers()
    if not wrappers:
        pytest.skip("No subprocess wrapper functions found; please route subprocess usage through a helper")

    called = {}
    def fake_run(cmd, *args, **kwargs):
        called["cmd"] = cmd
        called["kwargs"] = kwargs
        return subprocess.CompletedProcess(cmd, 0, "", "")

    monkeypatch.setattr(subprocess, "run", fake_run)

    # Invoke first found wrapper safely if it has no required params
    name, attr, fn = wrappers[0]
    try:
        fn()  # best-effort; if it requires args, skip gracefully
    except TypeError:
        pytest.skip(f"{name}.{attr} requires args; add a small wrapper suitable for testing")

    assert isinstance(called.get("cmd"), (list, tuple)), "subprocess.run must get list/tuple, not string"
    assert "timeout" in called.get("kwargs", {}), "subprocess.run must include a timeout"