"""
Contract tests for verify_bundle.py

These tests assert security and correctness behaviors that every release must preserve:

- Path safety: candidate paths are canonicalized under an allow-listed base,
  symlinks and traversal are rejected.
- Bundle validation: a manifest defines files + SHA256; tampering is detected.
- Size limits: oversized files are rejected before reading fully.
- Logging: errors are emitted as JSON-structured logs (level, logger, msg, time)
- Signature: if a signature verifier exists, valid sig passes and invalid fails.

They adapt to different internal APIs:
- Functions discovered dynamically by name:
  safe_path / canonicalize / validate_path
  compute_sha256
  load_manifest
  verify (single-bundle verification) OR main(argv) for CLI-style verification
  verify_signature (optional)
If any required function is missing, the corresponding test marks a clear, actionable SKIP.
"""

from __future__ import annotations
import io
import json
import os
import stat
import hashlib
import pathlib
import tarfile
import tempfile
from typing import Dict, Any, Tuple, Callable, Optional

import pytest

# ---------- Helpers to discover API in verify_bundle.py ----------

def _import_mod():
    try:
        import verify_bundle as mod
        return mod
    except Exception as e:
        pytest.skip(f"verify_bundle not importable: {e}")

def _find_fn(mod, names):
    for n in names:
        if hasattr(mod, n) and callable(getattr(mod, n)):
            return getattr(mod, n)
    return None

# ---------- Bundle fabrication utilities (directory- and tar-based) ----------

def _write_file(p: pathlib.Path, data: bytes) -> str:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    h = hashlib.sha256(data).hexdigest()
    return h

def _make_bundle_dir(base: pathlib.Path) -> Tuple[pathlib.Path, Dict[str, str]]:
    """Create a minimal bundle directory with manifest.json and two files."""
    bundle = base / "bundle_dir"
    files = {
        "logs/app.log": b"hello\n",
        "evidence/info.txt": b"DEVICE=demo\n",
    }
    shas: Dict[str, str] = {}
    for rel, data in files.items():
        shas[rel] = _write_file(bundle / rel, data)

    manifest = {
        "bundle_schema_version": "1",
        "files": [{"path": k, "sha256": v} for k, v in shas.items()],
    }
    (bundle / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return bundle, shas

def _make_bundle_tar(base: pathlib.Path) -> pathlib.Path:
    bundle_dir, _ = _make_bundle_dir(base)
    tar_path = base / "bundle.tar"
    with tarfile.open(tar_path, "w") as tf:
        for p in bundle_dir.rglob("*"):
            tf.add(p, arcname=p.relative_to(bundle_dir))
    return tar_path

# ---------- Fixtures ----------

@pytest.fixture
def tmpd(tmp_path: pathlib.Path) -> pathlib.Path:
    return tmp_path

@pytest.fixture(autouse=True, scope="module")
def _force_debug_logging():
    os.environ.setdefault("MDMCHECK_LOG_LEVEL", "DEBUG")

# ---------- Tests: Path safety primitives ----------

def test_safe_path_rejects_traversal(tmpd, capfd):
    mod = _import_mod()
    safe = _find_fn(mod, ("safe_path", "canonicalize", "validate_path"))
    if safe is None:
        pytest.skip("No safe_path/canonicalize/validate_path found in verify_bundle.py; please implement")

    base = tmpd / "root"
    base.mkdir()
    with pytest.raises(Exception):
        safe(base, pathlib.Path("../evil.txt"))  # should reject traversal
    out, _ = capfd.readouterr()
    # If logging is JSON, this will parse; else we ignore parsing.
    try:
        js = json.loads(out or "{}")
        assert js.get("level") in ("ERROR", "WARNING")
    except json.JSONDecodeError:
        pass

def test_safe_path_rejects_symlink(tmpd):
    mod = _import_mod()
    safe = _find_fn(mod, ("safe_path", "canonicalize", "validate_path"))
    if safe is None:
        pytest.skip("No safe_path/canonicalize/validate_path found; please implement")

    base = tmpd / "base"
    base.mkdir()
    target = base / "real.txt"
    target.write_text("ok")
    link = base / "link"
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError):
        pytest.skip("Symlinks not supported on this platform")
    with pytest.raises(Exception):
        safe(base, link)

# ---------- Tests: Hashing and manifest ----------

def test_compute_sha256_matches_python_hash(tmpd):
    mod = _import_mod()
    compute = _find_fn(mod, ("compute_sha256",))
    if compute is None:
        pytest.skip("compute_sha256 not found; please implement")

    f = tmpd / "x.bin"
    data = b"abc" * 100
    h = hashlib.sha256(data).hexdigest()
    f.write_bytes(data)
    assert compute(f) == h, "compute_sha256 must match hashlib.sha256"

def test_load_manifest_and_file_set(tmpd):
    mod = _import_mod()
    loader = _find_fn(mod, ("load_manifest",))
    if loader is None:
        pytest.skip("load_manifest not found; please implement")

    bundle_dir, shas = _make_bundle_dir(tmpd)
    manifest = loader(bundle_dir / "manifest.json")
    assert isinstance(manifest, dict)
    # minimal contract
    files = {e["path"]: e["sha256"] for e in manifest.get("files", [])}
    assert files == shas

# ---------- Tests: Verification workflow (directory or tar) ----------

def _discover_verifier(mod):
    ver = _find_fn(mod, ("verify",))  # function verify(bundle_path) -> bool or raises
    if ver:
        return ("function", ver)
    main = _find_fn(mod, ("main",))
    if main:
        return ("cli", main)
    return (None, None)

def test_verify_success_for_pristine_bundle(tmpd, capfd):
    mod = _import_mod()
    mode, entry = _discover_verifier(mod)
    if mode is None:
        pytest.skip("No verify() or main() in verify_bundle.py; please implement one")

    # Try directory-style
    bundle_dir, _ = _make_bundle_dir(tmpd)

    if mode == "function":
        ok = entry(bundle_dir)
        assert ok is True or ok is None  # allow True or None (no news is good news)
    else:
        # CLI should exit 0 on success
        import sys
        old_argv = sys.argv[:]
        try:
            sys.argv = ["verify_bundle.py", str(bundle_dir)]
            with pytest.raises(SystemExit) as e:
                entry()
            assert e.value.code == 0
        finally:
            sys.argv = old_argv
    out, err = capfd.readouterr()
    # Ensure at least one JSON-ish log arrives
    try:
        js = json.loads(out.strip() or "{}")
        assert "level" in js and "msg" in js
    except json.JSONDecodeError:
        # If logs emitted to stderr, try parsing there
        try:
            js = json.loads(err.strip() or "{}")
            assert "level" in js and "msg" in js
        except json.JSONDecodeError:
            # tolerate non-JSON logs but flag as improvement area
            pass

def test_verify_detects_tamper(tmpd):
    mod = _import_mod()
    mode, entry = _discover_verifier(mod)
    if mode is None:
        pytest.skip("No verify() or main() in verify_bundle.py; please implement one")

    bundle_dir, shas = _make_bundle_dir(tmpd)
    # Tamper with a file
    (bundle_dir / "logs" / "app.log").write_text("hacked\n")

    if mode == "function":
        with pytest.raises(Exception):
            entry(bundle_dir)
    else:
        import sys
        old_argv = sys.argv[:]
        try:
            sys.argv = ["verify_bundle.py", str(bundle_dir)]
            with pytest.raises(SystemExit) as e:
                entry()
            assert e.value.code != 0
        finally:
            sys.argv = old_argv

# ---------- Tests: Size limits & early rejection ----------

def test_rejects_oversized_file(tmpd):
    mod = _import_mod()
    # Either constant or function to enforce size; test adapts
    size_limit = getattr(mod, "MAX_FILE_BYTES", None)
    if size_limit is None:
        size_limit = 1_000_000  # 1 MB default expectation; adjust in code to pass strictly

    bundle_dir, shas = _make_bundle_dir(tmpd)
    big_path = bundle_dir / "evidence" / "big.bin"
    big_path.parent.mkdir(parents=True, exist_ok=True)
    big_path.write_bytes(b"\x00" * (int(size_limit) + 1))

    # Update manifest to include big file (to force verifier to look at it)
    manifest_p = bundle_dir / "manifest.json"
    manifest = json.loads(manifest_p.read_text())
    manifest["files"].append({"path": "evidence/big.bin", "sha256": hashlib.sha256(big_path.read_bytes()).hexdigest()})
    manifest_p.write_text(json.dumps(manifest, indent=2))

    verifier = _find_fn(mod, ("verify",))
    if verifier is None:
        pytest.skip("verify() not found; please implement")

    with pytest.raises(Exception):
        verifier(bundle_dir)

# ---------- Tests: Signature (optional) ----------

def test_signature_optional_hooks(tmpd, monkeypatch):
    mod = _import_mod()
    verifier = _find_fn(mod, ("verify_signature",))
    if verifier is None:
        pytest.skip("verify_signature() not implemented; this is optional but recommended")

    # Happy path: verifier returns True for placeholder (deterministic)
    assert verifier(b"payload", b"sig", b"pubkey") in (True, False), "verify_signature should return boolean"

    # Force failure path for invalid signature
    def fake_sig(*a, **kw):
        return False
    monkeypatch.setattr(mod, "verify_signature", fake_sig)
    assert mod.verify_signature(b"payload", b"sig", b"pubkey") is False