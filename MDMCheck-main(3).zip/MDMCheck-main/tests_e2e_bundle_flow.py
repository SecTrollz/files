from __future__ import annotations
import hashlib
import json
import pathlib
import pytest

def _require(modname: str):
    try:
        return __import__(modname)
    except Exception as e:
        pytest.skip(f"{modname} not importable: {e}")

@pytest.fixture
def tmpd(tmp_path: pathlib.Path) -> pathlib.Path:
    return tmp_path

def _write(p: pathlib.Path, data: bytes) -> str:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    return hashlib.sha256(data).hexdigest()

def test_pack_dir_then_verify_ok(tmpd):
    pack = _require("bundle_packager")
    verify = _require("verify_bundle")

    src = tmpd / "src"
    s1 = _write(src / "logs/app.log", b"hello\n")
    s2 = _write(src / "evidence/info.txt", b"DEVICE=demo\n")

    # create dir bundle (writes manifest.json in src)
    if not hasattr(pack, "create_bundle"):
        pytest.skip("bundle_packager.create_bundle not implemented")
    pack.create_bundle(src, tmpd / "outdir")

    # verify directory bundle
    if not hasattr(verify, "verify"):
        pytest.skip("verify_bundle.verify not implemented")
    assert verify.verify(src) is True

def test_pack_tar_then_verify_ok(tmpd):
    pack = _require("bundle_packager")
    verify = _require("verify_bundle")

    src = tmpd / "src"
    _write(src / "a.txt", b"a" * 10)
    _write(src / "b/b.txt", b"b" * 10)

    if not hasattr(pack, "create_tar_bundle"):
        pytest.skip("bundle_packager.create_tar_bundle not implemented")
    tar_path = tmpd / "bundle.tar"
    pack.create_tar_bundle(src, tar_path)

    if not hasattr(verify, "verify"):
        pytest.skip("verify_bundle.verify not implemented")
    assert verify.verify(tar_path) is True

def test_verify_detects_tamper_after_pack(tmpd):
    pack = _require("bundle_packager")
    verify = _require("verify_bundle")

    src = tmpd / "src"
    p = src / "x.txt"
    _write(p, b"original")
    if not hasattr(pack, "create_bundle"):
        pytest.skip("bundle_packager.create_bundle not implemented")
    pack.create_bundle(src, tmpd / "outdir")

    # Tamper file AFTER manifest is written
    p.write_text("tampered")

    if not hasattr(verify, "verify"):
        pytest.skip("verify_bundle.verify not implemented")
    with pytest.raises(Exception):
        verify.verify(src)