from __future__ import annotations
import pytest

def _require(modname: str):
    try:
        return __import__(modname)
    except Exception as e:
        pytest.skip(f"{modname} not importable: {e}")

def test_verify_signature_optional_present_or_skipped():
    mod = _require("verify_bundle")
    verifier = getattr(mod, "verify_signature", None)
    if verifier is None:
        pytest.skip("verify_signature not implemented (optional)")
    # Should return a boolean; invalid inputs -> False (not raise)
    assert verifier(b"payload", b"\x00" * 64, b"\x00" * 32) in (True, False)
    assert verifier(b"payload", b"bad", b"also-bad") is False