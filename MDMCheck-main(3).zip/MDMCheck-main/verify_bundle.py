#!/usr/bin/env python3
"""
verify_bundle.py — Secure bundle verifier for MDMCheck.

Features:
- Centralized JSON logging via logging_config.configure_logging()
- Path confinement + symlink rejection (safe_path)
- Streamed SHA-256 hashing with per-file size limit
- Strict manifest validation (bundle_schema_version "1")
- Supports verifying a directory bundle or a .tar/.tgz archive
- Clear exit codes and machine-parseable logs
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import tarfile
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

from logging_config import configure_logging

configure_logging()
LOG = logging.getLogger(__name__)

# Per-file size cap (bytes). Tunable via env or --max-bytes.
MAX_FILE_BYTES = int(os.getenv("MDMCHECK_MAX_FILE_BYTES", str(64 * 1024 * 1024)))  # 64 MiB


# ----------------------------- Exceptions ------------------------------------


class VerificationError(Exception):
    """Generic verification failure."""


# ----------------------------- Path Safety -----------------------------------


def _is_within(base: Path, candidate: Path) -> bool:
    """
    Return True if candidate resolves within base. Works with non-existent paths (strict=False).
    """
    base_resolved = base.resolve()
    try:
        cand_resolved = candidate.resolve()
    except FileNotFoundError:
        cand_resolved = (base / candidate).resolve(strict=False)
    return str(cand_resolved).startswith(str(base_resolved) + os.sep)


def safe_path(base: Path, candidate: Path) -> Path:
    """
    Resolve a candidate path against base with strict traversal protection.
    - Keeps all operations confined to `base`
    - Rejects symlinks anywhere along the path
    - Returns an absolute, normalized Path
    """
    base = base.resolve()
    candidate_path = base / candidate
    if candidate_path.is_symlink():
        LOG.error("Symlink blocked: %s", str(candidate))
        raise VerificationError("Symlink not allowed in bundle")
    normalized = candidate_path.resolve(strict=False)

    if not _is_within(base, normalized):
        LOG.error("Path traversal blocked: %s", str(candidate))
        raise VerificationError("Path traversal outside bundle base")

    # Symlink checks: deny if candidate or any parent is a symlink
    cur = normalized
    while True:
        if cur.is_symlink():
            LOG.error("Symlink blocked: %s", str(candidate))
            raise VerificationError("Symlink not allowed in bundle")
        if cur == base:
            break
        parent = cur.parent
        if parent == cur:
            break
        cur = parent

    return normalized


# ----------------------------- Hashing ---------------------------------------


def compute_sha256(path: Path) -> str:
    """Stream file contents to compute SHA-256 with size enforcement."""
    h = hashlib.sha256()
    total = 0
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            total += len(chunk)
            if total > MAX_FILE_BYTES:
                LOG.error("File too large during hashing: %s (%d bytes)", path, total)
                raise VerificationError("File exceeds size limit")
            h.update(chunk)
    return h.hexdigest()


# ----------------------------- Manifest --------------------------------------


def _validate_hex(s: str) -> bool:
    try:
        int(s, 16)
        return len(s) >= 40  # at least SHA1; SHA256 is 64
    except Exception:
        return False


def load_manifest(manifest_path: Path) -> Dict:
    """Load and validate a v1 manifest."""
    try:
        doc = json.loads(manifest_path.read_text())
    except json.JSONDecodeError as e:
        LOG.error("Manifest JSON invalid: %s", e)
        raise VerificationError("Invalid manifest JSON") from e

    if not isinstance(doc, dict):
        raise VerificationError("Manifest must be a JSON object")

    schema = str(doc.get("bundle_schema_version", "1"))
    if schema.split(".")[0] != "1":
        raise VerificationError(f"Unsupported bundle_schema_version: {schema}")

    files = doc.get("files")
    if not isinstance(files, list) or not files:
        raise VerificationError("Manifest 'files' must be a non-empty list")

    for entry in files:
        if not isinstance(entry, dict):
            raise VerificationError("Manifest file entry must be an object")
        p = entry.get("path")
        h = entry.get("sha256")
        if not isinstance(p, str) or not isinstance(h, str) or not _validate_hex(h):
            raise VerificationError("Manifest entry must include valid 'path' and 'sha256'")
        if p.startswith("/") or ".." in p.split("/"):
            raise VerificationError("Manifest 'path' must be relative and free of traversal")

    return doc


def _iter_manifest_entries(doc: Dict) -> Iterable[Tuple[str, str]]:
    for e in doc["files"]:
        yield e["path"], e["sha256"]


# ----------------------------- Archive handling ------------------------------


def _extract_tar_to_temp(tar_path: Path, temp_dir: Path) -> Path:
    """
    Safely extract a tarball into temp_dir/bundle, preventing path traversal.
    We do not trust tar member paths; we re-map them through safe_path.
    """
    bundle_root = temp_dir / "bundle"
    bundle_root.mkdir(parents=True, exist_ok=True)

    with tarfile.open(tar_path, "r") as tf:
        for member in tf.getmembers():
            if not member.isfile():
                # Skip non-regular files (no dirs/hardlinks/fifos/devs)
                continue

            dest = safe_path(bundle_root, Path(member.name))
            dest.parent.mkdir(parents=True, exist_ok=True)

            fobj = tf.extractfile(member)
            if fobj is None:
                raise VerificationError(f"Failed to read member: {member.name}")
            data = fobj.read()
            if len(data) > MAX_FILE_BYTES:
                raise VerificationError(f"Tar member too large: {member.name}")

            dest.write_bytes(data)

    return bundle_root


def _load_bundle_root(bundle: Path, temp_dir: Path | None = None) -> Path:
    """
    Accept either a directory bundle or a .tar/.tgz and return a directory root.
    """
    bundle = Path(bundle)
    if bundle.is_dir():
        return bundle
    if bundle.is_file() and bundle.suffix in {".tar", ".tgz"}:
        if temp_dir is None:
            from tempfile import TemporaryDirectory

            tmp = TemporaryDirectory()  # keep in scope
            temp_dir = Path(tmp.name)
        return _extract_tar_to_temp(bundle, temp_dir)
    raise VerificationError("Bundle must be a directory or tar archive")


# ----------------------------- Verification ----------------------------------


def verify(bundle_path: str | Path) -> bool:
    """
    Verify a bundle directory or tar:
      - manifest.json presence and validity
      - each file confined to bundle base
      - size limits enforced
      - content digest equals manifest sha256
      - (optional) signature verification hook
    Returns True on success; raises VerificationError on failure.
    """
    base = _load_bundle_root(Path(bundle_path))
    manifest = load_manifest(base / "manifest.json")

    for rel, expected_hash in _iter_manifest_entries(manifest):
        dest = safe_path(base, Path(rel))

        if not dest.is_file():
            LOG.error("Manifest entry missing on disk: %s", rel)
            raise VerificationError(f"Missing file: {rel}")

        # Fast path: stat check before hashing
        st = dest.stat()
        if st.st_size > MAX_FILE_BYTES:
            LOG.error("File exceeds size limit: %s (%d bytes)", rel, st.st_size)
            raise VerificationError(f"File too large: {rel}")

        actual = compute_sha256(dest)
        if actual.lower() != expected_hash.lower():
            LOG.error("Hash mismatch for %s: expected %s got %s", rel, expected_hash, actual)
            raise VerificationError(f"Hash mismatch: {rel}")

    # Optional signature verification (non-fatal if not implemented)
    sig = manifest.get("signature")
    pub = manifest.get("public_key")
    if sig and pub:
        payload = json.dumps(
            {"files": manifest["files"]},
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode()
        try:
            if not verify_signature(payload, bytes.fromhex(sig), bytes.fromhex(pub)):  # type: ignore[name-defined]
                LOG.error("Signature verification failed")
                raise VerificationError("Invalid signature")
        except NameError:
            LOG.warning("Signature present but verify_signature() not implemented; skipping")

    LOG.info("Bundle verified successfully")
    return True


# ----------------------------- CLI -------------------------------------------


def main(argv: List[str] | None = None) -> None:
    configure_logging()
    global MAX_FILE_BYTES

    parser = argparse.ArgumentParser(
        prog="mdmcheck-verify",
        description="Verify an MDMCheck bundle directory or tar archive.",
    )
    parser.add_argument("bundle", help="Path to bundle directory or .tar/.tgz archive")
    parser.add_argument(
        "--max-bytes",
        type=int,
        default=MAX_FILE_BYTES,
        help=f"Per-file max size in bytes (default {MAX_FILE_BYTES})",
    )
    args = parser.parse_args(argv)

    MAX_FILE_BYTES = int(args.max_bytes)

    try:
        verify(args.bundle)
        raise SystemExit(0)
    except VerificationError as e:
        LOG.error("Verification failed: %s", e)
        raise SystemExit(2)
    except FileNotFoundError as e:
        LOG.error("File not found: %s", e)
        raise SystemExit(3)
    except Exception:  # pragma: no cover
        LOG.exception("Unexpected error during verification")
        raise SystemExit(1)


if __name__ == "__main__":  # pragma: no cover
    main()
