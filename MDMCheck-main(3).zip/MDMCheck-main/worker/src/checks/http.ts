export async function probeHEAD(url: string, headers: Record<string,string> = {}) {
  const res = await fetch(url, { method: "HEAD", redirect: "manual", headers });
  return { status: res.status, headers: Object.fromEntries(res.headers.entries()) };
}

export async function probeGET(url: string, headers: Record<string,string> = {}) {
  const res = await fetch(url, { method: "GET", redirect: "manual", headers });
  const ct = res.headers.get("content-type") || "";
  const body = ct.includes("json") ? await res.json().catch(() => ({})) : await res.text();
  return { status: res.status, headers: Object.fromEntries(res.headers.entries()), body };
}
