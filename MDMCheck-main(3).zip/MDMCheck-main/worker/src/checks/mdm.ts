/** Heuristics & known indicators of MDM/IdP enrollment infrastructure.

This is conservative and false-positive averse. */

import { queryDoH } from "../utils/doh";

export interface Finding {
  test: string;
  indicator: string;
  severity: "low"|"med"|"high";
  details?: unknown;
}

const CNAME_PATTERNS: Array<[string, RegExp, string]> = [
  ["AzureAD Enterprise Enrollment", /(^|.)enterpriseenrollment.manage.microsoft.com.?$/i, "CNAME -> manage.microsoft.com"],
  ["AzureAD Enterprise Registration", /(^|.)enterpriseregistration.windows.net.?$/i, "CNAME -> windows.net"],
  ["Workspace ONE (VMware)", /(^|.)(airwatch|awmdm|workspaceone).(com|net).?$/i, "CNAME -> Workspace ONE"],
  ["Jamf Cloud", /(^|.)jamf(cn|cloud)?.com.?$/i, "CNAME -> Jamf"],
  ["Kandji", /(^|.)kandji.io.?$/i, "CNAME -> kandji.io"],
  ["Mosyle", /(^|.)mosyle.com.?$/i, "CNAME -> mosyle.com"],
  ["MobileIron/Ivanti", /(^|.)(mobileiron|ivanti).(com|cloud).?$/i, "CNAME -> Ivanti"],
];

const WELL_KNOWN_HOSTS = [
  // Microsoft Autopilot/AAD sign-in assists
  (d: string) => `enterpriseenrollment.${d}`,
  (d: string) => `enterpriseregistration.${d}`,
  // Apple MDM common hostnames (org-dependent)
  (d: string) => `mdm.${d}`,
  (d: string) => `enroll.${d}`,
  (d: string) => `enrollment.${d}`,
  (d: string) => `deviceenrollment.${d}`,
];

export async function detectForDomain(domain: string) {
  const findings: Finding[] = [];

  // MX tells us which mail provider (hints at OAuth scopes later)
  try {
    const mx = await queryDoH(domain, "MX");
    const mxData = mx.map(a => a.data.toLowerCase());
    if (mxData.some(s => s.includes("google.com")))
      findings.push({ test: "MX", indicator: "Google Workspace", severity: "low", details: mxData });
    if (mxData.some(s => s.includes("outlook.com") || s.includes("microsoft.com")))
      findings.push({ test: "MX", indicator: "Microsoft 365", severity: "low", details: mxData });
  } catch (e) {
    /* non-fatal */
  }

  // CNAME patterns on well-known hostnames
  for (const hk of WELL_KNOWN_HOSTS) {
    const host = hk(domain);
    try {
      const ans = await queryDoH(host, "CNAME");
      for (const a of ans) {
        for (const [label, re, note] of CNAME_PATTERNS) {
          if (re.test(a.data))
            findings.push({ test: `CNAME ${host}`, indicator: label, severity: "high", details: { host, cname: a.data, note } });
        }
      }
    } catch (_) {
      /* ignore */
    }
  }

  // TXT records sometimes leak enrollment hints
  try {
    const txt = await queryDoH(domain, "TXT");
    const parts = txt.flatMap(a => a.data.replace(/^\"|\"$/g, '').split(' '));
    if (parts.some(p => /intune|jamf|kandji|workspace|airwatch|mosyle|mobileiron|ivanti/i.test(p))) {
      findings.push({ test: "TXT", indicator: "MDM hint in TXT", severity: "med", details: parts });
    }
  } catch (_) {}

  return findings;
}
