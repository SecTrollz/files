export interface Env {
  BACKEND_HOST: string;
  CORS_ORIGIN: string;
}

import graph from "../graph.json";

function corsHeaders(origin: string): HeadersInit {
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET,HEAD,POST,PUT,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, CF-Connecting-IP",
  };
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders(env.CORS_ORIGIN) });
    }

    const incomingUrl = new URL(request.url);

    if (incomingUrl.pathname === "/graph") {
      return new Response(JSON.stringify(graph), {
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders(env.CORS_ORIGIN),
        },
      });
    }

    const backendUrl = new URL(env.BACKEND_HOST);
    backendUrl.pathname = incomingUrl.pathname;
    backendUrl.search = incomingUrl.search;

    const requestHeaders = new Headers(request.headers);
    const clientIp = request.headers.get("CF-Connecting-IP");
    if (clientIp) requestHeaders.set("CF-Connecting-IP", clientIp);
    const backendRequest = new Request(backendUrl.toString(), {
      method: request.method,
      headers: requestHeaders,
      body: request.body,
    });
    const backendResponse = await fetch(backendRequest);

    const responseHeaders = new Headers(backendResponse.headers);
    for (const [k, v] of Object.entries(corsHeaders(env.CORS_ORIGIN))) {
      responseHeaders.set(k, v);
    }

    return new Response(backendResponse.body, {
      status: backendResponse.status,
      headers: responseHeaders,
    });
  },
};
