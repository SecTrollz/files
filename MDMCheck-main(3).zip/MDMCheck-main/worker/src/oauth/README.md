OAuth (scaffold)

This project targets Google and Microsoft first. Use KV SESSIONS to store short-lived PKCE state.

For production, prefer a dedicated user system (Clerk, Auth0, Stytch) in front of the Worker if you want turn-key provider coverage. If you want native Worker OAuth, wire google.ts and microsoft.ts using standard OAuth2 flows and set these secrets:

WRANGLER SECRET put GOOGLE_CLIENT_ID
WRANGLER SECRET put GOOGLE_CLIENT_SECRET
WRANGLER SECRET put MS_CLIENT_ID
WRANGLER SECRET put MS_CLIENT_SECRET

Then add routes like /oauth/google/start, /oauth/google/callback from src/index.ts.

// (Implementations omitted here for brevity; they follow standard PKCE + state nonce exchange.)
