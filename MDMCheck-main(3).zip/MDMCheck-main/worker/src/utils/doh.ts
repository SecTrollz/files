// Cloudflare DNS-over-HTTPS JSON API helper
// https://developers.cloudflare.com/1.1.1.1/dns-over-https/json-format/

export type RRType = "A"|"AAAA"|"MX"|"TXT"|"CNAME"|"NS";

export interface DoHAnswer {
  name: string;
  type: number;
  TTL: number;
  data: string;
}

const TYPE_MAP: Record<RRType, number> = { A:1, AAAA:28, MX:15, TXT:16, CNAME:5, NS:2 };

export async function queryDoH(domain: string, type: RRType, cf: typeof fetch = fetch) {
  const url = `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(domain)}&type=${TYPE_MAP[type]}`;
  const res = await cf(url, { headers: { accept: "application/dns-json" } });
  if (!res.ok) throw new Error(`DoH ${type} failed: ${res.status}`);
  const j = await res.json() as { Answer?: DoHAnswer[] };
  return j.Answer ?? [];
}
