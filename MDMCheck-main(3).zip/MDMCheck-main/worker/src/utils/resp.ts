export const json = (data: unknown, init: ResponseInit = {}) =>
  new Response(JSON.stringify(data, null, 2), {
    headers: { "content-type": "application/json; charset=utf-8", ...init.headers },
    ...init,
  });

export const bad = (message: string, status = 400) =>
  json({ ok: false, error: message }, { status });

export const withCORS = (req: Request, res: Response, origin: string) => {
  const o = new Headers(res.headers);
  const allowed = origin || "*";
  o.set("access-control-allow-origin", allowed);
  o.set("access-control-allow-headers", "content-type, authorization");
  o.set("access-control-allow-methods", "GET,POST,OPTIONS");
  return new Response(res.body, { status: res.status, headers: o });
};
