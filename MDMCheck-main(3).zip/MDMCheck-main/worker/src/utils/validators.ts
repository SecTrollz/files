const EMAIL_RE = /^[^@\s]+@([^@\s]+)$/i;
const DOMAIN_RE = /^(?:[a-z0-9-]+\.)+[a-z]{2,}$/i;

export const parseTarget = (input: string) => {
  input = input.trim();
  const emailMatch = EMAIL_RE.exec(input);
  if (emailMatch)
    return { kind: "email" as const, email: input.toLowerCase(), domain: emailMatch[1].toLowerCase() };
  if (DOMAIN_RE.test(input))
    return { kind: "domain" as const, domain: input.toLowerCase() };
  throw new Error("Provide a valid email or domain");
};
