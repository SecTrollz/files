import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { Miniflare } from 'miniflare';
import { createServer } from 'node:http';
import { buildSync } from 'esbuild';

const graph = {
  start: {
    related: ['node-a', 'node-b'],
    surprise: ['node-c', 'node-d'],
  },
};

describe('Worker /api/next', () => {
  let server;
  let port;

  beforeAll(async () => {
    server = createServer((req, res) => {
      if (req.url.startsWith('/api/next')) {
        const payload = {
          related: [graph.start.related[0]],
          surprise: graph.start.surprise[0],
        };
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(payload));
      } else {
        res.writeHead(404);
        res.end();
      }
    });
    await new Promise((resolve) => server.listen(0, resolve));
    port = server.address().port;
  });

  afterAll(() => {
    server.close();
  });

  it('returns valid JSON with related and surprise options', async () => {
    const { outputFiles } = buildSync({
      entryPoints: ['src/index.ts'],
      bundle: true,
      format: 'esm',
      write: false,
    });
    const script = outputFiles[0].text;

    const mf = new Miniflare({
      modules: true,
      script,
      compatibilityDate: '2024-11-20',
      bindings: {
        BACKEND_HOST: `http://localhost:${port}`,
        CORS_ORIGIN: '*',
      },
    });

    const res = await mf.dispatchFetch('http://example.com/api/next');
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data).toHaveProperty('related');
    expect(data).toHaveProperty('surprise');
    expect(graph.start.related).toContain(data.related[0]);
    expect(graph.start.surprise).toContain(data.surprise);
  });
});
